#!/bin/bash

sed -i '/<!-- IV. URAIAN HASIL PENGAWASAN -->/,/<!-- V. DUGAAAN PELANGGARAN -->/c\
                <!-- IV. URAIAN HASIL PENGAWASAN -->\
                <div class="card">\
                    <div class="card-header">IV. 📝 Uraian Hasil Pengawasan</div>\
                    <div class="card-body">\
                        <div class="form-group">\
                            <label>Uraian Hasil Pengawasan</label>\
                            <textarea id="uraian_hasil" rows="8" placeholder=""></textarea>\
                        </div>\
                    </div>\
                </div>' form_a.php

# Update PDF builder
sed -i '/\/\/ IV. URAIAN/,/\/\/ V. DUGAAAN PELANGGARAN/c\
    // IV. URAIAN\
    html += '\''<div class="pdf-section">IV. Uraian Hasil Pengawasan</div>'\'';\
    html += '\''<p style="text-align:justify;">'\''+nl(v('\''uraian_hasil'\''))+'\''</p>'\'';' form_a.php

echo "✅ Bagian IV jadi SATU TEXTAREA KOSONG!"
