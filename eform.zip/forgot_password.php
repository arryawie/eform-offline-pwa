<?php
require_once 'config/database.php';
require_once 'config/auth.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lupa Password - <?= APP_NAME ?></title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #1A1A2E, #2D2D4E);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }
        .container {
            background: #fff;
            border-radius: 16px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.5);
        }
        .container h1 { font-size: 24px; color: #1A1A2E; margin-bottom: 8px; text-align: center; }
        .container p { color: #6B7A99; font-size: 14px; text-align: center; margin-bottom: 24px; }
        .field { margin-bottom: 16px; }
        .field label { display: block; font-size: 12px; font-weight: 700; color: #6B7A99; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
        .field input { width: 100%; padding: 12px 14px; border: 1.5px solid #DDE3F0; border-radius: 8px; font-size: 14px; outline: none; transition: 0.2s; }
        .field input:focus { border-color: #E53935; box-shadow: 0 0 0 3px rgba(229,57,53,0.1); }
        .btn { width: 100%; padding: 12px; background: #E53935; color: #fff; border: none; border-radius: 8px; font-size: 14px; font-weight: 700; cursor: pointer; transition: 0.2s; }
        .btn:hover { background: #c62828; }
        .error { background: #FFE5E5; color: #CC0000; padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 16px; text-align: center; }
        .success { background: #EEFAF4; color: #1A7A45; padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 16px; text-align: center; border: 1px solid #B6E8CF; }
        .footer { margin-top: 20px; color: rgba(255,255,255,0.4); font-size: 11px; text-align: center; }
        .logo-box { text-align: center; font-size: 48px; margin-bottom: 8px; }
        .loading { display: none; text-align: center; color: #6B7A99; font-size: 13px; margin-top: 8px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo-box"><img src="assets/images/logo.png" style="height:50px;width:auto;" alt="Logo"></div>
        <h1>🔑 Lupa Password</h1>
        <p>Masukkan username atau email Anda, admin akan dihubungi.</p>

        <div id="messageBox"></div>

        <form id="forgotForm">
            <div class="field">
                <label>Username atau Email</label>
                <input type="text" id="userInput" placeholder="Masukkan username atau email" required autofocus>
            </div>
            <button type="submit" class="btn" id="submitBtn">📤 Kirim Permintaan</button>
            <div class="loading" id="loading">⏳ Mengirim...</div>
        </form>

        <a href="index.php" style="display:block;text-align:center;margin-top:12px;color:#E53935;text-decoration:none;font-size:13px;">← Kembali ke Login</a>
    </div>

    <div class="footer">
        E-Form System v1.8 &copy; 2026 PT. Nura Kreasi Digital
    </div>

    <script>
    document.getElementById('forgotForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        var input = document.getElementById('userInput').value.trim();
        var messageBox = document.getElementById('messageBox');
        var submitBtn = document.getElementById('submitBtn');
        var loading = document.getElementById('loading');
        
        if (!input) {
            messageBox.innerHTML = '<div class="error">⚠️ Username atau email tidak boleh kosong.</div>';
            return;
        }
        
        submitBtn.disabled = true;
        loading.style.display = 'block';
        messageBox.innerHTML = '';
        
        fetch('api/forgot_password.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ input: input })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                messageBox.innerHTML = '<div class="success">✅ ' + data.message + '</div>';
                document.getElementById('userInput').value = '';
            } else {
                messageBox.innerHTML = '<div class="error">❌ ' + data.message + '</div>';
            }
        })
        .catch(error => {
            messageBox.innerHTML = '<div class="error">❌ Terjadi kesalahan: ' + error.message + '</div>';
        })
        .finally(() => {
            submitBtn.disabled = false;
            loading.style.display = 'none';
        });
    });
    </script>
</body>
</html>
