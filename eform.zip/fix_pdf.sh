#!/bin/bash

# Cari dan ganti fungsi downloadPDF
sed -i '/function downloadPDF() {/,/^    }/c\
function downloadPDF() {\
    saveToServer("downloaded");\
    var pdf = new jspdf.jsPDF("p", "mm", [210, 330]);\
    var pdfWidth = pdf.internal.pageSize.getWidth();\
    var pdfHeight = pdf.internal.pageSize.getHeight();\
    var margin = 10;\
    var contentWidth = pdfWidth - (margin * 2);\
    var contentHeight = pdfHeight - (margin * 2);\
    var page = 1;\
    var yPosition = margin;\
    var isFirstPage = true;\
    \
    function getTextHeight(text, fontSize) {\
        var lines = text.split("\\n");\
        return lines.length * (fontSize * 0.3528);\
    }\
    \
    function addTextToPDF(text, x, y, fontSize, isBold, align) {\
        if (!text) return y;\
        fontSize = fontSize || 10;\
        var lines = text.split("\\n");\
        pdf.setFontSize(fontSize);\
        pdf.setFont("times", isBold ? "bold" : "normal");\
        lines.forEach(function(line, i) {\
            if (y > pdfHeight - margin) {\
                pdf.addPage();\
                y = margin;\
            }\
            pdf.text(line, x, y, { align: align || "left" });\
            y += (fontSize * 0.3528) + 2;\
        });\
        return y;\
    }\
    \
    function addTableToPDF(rows, x, y) {\
        var colWidths = [30, 80, 30, 80];\
        var rowHeight = 6;\
        var startY = y;\
        pdf.setFontSize(8);\
        rows.forEach(function(row, ri) {\
            if (y > pdfHeight - margin) {\
                pdf.addPage();\
                y = margin;\
            }\
            pdf.setFont("times", ri === 0 ? "bold" : "normal");\
            row.forEach(function(cell, ci) {\
                var xPos = x + colWidths.slice(0, ci).reduce(function(a,b) { return a+b; }, 0);\
                pdf.rect(xPos, y, colWidths[ci], rowHeight);\
                pdf.text(cell, xPos + 1, y + 4);\
            });\
            y += rowHeight;\
        });\
        return y;\
    }\
    \
    // ===== AMBIL DATA =====\
    function v(id) { var el = document.getElementById(id); return el ? el.value.trim() : ""; }\
    function esc(s) { return s || ""; }\
    function fdate(s) { if(!s) return ""; var d=new Date(s); var M=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"]; return d.getDate()+" "+M[d.getMonth()]+" "+d.getFullYear(); }\
    \
    var nomor = esc(v("nomor"));\
    var tahapan = esc(v("tahapan"));\
    var nama_pengawas = esc(v("nama_pengawas"));\
    var jabatan = esc(v("jabatan"));\
    var no_st = esc(v("no_st"));\
    var alamat = esc(v("alamat"));\
    var bentuk = esc(v("bentuk"));\
    var tujuan = esc(v("tujuan"));\
    var sasaran = esc(v("sasaran"));\
    var tgl_kegiatan = fdate(v("tgl_kegiatan"));\
    var tempat_kegiatan = esc(v("tempat_kegiatan"));\
    var uraian = quill ? quill.root.innerHTML : esc(v("uraian"));\
    var uraianText = uraian.replace(/<[^>]*>/g, "");\
    var ttd_kota = esc(v("ttd_kota"));\
    var ttd_tgl = fdate(v("ttd_tgl"));\
    var ttd_jabatan = esc(v("ttd_jabatan"));\
    var ttd_nama = esc(v("ttd_nama"));\
    \
    var y = margin;\
    \
    // ===== KOP =====\
    pdf.setFontSize(12);\
    pdf.setFont("times", "bold");\
    var kopText = "<?= htmlspecialchars($kop_instansi) ?>";\
    var kopWidth = pdf.getStringUnitWidth(kopText) * 12 / pdf.internal.scaleFactor;\
    pdf.text(kopText, (pdfWidth - kopWidth) / 2, y);\
    y += 10;\
    \
    pdf.setFontSize(8);\
    pdf.setFont("times", "normal");\
    var alamatKop = "<?= htmlspecialchars($kop_alamat) ?>";\
    var alamatWidth = pdf.getStringUnitWidth(alamatKop) * 8 / pdf.internal.scaleFactor;\
    if (alamatKop) { pdf.text(alamatKop, (pdfWidth - alamatWidth) / 2, y); y += 5; }\
    y += 3;\
    pdf.line(margin, y, pdfWidth - margin, y);\
    y += 6;\
    \
    // ===== JUDUL =====\
    pdf.setFontSize(12);\
    pdf.setFont("times", "bold");\
    var judul = "FORM A";\
    var judulWidth = pdf.getStringUnitWidth(judul) * 12 / pdf.internal.scaleFactor;\
    pdf.text(judul, (pdfWidth - judulWidth) / 2, y);\
    y += 7;\
    var subJudul = "LAPORAN HASIL PENGAWASAN PEMILIHAN";\
    var subJudulWidth = pdf.getStringUnitWidth(subJudul) * 11 / pdf.internal.scaleFactor;\
    pdf.setFontSize(11);\
    pdf.text(subJudul, (pdfWidth - subJudulWidth) / 2, y);\
    y += 8;\
    var nomorText = "Nomor: " + nomor;\
    var nomorWidth = pdf.getStringUnitWidth(nomorText) * 10 / pdf.internal.scaleFactor;\
    pdf.setFontSize(10);\
    pdf.text(nomorText, (pdfWidth - nomorWidth) / 2, y);\
    y += 10;\
    \
    // ===== I. DATA PENGAWASAN =====\
    pdf.setFontSize(10);\
    pdf.setFont("times", "bold");\
    pdf.text("I. Data Pengawasan", margin, y);\
    y += 6;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    var dataRows = [\
        ["1. Tahapan yang diawasi", ":", tahapan],\
        ["2. Nama Pelaksana", ":", nama_pengawas],\
        ["3. Jabatan", ":", jabatan],\
        ["4. Nomor Surat Tugas", ":", no_st],\
        ["5. Alamat", ":", alamat]\
    ];\
    dataRows.forEach(function(row) {\
        if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
        pdf.text(row[0], margin, y);\
        pdf.text(row[1], margin + 80, y);\
        pdf.text(row[2], margin + 90, y);\
        y += 6;\
    });\
    y += 4;\
    \
    // ===== II. KEGIATAN PENGAWASAN =====\
    if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
    pdf.setFont("times", "bold");\
    pdf.text("II. Kegiatan Pengawasan", margin, y);\
    y += 6;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    var kegiatanRows = [\
        ["1. Bentuk", ":", bentuk],\
        ["2. Tujuan", ":", tujuan],\
        ["3. Sasaran", ":", sasaran],\
        ["4. Waktu dan Tempat", ":", tgl_kegiatan + ", " + tempat_kegiatan]\
    ];\
    kegiatanRows.forEach(function(row) {\
        if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
        pdf.text(row[0], margin, y);\
        pdf.text(row[1], margin + 80, y);\
        var text2 = row[2];\
        if (pdf.getStringUnitWidth(text2) * 9 / pdf.internal.scaleFactor > 80) {\
            var splitText = pdf.splitTextToSize(text2, 80);\
            splitText.forEach(function(line, i) {\
                if (i > 0 && y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
                if (i === 0) { pdf.text(line, margin + 90, y); }\
                else { pdf.text(line, margin + 90, y); }\
                y += 5;\
            });\
            y -= 5;\
        } else {\
            pdf.text(text2, margin + 90, y);\
        }\
        y += 6;\
    });\
    y += 4;\
    \
    // ===== III. URAIAN SINGKAT =====\
    if (y > pdfHeight - margin - 20) { pdf.addPage(); y = margin; }\
    pdf.setFont("times", "bold");\
    pdf.setFontSize(10);\
    pdf.text("III. Uraian Singkat Hasil Pengawasan", margin, y);\
    y += 6;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    var uraianSplit = pdf.splitTextToSize(uraianText, contentWidth);\
    uraianSplit.forEach(function(line) {\
        if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
        pdf.text(line, margin, y);\
        y += 5;\
    });\
    y += 4;\
    \
    // ===== IV. DUGAAAN PELANGGARAN =====\
    var adaP = document.getElementById("ada_pelanggaran").checked;\
    if (y > pdfHeight - margin - 20) { pdf.addPage(); y = margin; }\
    pdf.setFont("times", "bold");\
    pdf.setFontSize(10);\
    pdf.text("IV. Informasi Dugaan Pelanggaran", margin, y);\
    y += 6;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    if (adaP) {\
        var pelanggaranData = [\
            ["1. Peristiwa", ":", v("p_peristiwa")],\
            ["   b. Tempat", ":", v("p_tempat")],\
            ["   c. Waktu", ":", v("p_waktu")],\
            ["   d. Pelaku", ":", v("p_pelaku")],\
            ["   e. Alamat", ":", v("p_alamat_pelaku")],\
            ["2. Saksi-saksi", ":", v("saksi1_nama") + " (" + v("saksi1_alamat") + ")"],\
            ["", "", v("saksi2_nama") + " (" + v("saksi2_alamat") + ")"],\
            ["3. Alat Bukti", ":", v("bukti_a") + ", " + v("bukti_b") + ", " + v("bukti_c")],\
            ["4. Barang Bukti", ":", v("barang_a") + ", " + v("barang_b") + ", " + v("barang_c")],\
            ["5. Uraian", ":", v("uraian_pelanggaran")],\
            ["6. Fakta", ":", v("fakta")],\
            ["7. Analisa", ":", v("analisa")]\
        ];\
        pelanggaranData.forEach(function(row) {\
            if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
            pdf.text(row[0], margin, y);\
            pdf.text(row[1], margin + 80, y);\
            var text2 = row[2];\
            if (pdf.getStringUnitWidth(text2) * 9 / pdf.internal.scaleFactor > 80) {\
                var splitText2 = pdf.splitTextToSize(text2, 80);\
                splitText2.forEach(function(line, i) {\
                    if (i > 0 && y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
                    if (i === 0) { pdf.text(line, margin + 90, y); }\
                    else { pdf.text(line, margin + 90, y); }\
                    y += 5;\
                });\
                y -= 5;\
            } else {\
                pdf.text(text2, margin + 90, y);\
            }\
            y += 6;\
        });\
    } else {\
        pdf.text("Nihil", margin, y);\
        y += 6;\
    }\
    y += 4;\
    \
    // ===== V. POTENSI SENGKETA =====\
    var adaS = document.getElementById("ada_sengketa").checked;\
    if (y > pdfHeight - margin - 20) { pdf.addPage(); y = margin; }\
    pdf.setFont("times", "bold");\
    pdf.setFontSize(10);\
    pdf.text("V. Informasi Potensi Sengketa", margin, y);\
    y += 6;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    if (adaS) {\
        var sengketaData = [\
            ["1. Peristiwa", ":", v("s_peserta")],\
            ["   b. Tempat", ":", v("s_tempat")],\
            ["   c. Waktu", ":", v("s_waktu")],\
            ["2. Obyek Sengketa", ":", v("s_bentuk")],\
            ["   b. Identitas", ":", v("s_identitas")],\
            ["   c. Tanggal", ":", v("s_tgl_keluar")],\
            ["   d. Kerugian", ":", v("s_kerugian")],\
            ["3. Uraian", ":", v("s_uraian")]\
        ];\
        sengketaData.forEach(function(row) {\
            if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
            pdf.text(row[0], margin, y);\
            pdf.text(row[1], margin + 80, y);\
            var text2 = row[2];\
            if (pdf.getStringUnitWidth(text2) * 9 / pdf.internal.scaleFactor > 80) {\
                var splitText2 = pdf.splitTextToSize(text2, 80);\
                splitText2.forEach(function(line, i) {\
                    if (i > 0 && y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
                    if (i === 0) { pdf.text(line, margin + 90, y); }\
                    else { pdf.text(line, margin + 90, y); }\
                    y += 5;\
                });\
                y -= 5;\
            } else {\
                pdf.text(text2, margin + 90, y);\
            }\
            y += 6;\
        });\
    } else {\
        pdf.text("Nihil", margin, y);\
        y += 6;\
    }\
    y += 4;\
    \
    // ===== TTD =====\
    if (y > pdfHeight - margin - 40) { pdf.addPage(); y = margin; }\
    pdf.setFont("times", "bold");\
    pdf.setFontSize(10);\
    pdf.text("VI. Penandatangan", margin, y);\
    y += 8;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    pdf.text(ttd_kota + ", " + ttd_tgl, margin + 60, y);\
    y += 6;\
    pdf.text(ttd_jabatan, margin + 60, y);\
    y += 6;\
    pdf.text("_________________________", margin + 55, y);\
    y += 4;\
    pdf.setFont("times", "bold");\
    pdf.text(ttd_nama, margin + 60, y);\
    y += 4;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(8);\
    pdf.text("Nama Lengkap", margin + 55, y);\
    y += 10;\
    \
    // =============================================================\
    // DOKUMENTASI - HALAMAN TERPISAH DENGAN FOTO ASLI\
    // =============================================================\
    if (photos.length > 0) {\
        pdf.addPage();\
        y = margin + 20;\
        pdf.setFont("times", "bold");\
        pdf.setFontSize(12);\
        var judulFoto = "DOKUMENTASI KEGIATAN";\
        var judulFotoWidth = pdf.getStringUnitWidth(judulFoto) * 12 / pdf.internal.scaleFactor;\
        pdf.text(judulFoto, (pdfWidth - judulFotoWidth) / 2, y);\
        y += 10;\
        \
        var fotoJudul = esc(v("foto_judul"));\
        if (fotoJudul) {\
            pdf.setFont("times", "italic");\
            pdf.setFontSize(9);\
            var judulWidth2 = pdf.getStringUnitWidth(fotoJudul) * 9 / pdf.internal.scaleFactor;\
            pdf.text(fotoJudul, (pdfWidth - judulWidth2) / 2, y);\
            y += 8;\
        }\
        \
        var imgWidth = 80;\
        var imgHeight = 60;\
        var cols = 2;\
        var spacing = 10;\
        var totalWidth = (cols * imgWidth) + ((cols - 1) * spacing);\
        var startX = (pdfWidth - totalWidth) / 2;\
        \
        photos.forEach(function(p, index) {\
            var col = index % cols;\
            var row = Math.floor(index / cols);\
            var x = startX + (col * (imgWidth + spacing));\
            var yPos = y + (row * (imgHeight + spacing + 10));\
            \
            if (yPos + imgHeight > pdfHeight - margin) {\
                pdf.addPage();\
                y = margin + 20;\
                yPos = y + (row * (imgHeight + spacing + 10));\
            }\
            \
            try {\
                pdf.addImage(p.src, "JPEG", x, yPos, imgWidth, imgHeight);\
                if (p.caption) {\
                    pdf.setFont("times", "italic");\
                    pdf.setFontSize(7);\
                    var capWidth = pdf.getStringUnitWidth(p.caption) * 7 / pdf.internal.scaleFactor;\
                    pdf.text(p.caption, x + (imgWidth - capWidth) / 2, yPos + imgHeight + 4);\
                }\
            } catch(e) {\
                console.log("Gagal load foto: " + e.message);\
            }\
        });\
    }\
    \
    pdf.save("Laporan_Hasil_Pengawasan_"+new Date().toISOString().slice(0,10)+".pdf");\
    showToast("📄 PDF F4 berhasil di-download!", "success");\
}' form_a.php

echo "✅ PDF generator sudah diupdate!"
echo "   - Teks dibuat langsung dengan jsPDF (bukan html2canvas)"
echo "   - Foto ditambahkan langsung sebagai gambar (bukan di-convert)"
echo "   - Hasil lebih rapi dan tidak pecah!"
