<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? APP_NAME ?></title>
    
    <!-- Manifest untuk PWA -->
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#E53935">
    
    <!-- Stylesheet utama -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ============================================
         ONESIGNAL WEB PUSH SDK
         ============================================ -->
    <script src="https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js" defer></script>
    <script>
        window.OneSignalDeferred = window.OneSignalDeferred || [];
        OneSignalDeferred.push(async function(OneSignal) {
            await OneSignal.init({
                appId: "01cb3e1a-38ba-4514-8643-8782e78463a1",
                safari_web_id: "", // isi kalau support Safari iOS
                notifyButton: { enable: false }, // kita bikin tombol sendiri
                allowLocalhostAsSecureOrigin: true,
            });
        });
    </script>
    <!-- ============================================ -->
</head>
<body>