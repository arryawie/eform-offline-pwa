<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Google\Client;
use Google\Service\Drive;

function uploadToAdminDrive($content, $filename, $folderLink) {
    // Ambil folder ID dari link
    preg_match('/folders\/([a-zA-Z0-9_-]+)/', $folderLink, $matches);
    $folderId = $matches[1] ?? null;
    
    if (!$folderId) {
        throw new Exception('Folder ID tidak ditemukan di link');
    }
    
    // Gunakan Service Account Super Admin untuk upload ke folder admin
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM super_admin_gdrive ORDER BY id DESC LIMIT 1");
    $config = $stmt->fetch();
    
    if (!$config) {
        throw new Exception('Super Admin GDrive belum dikonfigurasi');
    }
    
    $client = new Client();
    $client->setApplicationName('E-Form System');
    $client->setScopes([Drive::DRIVE_FILE]);
    $client->setAuthConfig([
        'type' => 'service_account',
        'client_email' => $config['service_account_email'],
        'private_key' => $config['private_key'],
        'project_id' => 'eform-system'
    ]);
    
    $service = new Drive($client);
    
    $file = new Google\Service\Drive\DriveFile();
    $file->setName($filename);
    $file->setParents([$folderId]);
    
    $result = $service->files->create($file, [
        'data' => $content,
        'mimeType' => 'application/pdf',
        'uploadType' => 'multipart'
    ]);
    
    return $result;
}
