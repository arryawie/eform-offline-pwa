<?php
// ============================================================
// GOOGLE DRIVE CONFIGURATION
// ============================================================

require_once __DIR__ . '/../vendor/autoload.php';

use Google\Client;
use Google\Service\Drive;

// ============================================================
// KONFIGURASI GOOGLE CLOUD CONSOLE
// ============================================================
// ⚠️ GANTI DENGAN CREDENTIALS ANDA NANTI
// ============================================================
define('GDRIVE_CLIENT_ID', 'YOUR_CLIENT_ID.apps.googleusercontent.com');
define('GDRIVE_CLIENT_SECRET', 'YOUR_CLIENT_SECRET');
define('GDRIVE_REDIRECT_URI', 'https://your-domain.com/admin/gdrive_callback.php');
define('GDRIVE_APP_NAME', 'E-Form System');

// ============================================================
// FUNGSI GOOGLE CLIENT
// ============================================================
function getGoogleClient($refreshToken = null) {
    $client = new Client();
    $client->setApplicationName(GDRIVE_APP_NAME);
    $client->setClientId(GDRIVE_CLIENT_ID);
    $client->setClientSecret(GDRIVE_CLIENT_SECRET);
    $client->setRedirectUri(GDRIVE_REDIRECT_URI);
    $client->setScopes([
        Drive::DRIVE_FILE,
        'https://www.googleapis.com/auth/drive.appdata',
        'https://www.googleapis.com/auth/userinfo.email'
    ]);
    $client->setAccessType('offline');
    $client->setPrompt('select_account consent');
    
    if ($refreshToken) {
        $client->refreshToken($refreshToken);
    }
    
    return $client;
}

function getDriveService($refreshToken = null) {
    $client = getGoogleClient($refreshToken);
    return new Drive($client);
}

function getGoogleAuthUrl() {
    $client = getGoogleClient();
    return $client->createAuthUrl();
}

// ============================================================
// FUNGSI GOOGLE DRIVE
// ============================================================
function getOrCreateDriveFolder($service, $name, $parentId = null) {
    // Cari folder existing
    $query = "name='{$name}' and mimeType='application/vnd.google-apps.folder' and trashed=false";
    if ($parentId) {
        $query .= " and '{$parentId}' in parents";
    }
    
    $results = $service->files->listFiles([
        'q' => $query,
        'spaces' => 'drive',
        'fields' => 'files(id, name)'
    ]);
    
    foreach ($results->getFiles() as $file) {
        return $file->getId();
    }
    
    // Buat folder baru
    $folder = new Google\Service\Drive\DriveFile();
    $folder->setName($name);
    $folder->setMimeType('application/vnd.google-apps.folder');
    if ($parentId) {
        $folder->setParents([$parentId]);
    }
    
    $result = $service->files->create($folder);
    return $result->getId();
}

function uploadToDrive($service, $content, $filename, $folderId = null) {
    $file = new Google\Service\Drive\DriveFile();
    $file->setName($filename);
    if ($folderId) {
        $file->setParents([$folderId]);
    }
    
    $result = $service->files->create($file, [
        'data' => $content,
        'mimeType' => 'application/octet-stream',
        'uploadType' => 'multipart'
    ]);
    
    // Set permission - bisa dilihat oleh siapa saja dengan link
    try {
        $permission = new Google\Service\Drive\Permission();
        $permission->setType('anyone');
        $permission->setRole('reader');
        $service->permissions->create($result->id, $permission);
    } catch (Exception $e) {
        // Permission mungkin sudah ada
    }
    
    return $result;
}

function getSuperAdminAuthUrl() {
    return getGoogleAuthUrl();
}
