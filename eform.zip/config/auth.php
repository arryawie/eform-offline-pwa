<?php
// config/auth.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    if (!isset($_SESSION['user_id'])) return false;
    if (isset($_SESSION['last_activity']) && 
        (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
        session_destroy();
        return false;
    }
    $_SESSION['last_activity'] = time();
    return true;
}

function login($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['last_activity'] = time();
        
        $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$user['id']]);
        
        return true;
    }
    return false;
}

function logout() {
    session_destroy();
}

function hasRole($role) {
    if (!isset($_SESSION['role'])) return false;
    if ($_SESSION['role'] === 'super_admin') return true;
    return $_SESSION['role'] === $role;
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

function requireAdmin() {
    requireLogin();
    if (!hasRole('super_admin') && !hasRole('admin')) {
        header('Location: dashboard.php');
        exit;
    }
}

function requireSuperAdmin() {
    requireLogin();
    if (!hasRole('super_admin')) {
        header('Location: dashboard.php');
        exit;
    }
}

function canAccessForm($form_key) {
    global $pdo;
    if (!isLoggedIn()) return false;
    if (hasRole('super_admin') || hasRole('admin')) return true;
    
    $stmt = $pdo->prepare("SELECT 1 FROM user_form_access ufa JOIN forms f ON f.id = ufa.form_id WHERE ufa.user_id = ? AND f.form_key = ?");
    $stmt->execute([$_SESSION['user_id'], $form_key]);
    return $stmt->fetch() !== false;
}

function logAction($user_id, $action) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO user_logs (user_id, action, ip_address, user_agent) VALUES (?, ?, ?, ?)");
    $stmt->execute([
        $user_id,
        $action,
        $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
    ]);
}

// ===== CEK MAINTENANCE MODE =====
function isMaintenanceMode() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'maintenance_mode'");
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return ($row && $row['setting_value'] === 'on');
    } catch (Exception $e) {
        return false;
    }
}

function checkMaintenance() {
    // Jika maintenance tidak aktif, lanjutkan
    if (!isMaintenanceMode()) {
        return true;
    }
    
    // Jika user super_admin, tetap bisa akses
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'super_admin') {
        return true;
    }
    
    // Admin dan user di-redirect ke maintenance
    header('Location: maintenance.php');
    exit;
}
