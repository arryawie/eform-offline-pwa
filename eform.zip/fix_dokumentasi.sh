#!/bin/bash

# Update PDF builder - pisahkan dokumentasi di halaman sendiri
sed -i '/\/\/ FOTO/,/html += "<\/div>"/c\
    // FOTO - HALAMAN TERPISAH\
    if (photos.length > 0) {\
        html += "<div style=\"page-break-before: always;\"></div>";\
        html += "<div class=\"pdf-page\" style=\"text-align:center;\">";\
        html += "<div class=\"pdf-foto-title\">DOKUMENTASI KEGIATAN</div>";\
        if (v("foto_judul")) html += "<p style=\"text-align:center;font-size:9pt;font-style:italic;margin-bottom:12px;\">"+esc(v("foto_judul"))+"</p>";\
        html += "<div class=\"pdf-foto-grid\">";\
        photos.forEach(function(p) {\
            html += "<div class=\"pdf-foto-item\" style=\"margin-bottom:10px;\">";\
            html += "<img src=\""+p.src+"\" style=\"width:100%;max-width:280px;border:1px solid #ccc;border-radius:4px;\">";\
            html += "<p style=\"text-align:center;font-size:8.5pt;margin-top:3px;font-style:italic;color:#555;\">"+esc(p.caption||"")+"</p>";\
            html += "</div>";\
        });\
        html += "</div>";\
        html += "</div>";\
    }' form_a.php

# Update downloadPDF untuk deteksi halaman dokumentasi
sed -i '/function downloadPDF() {/,/^    }/c\
function downloadPDF() {\
    saveToServer("downloaded");\
    var element = document.getElementById("previewDoc");\
    html2canvas(element, { scale: 2, useCORS: true, logging: false, allowTaint: true }).then(function(canvas) {\
        var imgData = canvas.toDataURL("image/png");\
        var pdf = new jspdf.jsPDF("p", "mm", [210, 330]);\
        var pdfWidth = pdf.internal.pageSize.getWidth();\
        var pdfHeight = pdf.internal.pageSize.getHeight();\
        var imgWidth = canvas.width;\
        var imgHeight = canvas.height;\
        var margin = 1;\
        var contentWidth = pdfWidth - (margin * 2);\
        var contentHeight = pdfHeight - (margin * 2);\
        var ratio = Math.min(contentWidth / imgWidth, contentHeight / imgHeight);\
        var imgX = margin + (contentWidth - imgWidth * ratio) / 2;\
        var imgY = margin;\
        var pageHeight = pdfHeight;\
        var imgHeightPage = imgHeight * ratio;\
        var totalPages = Math.ceil(imgHeightPage / contentHeight);\
        var position = 0;\
        for (var page = 0; page < totalPages; page++) {\
            if (page > 0) pdf.addPage();\
            var cropY = position;\
            var cropHeight = Math.min(contentHeight / ratio, imgHeight - position / ratio);\
            var canvasCrop = document.createElement("canvas");\
            canvasCrop.width = imgWidth;\
            canvasCrop.height = cropHeight * ratio;\
            var ctx = canvasCrop.getContext("2d");\
            ctx.drawImage(canvas, 0, cropY / ratio, imgWidth, cropHeight, 0, 0, imgWidth, cropHeight * ratio);\
            var imgDataCrop = canvasCrop.toDataURL("image/png");\
            pdf.addImage(imgDataCrop, "PNG", imgX, margin, imgWidth * ratio, cropHeight * ratio);\
            position += contentHeight;\
        }\
        pdf.save("Laporan_Hasil_Pengawasan_"+new Date().toISOString().slice(0,10)+".pdf");\
        showToast("📄 PDF F4 berhasil di-download!", "success");\
    }).catch(function(err) {\
        console.error(err);\
        showToast("❌ Gagal generate PDF", "error");\
    });\
}' form_a.php

echo "✅ Dokumentasi: halaman terpisah, auto convert, ukuran foto sama!"
