<?php
require_once 'config/database.php';
require_once 'config/auth.php';

// Hanya Super Admin yang bisa akses
if (!hasRole('super_admin')) {
    header('Location: dashboard.php');
    exit;
}

$message = '';
$messageType = '';

// Load config saat ini
$configFile = '/www/wwwroot/eform/config/mail_config.php';
$configContent = file_get_contents($configFile);

// Ambil nilai config saat ini
preg_match("/define\('MAIL_USERNAME', '([^']+)'\);/", $configContent, $mailUsername);
preg_match("/define\('MAIL_PASSWORD', '([^']+)'\);/", $configContent, $mailPassword);
preg_match("/define\('MAIL_FORGOT_PASSWORD_TO', '([^']+)'\);/", $configContent, $mailForgotTo);
preg_match("/define\('MAIL_FROM_NAME', '([^']+)'\);/", $configContent, $mailFromName);

$currentUsername = $mailUsername[1] ?? 'nurakreasidigital@gmail.com';
$currentPassword = $mailPassword[1] ?? '';
$currentForgotTo = $mailForgotTo[1] ?? 'nurakreasidigital@gmail.com';
$currentFromName = $mailFromName[1] ?? 'E-Form System';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUsername = trim($_POST['mail_username'] ?? '');
    $newPassword = trim($_POST['mail_password'] ?? '');
    $newForgotTo = trim($_POST['mail_forgot_to'] ?? '');
    $newFromName = trim($_POST['mail_from_name'] ?? 'E-Form System');

    if (empty($newUsername) || empty($newPassword) || empty($newForgotTo)) {
        $message = '⚠️ Semua field wajib diisi!';
        $messageType = 'error';
    } else {
        // Backup config lama
        copy($configFile, $configFile . '.backup_' . date('Ymd_His'));

        // Tulis config baru
        $newConfig = "<?php\n";
        $newConfig .= "// ============================================================\n";
        $newConfig .= "// KONFIGURASI EMAIL\n";
        $newConfig .= "// ============================================================\n\n";
        $newConfig .= "// Email pengirim (SMTP)\n";
        $newConfig .= "define('MAIL_USERNAME', '" . addslashes($newUsername) . "');\n";
        $newConfig .= "define('MAIL_PASSWORD', '" . addslashes($newPassword) . "');\n";
        $newConfig .= "define('MAIL_FROM_NAME', '" . addslashes($newFromName) . "');\n\n";
        $newConfig .= "// Email tujuan NOTIFIKASI LUPA PASSWORD (Admin/Super Admin)\n";
        $newConfig .= "define('MAIL_FORGOT_PASSWORD_TO', '" . addslashes($newForgotTo) . "');\n\n";
        $newConfig .= "// SMTP Server\n";
        $newConfig .= "define('MAIL_HOST', 'smtp.gmail.com');\n";
        $newConfig .= "define('MAIL_PORT', 587);\n";
        $newConfig .= "define('MAIL_ENCRYPTION', 'tls');\n";
        $newConfig .= "?>\n";

        if (file_put_contents($configFile, $newConfig)) {
            $message = '✅ Setting email berhasil diupdate!';
            $messageType = 'success';
            
            // Refresh nilai
            $currentUsername = $newUsername;
            $currentPassword = $newPassword;
            $currentForgotTo = $newForgotTo;
            $currentFromName = $newFromName;
        } else {
            $message = '❌ Gagal menyimpan config!';
            $messageType = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setting Email - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .container { max-width: 650px; margin: 0 auto; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 4px; color: #1A1A2E; font-size: 13px; }
        .form-group input { width: 100%; padding: 8px 12px; border: 1.5px solid #DDE3F0; border-radius: 8px; font-size: 14px; font-family: inherit; }
        .form-group input:focus { border-color: #E53935; outline: none; }
        .alert { padding: 10px 14px; border-radius: 8px; margin-bottom: 14px; }
        .alert-success { background: #EEFAF4; color: #1A7A45; border: 1px solid #B6E8CF; }
        .alert-error { background: #FFE5E5; color: #C62828; border: 1px solid #FFB3B3; }
        .btn { padding: 10px 24px; border-radius: 8px; font-weight: 700; cursor: pointer; border: none; font-size: 14px; transition: 0.2s; }
        .btn-primary { background: #E53935; color: #fff; }
        .btn-primary:hover { background: #c62828; }
        .btn-secondary { background: #6B7A99; color: #fff; }
        .btn-secondary:hover { background: #5a6a89; }
        .info-box { background: #F0F4FF; border: 1px solid #C3D4F9; border-radius: 8px; padding: 12px 14px; font-size: 13px; color: #2D5BE3; margin-bottom: 16px; }
        .info-box strong { display: block; margin-bottom: 4px; }
        .info-box ol { margin: 6px 0 0 20px; padding: 0; }
        .info-box ol li { margin-bottom: 4px; }
        .role-badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; background: #FFD700; color: #1A1A2E; }
    </style>
</head>
<body>
    <div class="app">
        <?php include "sidebar.php"; ?>
        <main class="main">
            <div class="container">
                <header class="topbar">
                    <div class="topbar-left">
                        <button class="hamburger" onclick="toggleSidebar()">☰</button>
                        <h2>⚙️ Setting Email</h2>
                    </div>
                    <div class="topbar-right">
                        <span class="user-badge">👤 <?= htmlspecialchars($_SESSION['fullname']) ?> <span class="role-badge">SUPER ADMIN</span></span>
                    </div>
                </header>

                <?php if ($message): ?>
                <div class="alert alert-<?= $messageType ?>"><?= $message ?></div>
                <?php endif; ?>

                <div class="info-box">
                    <strong>📌 Cara Mendapatkan Password App Gmail:</strong>
                    <ol>
                        <li>Login ke <a href="https://myaccount.google.com/apppasswords" target="_blank">Google App Passwords</a></li>
                        <li>Pilih <strong>Mail</strong> dan <strong>Other (Custom name)</strong></li>
                        <li>Isi nama: <strong>E-Form System</strong></li>
                        <li>Klik <strong>Generate</strong></li>
                        <li>Copy password yang muncul (contoh: <code>xxxx xxxx xxxx xxxx</code>)</li>
                    </ol>
                </div>

                <div class="card">
                    <div class="card-header"><h3>📧 Konfigurasi Email</h3></div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="form-group">
                                <label>Email Pengirim (SMTP Username)</label>
                                <input type="email" name="mail_username" value="<?= htmlspecialchars($currentUsername) ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Password App Gmail</label>
                                <input type="text" name="mail_password" value="<?= htmlspecialchars($currentPassword) ?>" required>
                                <div style="font-size:11px;color:#6B7A99;margin-top:4px;">💡 Password App (bukan password biasa), dapatkan dari Google App Passwords</div>
                            </div>

                            <div class="form-group">
                                <label>Nama Pengirim</label>
                                <input type="text" name="mail_from_name" value="<?= htmlspecialchars($currentFromName) ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Email Tujuan Lupa Password (Admin)</label>
                                <input type="email" name="mail_forgot_to" value="<?= htmlspecialchars($currentForgotTo) ?>" required>
                                <div style="font-size:11px;color:#6B7A99;margin-top:4px;">💡 Email yang akan menerima notifikasi permintaan reset password</div>
                            </div>

                            <button type="submit" class="btn btn-primary">💾 Simpan Setting</button>
                            <a href="dashboard.php" class="btn btn-secondary">← Kembali</a>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="assets/js/main.js"></script>
</body>
</html>
