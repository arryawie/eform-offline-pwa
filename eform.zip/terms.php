<?php
require_once 'config/database.php';
require_once 'config/auth.php';
$page_title = 'Syarat & Ketentuan';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .legal-container { max-width: 800px; margin: 40px auto; padding: 30px; background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .legal-container h1 { color: #1A1A2E; border-bottom: 2px solid #E53935; padding-bottom: 12px; }
        .legal-container h2 { color: #2D5BE3; margin-top: 24px; font-size: 16px; }
        .legal-container p, .legal-container li { color: #333; line-height: 1.8; font-size: 14px; }
        .legal-container ul { padding-left: 20px; }
        .last-updated { color: #6B7A99; font-size: 12px; margin-top: 30px; border-top: 1px solid #DDE3F0; padding-top: 16px; }
        .btn-back { display: inline-block; padding: 8px 20px; background: #E53935; color: #fff; border-radius: 6px; text-decoration: none; margin-bottom: 16px; }
        .btn-back:hover { background: #c62828; }
    </style>
</head>
<body>
    <?php include "sidebar.php"; ?>
    <div class="app">
        <main class="main">
            <div class="legal-container">
                <a href="dashboard.php" class="btn-back">← Kembali</a>
                <h1>📋 Syarat & Ketentuan</h1>
                <p class="last-updated">Terakhir diperbarui: <?= date('d F Y') ?></p>

                <h2>1. Penerimaan Syarat</h2>
                <p>Dengan menggunakan E-Form System, Anda menyetujui syarat dan ketentuan yang berlaku.</p>

                <h2>2. Hak dan Kewajiban Pengguna</h2>
                <ul>
                    <li>Pengguna bertanggung jawab atas akun dan data yang diinput.</li>
                    <li>Pengguna tidak diperbolehkan menyalahgunakan sistem untuk hal ilegal.</li>
                </ul>

                <h2>3. Keamanan Data</h2>
                <ul>
                    <li>Data pengguna dilindungi dengan enkripsi dan akses terbatas.</li>
                    <li>Pengguna wajib menjaga kerahasiaan password.</li>
                </ul>

                <h2>4. Hak Kekayaan Intelektual</h2>
                <p>Seluruh source code, desain, dan fitur sistem adalah hak milik PT. Nura Kreasi Digital.</p>

                <h2>5. Pembatasan Tanggung Jawab</h2>
                <p>Kami tidak bertanggung jawab atas kerugian akibat force majeure atau penyalahgunaan sistem oleh pihak ketiga.</p>

                <h2>6. Pengakhiran</h2>
                <p>Kami berhak menghentikan akses pengguna jika melanggar ketentuan yang berlaku.</p>

                <h2>7. Perubahan Syarat</h2>
                <p>Kami dapat mengubah syarat dan ketentuan sewaktu-waktu. Pengguna akan diberitahu melalui email atau notifikasi.</p>

                <div class="last-updated">© <?= date('Y') ?> <?= APP_NAME ?> - PT. Nura Kreasi Digital</div>
            </div>
        </main>
    </div>
</body>
</html>
