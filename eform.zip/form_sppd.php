<?php
// ============================================================
// FORM SPPD - Surat Perintah Perjalanan Dinas
// ============================================================
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

$form_key = 'form_sppd';
$form_title = 'Form SPPD - Surat Perintah Perjalanan Dinas';

if (!canAccessForm($form_key)) {
    die("<h1>⛔ Akses Ditolak</h1><p>Anda tidak memiliki akses ke form ini.</p><a href='dashboard.php'>← Kembali</a>");
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? 'user';

// Cek apakah user Super Admin atau Admin
if (in_array($role, ['super_admin', 'admin'])) {
    // Ambil form milik user tersebut
    $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id = ?");
    $stmt->execute([$form_key, $user_id]);
    $form = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$form) {
        // Buat form default untuk user
        $stmt = $pdo->prepare("INSERT INTO forms (form_key, form_name, user_id, is_active) VALUES (?, ?, ?, 1)");
        $stmt->execute([$form_key, $form_title, $user_id]);
        
        $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id = ?");
        $stmt->execute([$form_key, $user_id]);
        $form = $stmt->fetch(PDO::FETCH_ASSOC);
    }
} else {
    // User: ambil dari admin yang membuatnya (created_by)
    $stmt = $pdo->prepare("SELECT created_by FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($userData && $userData['created_by']) {
        $adminId = $userData['created_by'];
        $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id = ?");
        $stmt->execute([$form_key, $adminId]);
        $form = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    if (!$form) {
        // Fallback: ambil form default (user_id NULL)
        $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id IS NULL");
        $stmt->execute([$form_key]);
        $form = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

$kop_logo = $form['kop_logo'] ?? '';
$kop_instansi = $form['kop_instansi'] ?? 'BADAN PENGAWAS PEMILIHAN UMUM';
$kop_alamat = $form['kop_alamat'] ?? '';
$kop_telp = $form['kop_telp'] ?? '';
$kop_email = $form['kop_email'] ?? '';

if (!$form || $form['is_active'] != 1) {
    die("<h1>⚠️ Form sedang tidak aktif</h1>");
}

$kop_logo = $form['kop_logo'] ?? '';
$kop_instansi = $form['kop_instansi'] ?? 'BADAN PENGAWAS PEMILIHAN UMUM';
$kop_alamat = $form['kop_alamat'] ?? '';
$kop_telp = $form['kop_telp'] ?? '';
$kop_email = $form['kop_email'] ?? '';

$submissions = $pdo->prepare("
    SELECT s.*, f.form_name, f.icon 
    FROM form_submissions s 
    JOIN forms f ON s.form_id = f.id 
    WHERE s.user_id = ? AND f.form_key = ? 
    ORDER BY s.created_at DESC 
    LIMIT 20
");
$submissions->execute([$_SESSION['user_id'], $form_key]);
$submissionList = $submissions->fetchAll(PDO::FETCH_ASSOC);

// Ambil submission_id terbaru
$submission_id = 0; // ← Jangan auto-ambil dari database

// ===== FIELD SPPD SESUAI PDF =====
$fields = [
    ['id' => 'ditujukan', 'label' => 'Yth', 'type' => 'text', 'placeholder' => 'tujuan laporan'],
    ['id' => 'dari', 'label' => 'Dari', 'type' => 'text', 'placeholder' => 'Nama Pelaksana'],
    ['id' => 'jabatan_pelaksana', 'label' => 'Jabatan', 'type' => 'text', 'placeholder' => 'jabatan pelaksana'],
    ['id' => 'hari_tanggal', 'label' => 'Hari, Tanggal', 'type' => 'text', 'placeholder' => 'tanggal pelaksanaan'],
    ['id' => 'waktu', 'label' => 'Waktu', 'type' => 'text', 'placeholder' => 'waktu pelaksanaan'],
    ['id' => 'tempat', 'label' => 'Tempat', 'type' => 'text', 'placeholder' => 'tempat pelaksanaan'],
    ['id' => 'acara', 'label' => 'Acara', 'type' => 'text', 'placeholder' => 'accara  '],
    ['id' => 'dasar', 'label' => 'Dasar', 'type' => 'text', 'placeholder' => 'nomor surat tugas'],
    ['id' => 'hasil_tugas', 'label' => 'Hasil Tugas', 'type' => 'textarea', 'rows' => 12],
    ['id' => 'temuan', 'label' => 'Temuan', 'type' => 'textarea', 'rows' => 4],
    ['id' => 'tindak_lanjut', 'label' => 'Tindak Lanjut', 'type' => 'textarea', 'rows' => 4],
    ['id' => 'penutup', 'label' => 'Penutup', 'type' => 'textarea', 'rows' => 3],
    ['id' => 'ttd_kota', 'label' => 'Kota', 'type' => 'text', 'placeholder' => 'kota/kec'],
    ['id' => 'ttd_tgl', 'label' => 'Tanggal TTD', 'type' => 'date'],
    ['id' => 'ttd_jabatan', 'label' => 'Jabatan Penandatangan', 'type' => 'text', 'placeholder' => 'jabatab'],
    ['id' => 'ttd_nama', 'label' => 'Nama Penandatangan', 'type' => 'text', 'placeholder' => 'nama'],
    ['id' => 'foto_judul', 'label' => 'Judul Dokumentasi', 'type' => 'text', 'placeholder' => 'judul'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $form_title ?> - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <style>
        * { box-sizing: border-box; }
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; margin:0; }
        .form-container { max-width: 900px; margin: 0 auto; padding: 20px; }
        .topbar { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; background: #fff; padding: 15px 20px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .topbar h2 { margin: 0; font-size: 18px; color: #1A1A2E; }
        .tab-bar { display: flex; gap: 4px; background: #fff; border-radius: 12px; padding: 4px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); flex-wrap:wrap; }
        .tab-btn { padding: 10px 24px; border: none; border-radius: 8px; background: transparent; font-weight: 600; cursor: pointer; color: #6B7A99; transition: 0.2s; font-size: 14px; }
        .tab-btn.active { background: #E53935; color: #fff; }
        .tab-btn:hover:not(.active) { background: #f0f0f0; }
        .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); margin-bottom: 16px; overflow: hidden; }
        .card-header { padding: 12px 20px; background: #f8f9fc; border-bottom: 1px solid #eee; font-weight: 700; color: #1A1A2E; font-size: 14px; }
        .card-body { padding: 16px 20px; }
        .form-group { margin-bottom: 12px; }
        .form-group label { display: block; font-weight: 600; font-size: 13px; color: #2c3e50; margin-bottom: 4px; }
        .form-group label .req { color: #E53935; }
        .form-group input, .form-group textarea, .form-group select { width: 100%; padding: 8px 12px; border: 1.5px solid #DDE3F0; border-radius: 8px; font-size: 14px; font-family: inherit; transition: 0.2s; background: #fff; }
        .form-group input:focus, .form-group textarea:focus { border-color: #E53935; outline: none; box-shadow: 0 0 0 3px rgba(229,57,53,0.1); }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
        .btn { padding: 8px 20px; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 13px; transition: 0.2s; text-decoration: none; display: inline-block; }
        .btn-primary { background: #E53935; color: #fff; }
        .btn-primary:hover { background: #c62828; }
        .btn-secondary { background: #6B7A99; color: #fff; }
        .btn-secondary:hover { background: #5a6a89; }
        .btn-success { background: #2E7D32; color: #fff; }
        .btn-success:hover { background: #1B5E20; }
        .btn-outline { background: transparent; color: #E53935; border: 1.5px solid #E53935; }
        .btn-outline:hover { background: #FFF5F5; }
        .btn-sm { padding: 4px 12px; font-size: 12px; }
        .btn-row { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 16px; }
        .btn-row .btn { flex: 1; min-width: 100px; text-align: center; }
        .alert { padding: 10px 16px; border-radius: 8px; margin-bottom: 12px; font-size: 13px; }
        .alert-info { background: #EEF4FF; color: #2D5BE3; border: 1px solid #C3D4F9; }
        .photo-zone { border: 2px dashed #DDE3F0; border-radius: 8px; padding: 16px; text-align: center; cursor: pointer; transition: 0.2s; background: #FAFBFD; }
        .photo-zone:hover { border-color: #E53935; background: #FFF5F5; }
        .photo-zone input { display: none; }
        .photo-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 10px; margin-top: 10px; }
        .photo-item { position: relative; border-radius: 8px; overflow: hidden; aspect-ratio: 4/3; border: 1.5px solid #DDE3F0; background: #f0f0f0; }
        .photo-item img { width: 100%; height: 100%; object-fit: cover; }
        .photo-item .caption-input { position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0,0,0,0.6); padding: 4px 7px; border: none; color: #fff; font-size: 10px; font-family: inherit; width: 100%; outline: none; }
        .photo-item .remove-btn { position: absolute; top: 4px; right: 4px; width: 22px; height: 22px; background: rgba(229,57,53,0.85); border: none; border-radius: 50%; color: #fff; font-size: 12px; cursor: pointer; }
        .status-badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
        .status-badge.draft { background: #EEF0F6; color: #6B7A99; }
        .status-badge.previewed { background: #EEF4FF; color: #2D5BE3; }
        .status-badge.downloaded { background: #EEFAF4; color: #1A7A45; }
        .status-badge.submitted { background: #FFFBEE; color: #B07A00; }
        .status-badge.approved { background: #EEFAF4; color: #1A7A45; }
        .status-badge.rejected { background: #FFE5E5; color: #C62828; }
        .submission-table { width: 100%; border-collapse: collapse; font-size: 12px; }
        .submission-table th { text-align: left; padding: 6px 8px; background: #F8F9FC; color: #6B7A99; font-weight: 700; font-size: 11px; text-transform: uppercase; border-bottom: 2px solid #DDE3F0; }
        .submission-table td { padding: 6px 8px; border-bottom: 1px solid #EEF0F6; vertical-align: middle; }
        .submission-table tr:hover { background: #FAFBFD; }
        .btn-edit { background: #2D5BE3; color: #fff; border: none; padding: 2px 10px; border-radius: 4px; font-size: 11px; cursor: pointer; }
        .btn-edit:hover { background: #1A3F8A; }
        .btn-preview { background: #F5A623; color: #fff; border: none; padding: 2px 10px; border-radius: 4px; font-size: 11px; cursor: pointer; }
        .btn-preview:hover { background: #d4911a; }
        .btn-delete { background: #dc3545; color: #fff; border: none; padding: 2px 10px; border-radius: 4px; font-size: 11px; cursor: pointer; }
        .btn-delete:hover { background: #b02a37; }
        #previewArea { background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); overflow: hidden; }
        .preview-toolbar { background: #f8f9fc; padding: 12px 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; }
        .preview-content { padding: 20px; max-height: 700px; overflow-y: auto; }
        .pdf-page { background: #fff; padding: 30px 35px; max-width: 680px; margin: 0 auto 16px; font-family: 'Times New Roman', serif; font-size: 10.5pt; line-height: 1.6; border: 1px solid #ddd; border-radius: 4px; }
        .pdf-page .kop { text-align: center; margin-bottom: 12px; border-bottom: 2px solid #1A1A2E; padding-bottom: 10px; }
        .pdf-page .kop img { max-height: 60px; width: auto; }
        .pdf-page .kop .instansi { font-size: 13pt; font-weight: 700; color: #1A1A2E; }
        .pdf-page .kop .alamat { font-size: 8.5pt; color: #666; }
        .pdf-title { font-size: 12pt; font-weight: 700; text-align: center; text-transform: uppercase; }
        .pdf-subtitle { font-size: 11pt; font-weight: 700; text-align: center; text-transform: uppercase; margin-bottom: 4px; }
        .pdf-section { font-weight: 700; font-size: 11pt; margin: 10px 0 4px; }
        .pdf-tbl { width: 100%; border-collapse: collapse; font-size: 10pt; margin: 4px 0; }
        .pdf-tbl td { border: 1px solid #444; padding: 4px 8px; vertical-align: top; }
        .pdf-tbl .label-col { width: 160px; font-weight: 600; }
        .pdf-tbl .sep-col { width: 14px; text-align: center; }
        .pdf-ttd { text-align: center; margin-top: 20px; }
        .pdf-ttd .nama { font-weight: 700; text-decoration: underline; display: block; margin-top: 40px; }
        .pdf-ttd .jabatan { font-weight: 600; display: block; }
        .pdf-foto-title { text-align: center; font-weight: 700; font-size: 11pt; margin: 12px 0 8px; }
        .pdf-foto-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .pdf-foto-item img { width: 100%; border: 1px solid #ccc; border-radius: 4px; }
        .pdf-foto-item p { text-align: center; font-size: 8.5pt; margin-top: 3px; font-style: italic; color: #555; }
        .pdf-page .ql-editor { padding: 0 !important; font-family: 'Times New Roman', serif; font-size: 10.5pt; line-height: 1.6; text-align: justify; overflow: visible; }
        .pdf-page .ql-editor p { margin: 0 0 6px; }
        .pdf-page .ql-editor ol, .pdf-page .ql-editor ul { margin: 2px 0 8px; padding-left: 0; }
        .pdf-page .ql-editor li { margin-bottom: 3px; }
        .ql-editor table, .ql-editor table.ql-table { border-collapse: collapse; width: 100%; margin: 8px 0; table-layout: fixed; }
        .ql-editor table td, .ql-editor table th { border: 1px solid #444; padding: 5px 7px; vertical-align: top; text-align: left; font-size: 10pt; min-width: 40px; word-wrap: break-word; }
        .ql-editor table th { background: #f0f0f0; font-weight: 700; }
        .pdf-page .ql-editor table td, .pdf-page .ql-editor table th { font-size: 9.5pt; }
        .ql-toolbar .ql-insertTable { width: 30px; }
        .ql-toolbar .ql-insertTable .ql-table-icon { font-size: 15px; line-height: 1; }
        /* Placeholder halus untuk sel tabel kosong (hanya saat mengedit, tidak ikut tercetak) */
        .ql-editor table.ql-table th:empty::before { content: 'Judul kolom'; color: #b3bacb; font-style: italic; font-weight: 400; }
        .ql-editor table.ql-table td:empty::before { content: 'Isi sel'; color: #c3c9d8; font-style: italic; }
        .pdf-page .ql-editor table.ql-table th:empty::before,
        .pdf-page .ql-editor table.ql-table td:empty::before { content: '' !important; }
        /* Kursor tarik-ubah untuk resize kolom/baris tabel */
        .ql-editor table.ql-table td, .ql-editor table.ql-table th { position: relative; }
        body.rt-col-resizing, body.rt-col-resizing * { cursor: col-resize !important; }
        body.rt-row-resizing, body.rt-row-resizing * { cursor: row-resize !important; }
        .app { display: flex; min-height: 100vh; }
        .sidebar { width: 240px; background: #1A1A2E; color: #fff; padding: 20px; flex-shrink: 0; }
        .sidebar-brand { font-size: 20px; font-weight: 700; margin-bottom: 30px; }
        .sidebar-nav a { display: block; padding: 10px 12px; color: rgba(255,255,255,0.7); text-decoration: none; border-radius: 8px; margin-bottom: 4px; transition: 0.2s; }
        .sidebar-nav a:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .sidebar-nav .logout { color: #E53935; margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 16px; }
        .main { flex: 1; padding: 20px; background: #f0f2f5; }
        .hamburger { display: none; background: none; border: none; font-size: 24px; cursor: pointer; }
        .user-badge { background: rgba(0,0,0,0.08); padding: 4px 12px; border-radius: 20px; font-size: 13px; }
        .ql-editor { min-height: 200px; font-size: 14px; }
        @media (max-width: 768px) { .sidebar { display: none; } .sidebar.open { display: block; position: fixed; top: 0; left: 0; height: 100%; z-index: 1000; width: 260px; } .hamburger { display: block; } .main { padding: 10px; } .grid-2, .grid-3 { grid-template-columns: 1fr; } .btn-row { flex-direction: column; } .pdf-page { padding: 15px; } }
    </style>
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">📋 E-Form</div>
        <nav class="sidebar-nav">
            <a href="dashboard.php">📊 Dashboard</a>
            <?php if (hasRole('super_admin') || hasRole('admin')): ?>
            <a href="admin_users.php">👥 Manajemen User</a>
            <a href="forms.php">📝 Manajemen Form</a>
            <?php endif; ?>
            <a href="notifications.php">🔔 Notifikasi</a>
            <a href="profile.php">⚙️ Profile</a>
            <a href="logout.php" class="logout">🚪 Logout</a>
        </nav>
    </aside>
    <main class="main">
        <div class="form-container">
            <div class="topbar">
                <div style="display:flex;align-items:center;gap:10px;">
                    <button class="hamburger" onclick="toggleSidebar()">☰</button>
                    <h2>📋 <?= $form_title ?></h2>
                </div>
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <span class="user-badge">👤 <?= htmlspecialchars($_SESSION['fullname']) ?></span>
                    <a href="dashboard.php" class="btn btn-secondary btn-sm" style="padding:4px 12px;font-size:12px;">← Kembali</a>
                </div>
            </div>

            <div class="tab-bar">
                <button class="tab-btn active" onclick="switchTab('form')">📝 Form</button>
                <button class="tab-btn" onclick="switchTab('preview')">👁 Preview</button>
                <button class="tab-btn" onclick="switchTab('riwayat')">📋 Riwayat</button>

            </div>

            <!-- TAB FORM -->
            <div id="tabForm">
                <div class="alert alert-info">ℹ️ Isi data lengkap. Klik <strong>Preview</strong> untuk melihat hasil dokumen.</div>
                <div id="formContainer">

                <?php foreach ($fields as $field): ?>
                    <?php if ($field['type'] === 'textarea'): ?>
                    <div class="card">
                        <div class="card-header">📝 <?= $field['label'] ?></div>
                        <div class="card-body">
                            <div class="form-group">
                                <label><?= $field['label'] ?> <span class="req">*</span></label>
                                <div id="editor_<?= $field['id'] ?>" style="height: <?= ($field['rows'] ?? 4) * 30 ?>px; border: 1px solid #DDE3F0; border-radius: 8px;"></div>
                                <input type="hidden" id="<?= $field['id'] ?>" name="<?= $field['id'] ?>">
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="card">
                        <div class="card-header">📌 <?= $field['label'] ?></div>
                        <div class="card-body">
                            <div class="form-group">
                                <label><?= $field['label'] ?> <span class="req">*</span></label>
                                <input type="<?= $field['type'] === 'date' ? 'date' : 'text' ?>" id="<?= $field['id'] ?>" placeholder="<?= $field['placeholder'] ?? '' ?>">
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; ?>

                <!-- DOKUMENTASI -->
                <div class="card">
                    <div class="card-header">📸 Dokumentasi</div>
                    <div class="card-body">
                        <div class="photo-zone" onclick="document.getElementById('photoInput').click()">
                            <input type="file" id="photoInput" accept="image/*" multiple onchange="addPhotos(event)">
                            <div style="font-size:28px;">📷</div>
                            <p>Tap untuk pilih foto</p>
                            <small>JPG, PNG</small>
                        </div>
                        <div class="photo-grid" id="photoGrid"></div>
                    </div>
                </div>

                <!-- BUTTONS -->
                <div class="btn-row">
                    <button class="btn btn-outline" onclick="resetForm()">🗑 Reset</button>
                    <button class="btn btn-secondary" onclick="saveDraft()">💾 Simpan Draf</button>
                    <button class="btn btn-primary" onclick="preview()">👁 Preview</button>
                    <button class="btn btn-success" onclick="downloadPDF()">⬇ Download PDF</button>
                    
                    <?php if ($submission_id > 0): ?>
                        <?php 
                            $stmt = $pdo->prepare("SELECT status FROM form_submissions WHERE id = ?");
                            $stmt->execute([$submission_id]);
                            $submissionStatus = $stmt->fetchColumn();
                        ?>
                        <?php if (in_array($submissionStatus, ['draft', 'rejected', null])): ?>
                            <!-- <button class="btn btn-primary" onclick="submitForm()">📤 Kirim</button> -->
                        <?php elseif ($submissionStatus === 'submitted'): ?>
                            <button class="btn btn-warning" disabled style="opacity:0.7;">⏳ Menunggu Verifikasi</button>
                        <?php elseif ($submissionStatus === 'approved'): ?>
                            <button class="btn btn-success" disabled>✅ Disetujui</button>
                        <?php elseif ($submissionStatus === 'rejected'): ?>
                            <button class="btn btn-danger" disabled>❌ Ditolak</button>
                            <?php 
                                $stmt = $pdo->prepare("SELECT admin_note FROM form_submissions WHERE id = ?");
                                $stmt->execute([$submission_id]);
                                $note = $stmt->fetchColumn();
                            ?>
                            <?php if ($note): ?>
                                <small style="color:#C62828;display:block;margin-top:4px;">Catatan: <?= htmlspecialchars($note) ?></small>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
</div>

                </div><!-- end formContainer -->
            </div><!-- end tabForm -->

            <!-- TAB PREVIEW -->
            <div id="tabPreview" style="display:none;">
                <div id="previewArea">
                    <div class="preview-toolbar">
                        <span>👁 Preview Dokumen</span>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            <button class="btn btn-outline btn-sm" onclick="switchTab('form')">← Edit</button>
                            <button class="btn btn-primary btn-sm" onclick="downloadPDF()">⬇ Download PDF</button>
                        </div>
                    </div>
                    <div class="preview-content">
                        <div id="previewDoc">
                            <p style="text-align:center;color:#9AA6C0;padding:40px 0;">Isi form lalu klik <strong>Preview</strong></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB RIWAYAT -->
            <div id="tabRiwayat" style="display:none;">
                <div class="card">
                    <div class="card-header">📋 Riwayat Submission</div>
                    <div class="card-body" id="riwayatContent">
                        <?php if (empty($submissionList)): ?>
                            <p style="text-align:center;color:#6B7A99;padding:20px;">Belum ada submission</p>
                        <?php else: ?>
                        <table class="submission-table">
                            <thead><tr><th>#</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead>
                            <tbody>
                            <?php $no=1; foreach ($submissionList as $s):
                                $statusLabel = ['draft'=>'📝 Draf','previewed'=>'👁 Preview','downloaded'=>'⬇ Downloaded','submitted'=>'📤 submitted','approved'=>'✅ Diterima','rejected'=>'❌ Ditolak'][$s['status']] ?? $s['status'];
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($s['created_at'])) ?></td>
                                <td><span class="status-badge <?= $s['status'] ?>"><?= $statusLabel ?></span></td>
                                <td>
                                    <button class="btn-edit" onclick="editSubmission(<?= $s['id'] ?>)">✏️ Edit</button>
                                    <button class="btn-preview" onclick="previewSubmission(<?= $s['id'] ?>)">👁 Preview</button>
                                    <button class="btn-delete" onclick="deleteSubmission(<?= $s['id'] ?>)">🗑 Hapus</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div><!-- form-container -->
    </main>
</div>

<script>
// ================================================================
// STATE
// ================================================================
var STORAGE_KEY = 'form_sppd_draft';
var photos = [];
var submissionId = null;
var quills = {};
var isSaving = false;  // ✅ TAMBAHKAN INI!
var userId = <?= $_SESSION['user_id'] ?>;  // ← TAMBAHKAN INI!


// ================================================================
// SIDEBAR TOGGLE
// ================================================================
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

// ================================================================
// PHOTOS
// ================================================================
function addPhotos(e) {
    var files = Array.from(e.target.files);
    files.forEach(function(file) {
        var reader = new FileReader();
        reader.onload = function(ev) {
            compressPhoto(ev.target.result, 0.5, function(compressedSrc) {
                photos.push({ src: compressedSrc, caption: '' });
                renderPhotos();
                // ✅ SAVE DRAFT DIHAPUS! User harus klik tombol manual
            });
        };
        reader.readAsDataURL(file);
    });
    e.target.value = '';
}

// Kompres foto dokumentasi ke kualitas 50% (JPEG quality 0.5) via canvas.
// Hanya dipakai saat upload foto, TIDAK dipakai saat generate PDF,
// supaya kualitas hasil PDF tidak ikut berubah.
function compressPhoto(dataUrl, quality, callback) {
    var img = new Image();
    img.onload = function() {
        var canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        var ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        try {
            var compressed = canvas.toDataURL('image/jpeg', quality);
            callback(compressed);
        } catch (err) {
            // Fallback: kalau gagal (misal gambar dari sumber lain), pakai versi asli
            callback(dataUrl);
        }
    };
    img.onerror = function() { callback(dataUrl); };
    img.src = dataUrl;
}

function renderPhotos() {
    var grid = document.getElementById('photoGrid');
    grid.innerHTML = '';
    photos.forEach(function(p, i) {
        var div = document.createElement('div');
        div.className = 'photo-item';
        div.innerHTML = '<img src="' + p.src + '"><input class="caption-input" placeholder="Keterangan..." value="' + (p.caption||'') + '" onchange="photos['+i+'].caption=this.value;"><button class="remove-btn" onclick="removePhoto('+i+')">✕</button>';
        // ✅ SAVE DRAFT DIHAPUS DARI ONCHANGE!
        grid.appendChild(div);
    });
}

function removePhoto(i) {
    photos.splice(i,1);
    renderPhotos();
    // ✅ SAVE DRAFT DIHAPUS!
}
// ================================================================
// GET ALL DATA
// ================================================================
function getAllData() {
    var fields = document.querySelectorAll('#formContainer input, #formContainer textarea, #formContainer select');
    var data = {};
    fields.forEach(function(el) {
        if (el.id) {
            if (el.type === 'checkbox') data[el.id] = el.checked;
            else data[el.id] = el.value;
        }
    });
    for (var key in quills) {
        if (quills[key]) {
            data[key] = quills[key].root.innerHTML;
        }
    }
    data.photos = photos;
    return data;
}

function saveDraft() {
    if (isSaving) {
        showToast('⏳ Sedang menyimpan, tunggu...', 'warning');
        return;
    }
    
    isSaving = true;
    var btns = document.querySelectorAll('.btn-secondary, .btn-primary, .btn-outline');
    btns.forEach(function(btn) {
        btn.disabled = true;
        btn.style.opacity = '0.5';
        btn.style.cursor = 'not-allowed';
    });
    
    showToast('💾 Menyimpan draft...', 'info', true);
    
    try {
        var data = getAllData();
        data.status = 'draft';
        data.updated_at = new Date().toISOString();
        
        // Simpan ke LOCAL STORAGE
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        
        // ✅ HAPUS saveToHistory(data) DI SINI!
        
        var payload = {
            form_key: 'form_sppd',
            status: 'draft',
            submission_id: submissionId || 0,
            timestamp: data.updated_at
        };
        
        fetch('api/save_status.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(function(res) { 
            if (!res.ok) throw new Error('Network error');
            return res.json(); 
        })
        .then(function(result) {
            isSaving = false;
            btns.forEach(function(btn) {
                btn.disabled = false;
                btn.style.opacity = '1';
                btn.style.cursor = 'pointer';
            });
            
            if (result.success) {
                submissionId = result.submission_id;
                var draft = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
                draft.submission_id = result.submission_id;
                localStorage.setItem(STORAGE_KEY, JSON.stringify(draft));
                
                saveToHistory(draft);  // ✅ HANYA DI SINI!
                
                showToast('✅ Draft berhasil disimpan!', 'success');
            } else {
                showToast('⚠️ ' + (result.message || 'Gagal update status'), 'warning');
            }
        })
        .catch(function(err) {
            isSaving = false;
            btns.forEach(function(btn) {
                btn.disabled = false;
                btn.style.opacity = '1';
                btn.style.cursor = 'pointer';
            });
            showToast('⚠️ Data tersimpan lokal', 'warning');
            console.error('Save status error:', err);
        });
        
    } catch (error) {
        isSaving = false;
        btns.forEach(function(btn) {
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
        });
        showToast('❌ Gagal menyimpan: ' + error.message, 'error');
        console.error('Save error:', error);
    }
}

// ================================================================
// LOAD DRAFT
// ================================================================
function loadDraft() {
    try {
        var saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
            var data = JSON.parse(saved);
            for (var key in data) {
                if (key === 'photos') { photos = data.photos || []; renderPhotos(); continue; }
                if (quills[key] && data[key]) {
                    quills[key].root.innerHTML = data[key];
                    continue;
                }
                var el = document.getElementById(key);
                if (el) {
                    if (el.type === 'checkbox') el.checked = data[key] === true;
                    else el.value = data[key] || '';
                }
            }
            if (data.submission_id) submissionId = data.submission_id;
        }
    } catch(e) {}
}

// ================================================================
// RESET
// ================================================================
function resetForm() {
    if (!confirm('Reset semua data?')) return;
    
    // Clear localStorage
    localStorage.removeItem(STORAGE_KEY);
    submissionId = null;
    
    // Reload halaman → PHP akan fetch ulang $submission_id
    location.reload();
}

// ================================================================
// PREVIEW
// ================================================================
function previewAndDownload() {
    generatePreview();
    switchTab('preview');
    showToast('👁 Preview siap dilihat', 'info');
}

function generatePreview() {
    var html = buildPDFHTML();
    document.getElementById('previewDoc').innerHTML = html;
}

// ================================================================
// BUILD PDF HTML - PREVIEW
// ================================================================
function buildPDFHTML() {
    function v(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }
    function q(id) { return quills[id] ? quills[id].root.innerHTML : ''; }
    function esc(s) { return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
    function fdate(s) { if(!s) return ''; var d=new Date(s); var M=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']; return d.getDate()+' '+M[d.getMonth()]+' '+d.getFullYear(); }

    var html = '<div class="pdf-page">';
    html += '<div class="kop">';
    if ('<?= $kop_logo ?>') html += '<img src="<?= $kop_logo ?>"><br>';
    html += '<div class="instansi"><?= htmlspecialchars($kop_instansi) ?></div>';
    if ('<?= $kop_alamat ?>') html += '<div class="alamat"><?= htmlspecialchars($kop_alamat) ?></div>';
    if ('<?= $kop_telp ?>' || '<?= $kop_email ?>') {
        html += '<div class="alamat">';
        if ('<?= $kop_telp ?>') html += 'Telp: <?= htmlspecialchars($kop_telp) ?>';
        if ('<?= $kop_telp ?>' && '<?= $kop_email ?>') html += ' | ';
        if ('<?= $kop_email ?>') html += 'Email: <?= htmlspecialchars($kop_email) ?>';
        html += '</div>';
    }
    html += '</div>';

    html += '<div class="pdf-title">LAPORAN HASIL PERJALANAN DINAS</div>';
    html += '<br>';
    html += '<table class="pdf-tbl">';
    html += '<tr><td class="label-col">Yth</td><td class="sep-col">:</td><td>'+esc(v('ditujukan'))+'</td></tr>';
    html += '<tr><td class="label-col">Dari</td><td class="sep-col">:</td><td>'+esc(v('dari'))+'</td></tr>';
    html += '<tr><td class="label-col">Hari, Tanggal</td><td class="sep-col">:</td><td>'+esc(v('hari_tanggal'))+'</td></tr>';
    html += '<tr><td class="label-col">Waktu</td><td class="sep-col">:</td><td>'+esc(v('waktu'))+'</td></tr>';
    html += '<tr><td class="label-col">Tempat</td><td class="sep-col">:</td><td>'+esc(v('tempat'))+'</td></tr>';
    html += '<tr><td class="label-col">Acara</td><td class="sep-col">:</td><td>'+esc(v('acara'))+'</td></tr>';
    html += '<tr><td class="label-col">Dasar</td><td class="sep-col">:</td><td>'+esc(v('dasar'))+'</td></tr>';
    html += '</table>';

    html += '<div class="pdf-section">Hasil Tugas :</div>';
    html += '<div class="ql-editor">'+q('hasil_tugas')+'</div>';

    if (v('temuan')) {
        html += '<div class="pdf-section">Temuan :</div>';
        html += '<div class="ql-editor">'+q('temuan')+'</div>';
    }

    if (v('tindak_lanjut')) {
        html += '<div class="pdf-section">Tindak Lanjut :</div>';
        html += '<div class="ql-editor">'+q('tindak_lanjut')+'</div>';
    }

    if (v('penutup')) {
        html += '<div class="pdf-section">Penutup :</div>';
        html += '<div class="ql-editor">'+q('penutup')+'</div>';
    }

    html += '<div style="text-align:right;margin-top:20px;">';
    html += '<p style="margin:2px 0;">'+esc(v('ttd_kota'))+', '+fdate(v('ttd_tgl'))+'</p>';
    html += '<p style="margin:2px 0;">Yang Melaksanakan Perjalanan Dinas</p>';
    html += '<p style="margin:2px 0;">'+esc(v('ttd_jabatan'))+'</p>';
    html += '<p style="margin:6px 0;"></p>';  // spasi
    html += '<p style="margin:2px 0;font-weight:bold;">'+esc(v('ttd_nama'))+'</p>';
    html += '</div>';

    if (photos.length > 0) {
        html += '<div style="page-break-before: always;"></div>';
        html += '<div class="pdf-page" style="text-align:center;">';
        html += '<div class="pdf-foto-title"><?= $fields[array_search("foto_judul", array_column($fields, "id"))]["placeholder"] ?? "DOKUMENTASI KEGIATAN" ?></div>';
        html += '<div class="pdf-foto-grid">';
        photos.forEach(function(p) {
            html += '<div class="pdf-foto-item"><img src="'+p.src+'"><p>'+esc(p.caption||'')+'</p></div>';
        });
        html += '</div>';
        html += '</div>';
    }

    html += '</div>';
    return html;
}

// ================================================================
// RENDER RICH TEXT (QUILL HTML) KE PDF - BULLET/NUMBERING RAPIH
// Bullet & angka pakai hanging indent: baris lanjutan sejajar
// dengan awal teks (bukan sejajar bullet).
// ================================================================
function renderQuillToPdf(pdf, html, x, y, maxWidth, pdfHeight, pageMargin) {
    var LINE_H = 5;       // tinggi baris
    var PARA_GAP = 2;     // jarak antar paragraf
    var ITEM_GAP = 1.5;   // jarak antar item list
    var INDENT_STEP = 6;  // lebar tiap level indent (ql-indent-N)
    var MARK_W = 6;       // lebar kolom bullet/nomor
    var FONT_SIZE = 9;
    var defaultLHF = pdf.getLineHeightFactor ? pdf.getLineHeightFactor() : 1.15;

    var wrapper = document.createElement('div');
    wrapper.innerHTML = html;

    // kalau kosong (mis. "<p><br></p>"), render strip saja
    var plain = wrapper.textContent.replace(/\u00a0/g, ' ').trim();
    if (!plain) {
        checkBreak();
        pdf.setFont('times', 'normal');
        pdf.setFontSize(FONT_SIZE);
        pdf.text('-', x, y);
        y += LINE_H;
        return y;
    }

    function checkBreak() {
        if (y > pdfHeight - pageMargin) {
            pdf.addPage();
            y = pageMargin;
        }
    }

    function cleanText(s) {
        return (s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
    }

    function indentLevelOf(el) {
        var m = (el.className || '').match(/ql-indent-(\d+)/);
        return m ? parseInt(m[1], 10) : 0;
    }

    // Cetak sekumpulan baris (hasil splitTextToSize) dengan perataan
    // kiri-kanan (justify) - baris terakhir tetap rata kiri, sama seperti
    // perilaku "text-align: justify" pada preview. Otomatis pindah
    // halaman kalau baris tidak muat, tanpa memutus perataan tiap chunk.
    function writeJustifiedLines(lines, textX, availWidth) {
        var sf = pdf.internal.scaleFactor;
        var idx = 0;
        while (idx < lines.length) {
            checkBreak();
            var remaining = Math.max(1, Math.floor((pdfHeight - pageMargin - y) / LINE_H));
            var chunk = lines.slice(idx, idx + remaining);
            var isLastChunk = (idx + chunk.length) >= lines.length;
            pdf.setLineHeightFactor((LINE_H * sf) / FONT_SIZE);
            if (chunk.length > 1) {
                // jsPDF's 'justify' stretches every line in the array except
                // the last one, which stays left-aligned - same as CSS
                // text-align:justify. isLastChunk is kept for clarity/future use.
                pdf.text(chunk, textX, y, { maxWidth: availWidth, align: 'justify' });
            } else {
                pdf.text(chunk[0], textX, y);
            }
            pdf.setLineHeightFactor(defaultLHF);
            y += chunk.length * LINE_H;
            idx += chunk.length;
        }
    }

    // Tulis satu "item" teks dengan hanging indent + rata kiri-kanan.
    // markText di-print hanya pada baris pertama, kolom markX..indentX.
    function writeItem(text, indentX, markText, bold) {
        var textX = indentX + (markText ? MARK_W : 0);
        var availWidth = (x + maxWidth) - textX;
        availWidth = availWidth > 20 ? availWidth : 20;
        pdf.setFont('times', bold ? 'bold' : 'normal');
        pdf.setFontSize(FONT_SIZE);
        var lines = pdf.splitTextToSize(text, availWidth);
        if (markText) {
            checkBreak();
            pdf.text(markText, indentX, y);
        }
        writeJustifiedLines(lines, textX, availWidth);
    }

    function renderList(listEl, ordered) {
        var counters = {}; // counter per level, reset tiap list baru
        Array.from(listEl.children).forEach(function(li) {
            if (!li.tagName || li.tagName.toLowerCase() !== 'li') return;
            var level = indentLevelOf(li);
            var text = cleanText(li.textContent);
            if (!text) return;
            counters[level] = (counters[level] || 0) + 1;
            // reset counter level yang lebih dalam saat kembali ke level ini
            Object.keys(counters).forEach(function(k) {
                if (parseInt(k, 10) > level) counters[k] = 0;
            });
            var mark = ordered ? (counters[level] + '.') : '•';
            var indentX = x + (level * INDENT_STEP);
            writeItem(text, indentX, mark + ' ', false);
            y += ITEM_GAP;
        });
        y += PARA_GAP;
    }

     // Render <table> Quill sebagai tabel bergaris di PDF.
    function renderTable(tableEl) {
        var rows = Array.from(tableEl.querySelectorAll('tr'));
        if (!rows.length) return;
        var numCols = 0;
        rows.forEach(function(r) { numCols = Math.max(numCols, r.children.length); });
        if (numCols === 0) return;
        var cellPad = 2;

        // ---- Ambil lebar kolom ASLI dari <col style="width:Xpx"> (hasil
        // drag-resize pengguna), diskalakan proporsional ke maxWidth (mm).
        // tableEl di sini diproses dari elemen yang tidak menempel ke DOM
        // (dibuat dari innerHTML string), jadi getBoundingClientRect selalu
        // nol — satu-satunya sumber ukuran valid adalah style inline yang
        // sudah ditanam oleh drag-handle. ----
        var colWidthsPx = [];
        var colgroup = tableEl.querySelector('colgroup');
        if (colgroup) {
            Array.prototype.forEach.call(colgroup.children, function(col) {
                colWidthsPx.push(parseFloat(col.style.width) || 0);
            });
        }
        var totalPx = colWidthsPx.reduce(function(a, b) { return a + b; }, 0);
        var colW;
        if (totalPx > 0 && colWidthsPx.length === numCols) {
            colW = colWidthsPx.map(function(w) { return (w / totalPx) * maxWidth; });
        } else {
            var uniform = maxWidth / numCols;
            colW = []; for (var ci = 0; ci < numCols; ci++) colW.push(uniform);
        }
        function colX(ci) { var cx = x; for (var i = 0; i < ci; i++) cx += colW[i]; return cx; }

        // Konversi px (drag di browser, ~96dpi) ke mm untuk PDF
        var PX_TO_MM = 0.264;

        rows.forEach(function(row) {
            var cells = Array.from(row.children);
            var isHeaderRow = cells.length && cells[0].tagName && cells[0].tagName.toLowerCase() === 'th';
            pdf.setFont('times', isHeaderRow ? 'bold' : 'normal');
            pdf.setFontSize(FONT_SIZE - 0.5);

            // ---- Tinggi baris ASLI (px) hasil drag-resize pengguna,
            // diambil dari style.height baris <tr> atau sel <td>/<th>. ----
            var customHeightPx = parseFloat(row.style.height) || 0;
            if (!customHeightPx && cells.length) {
                customHeightPx = parseFloat(cells[0].style.height) || 0;
            }
            var neededFromResize = customHeightPx ? (customHeightPx * PX_TO_MM) : 0;

            var cellLines = [];
            var rowHeight = LINE_H + cellPad * 2;
            cells.forEach(function(cell, ci) {
                var text = cleanText(cell.textContent);
                var w = colW[ci] - cellPad * 2;
                var lines = pdf.splitTextToSize(text || ' ', w > 5 ? w : 5);
                cellLines.push(lines);
                var h = lines.length * LINE_H + cellPad * 2;
                if (h > rowHeight) rowHeight = h;
            });
            // Hormati tinggi hasil drag kalau lebih besar dari kebutuhan teks;
            // tetap perbesar otomatis kalau teksnya lebih panjang dari itu
            // supaya tidak terpotong.
            rowHeight = Math.max(rowHeight, neededFromResize);

            if (y + rowHeight > pdfHeight - pageMargin) {
                pdf.addPage();
                y = pageMargin;
            }
            if (isHeaderRow) { pdf.setFillColor(240, 240, 240); }

            cells.forEach(function(cell, ci) {
                var cx = colX(ci);
                if (isHeaderRow) {
                    pdf.rect(cx, y, colW[ci], rowHeight, 'FD');
                } else {
                    pdf.rect(cx, y, colW[ci], rowHeight);
                }
                var lines = cellLines[ci];
                lines.forEach(function(line, li) {
                    pdf.text(line, cx + cellPad, y + cellPad + (li + 1) * LINE_H - 1.5);
                });
            });
            y += rowHeight;
        });
        y += PARA_GAP + 1;
    }

    Array.from(wrapper.children).forEach(function(node) {
        var tag = node.tagName ? node.tagName.toLowerCase() : '';
        if (tag === 'ol') {
            renderList(node, true);
        } else if (tag === 'ul') {
            renderList(node, false);
        } else if (tag === 'table') {
            renderTable(node);
        } else if (tag === 'blockquote') {
            var qText = cleanText(node.textContent);
            if (qText) { writeItem(qText, x + INDENT_STEP, null, false); y += PARA_GAP; }
        } else if (tag === 'p' || tag === 'div' || tag === 'h1' || tag === 'h2' || tag === 'h3') {
            var pText = cleanText(node.textContent);
            if (pText) {
                writeItem(pText, x, null, false);
                y += PARA_GAP;
            } else {
                y += LINE_H * 0.5; // baris kosong dari <p><br></p>
            }
        } else {
            var fallbackText = cleanText(node.textContent);
            if (fallbackText) { writeItem(fallbackText, x, null, false); y += PARA_GAP; }
        }
    });

    return y;
}

// ================================================================
// DOWNLOAD PDF - JSPDF LANGSUNG (TIDAK PAKAI html2canvas)
// ================================================================
function downloadPDF() {
    // ============================================================
    // BAGIAN 1: UPDATE STATUS (GANTI saveToServer)
    // ============================================================
    
    // 1. Update status di LOCAL
    var data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    data.status = 'downloaded';
    data.downloaded_at = new Date().toISOString();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    
    // 2. Kirim status ke server (RINGAN!)
    var payload = {
        form_key: 'form_sppd',
        status: 'downloaded',
        submission_id: submissionId || 0,
        timestamp: data.downloaded_at
    };
    
    fetch('api/save_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(function(res) { return res.json(); })
    .then(function(result) {
        if (result.success) {
            // Update submissionId
            submissionId = result.submission_id;
            data.submission_id = result.submission_id;
            data.status = 'downloaded';
            data.updated_at = new Date().toISOString();
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
            
            // ✅ UPDATE RIWAYAT!
            saveToHistory(data);
            
            console.log('✅ Status updated to downloaded:', result.submission_id);
        }
    })
    .catch(function(err) {
        console.error('Failed to update status:', err);
    });
    
    // ============================================================
    // BAGIAN 2: GENERATE PDF (KODE ASLI ANDA)
    // ============================================================
    
    function v(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }
    function esc(s) { return s || ''; }
    function fdate(s) { if(!s) return ''; var d=new Date(s); var M=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']; return d.getDate()+' '+M[d.getMonth()]+' '+d.getFullYear(); }
    function q(id) { return quills[id] ? quills[id].root.innerHTML : ''; }
    
    var ditujukan = esc(v('ditujukan'));
    var dari = esc(v('dari'));
    var jabatan_pelaksana = esc(v('jabatan_pelaksana'));
    var hari_tanggal = esc(v('hari_tanggal'));
    var waktu = esc(v('waktu'));
    var tempat = esc(v('tempat'));
    var acara = esc(v('acara'));
    var dasar = esc(v('dasar'));
    var hasil_tugas = q('hasil_tugas');
    var temuan = q('temuan');
    var tindak_lanjut = q('tindak_lanjut');
    var penutup = q('penutup');
    var ttd_kota = esc(v('ttd_kota'));
    var ttd_tgl = fdate(v('ttd_tgl'));
    var ttd_jabatan = esc(v('ttd_jabatan'));
    var ttd_nama = esc(v('ttd_nama'));
    var foto_judul = esc(v('foto_judul'));
    
    var pdf = new jspdf.jsPDF('p', 'mm', [210, 330]);
    var pdfWidth = pdf.internal.pageSize.getWidth();
    var pdfHeight = pdf.internal.pageSize.getHeight();
    var margin = 10;
    var contentWidth = pdfWidth - (margin * 2);
    var y = margin;
    
    // LOGO - RATA KIRI
    var logoUrl = '<?= $kop_logo ?>';
    if (logoUrl) {
        try {
            pdf.addImage(logoUrl, 'JPEG', margin, y, 170, 25);
            y += 20;
        } catch(e) {
            console.log('Logo tidak bisa dimuat: ' + e.message);
            y += 5;
        }
    }
    
    pdf.setFontSize(12);
    pdf.setFont('times', 'bold');
    var kopText = '<?= htmlspecialchars($kop_instansi) ?>';
    pdf.text(kopText, pdfWidth/2, y, { align: 'center' });
    y += 6;
    
    pdf.setFontSize(8);
    pdf.setFont('times', 'normal');
    var alamatKop = '<?= htmlspecialchars($kop_alamat) ?>';
    if (alamatKop) { pdf.text(alamatKop, pdfWidth/2, y, { align: 'center' }); y += 4; }
    var telpKop = '<?= htmlspecialchars($kop_telp) ?>';
    var emailKop = '<?= htmlspecialchars($kop_email) ?>';
    if (telpKop || emailKop) {
        var infoKop = '';
        if (telpKop) infoKop += 'Telp: ' + telpKop;
        if (telpKop && emailKop) infoKop += ' | ';
        if (emailKop) infoKop += 'Email: ' + emailKop;
        pdf.text(infoKop, pdfWidth/2, y, { align: 'center' });
        y += 1;
    }
    pdf.setLineWidth(1);
    pdf.line(margin, y, pdfWidth - margin, y);
    y += 1;

    pdf.setLineWidth(0.3);
    pdf.line(margin, y, pdfWidth - margin, y);
    y += 8;
    
    pdf.setFontSize(12);
    pdf.setFont('times', 'bold');
    pdf.text('LAPORAN HASIL PERJALANAN DINAS', pdfWidth/2, y, { align: 'center' });
    y += 10;
    
    pdf.setFontSize(9);
    pdf.setFont('times', 'normal');
    var dataRows = [
        ['Yth', ditujukan || '-'],
        ['Dari', dari || '-'],
        ['Jabatan', jabatan_pelaksana || '-'],
        ['Hari, Tanggal', hari_tanggal || '-'],
        ['Waktu', waktu || '-'],
        ['Tempat', tempat || '-'],
        ['Acara', acara || '-'],
        ['Dasar', dasar || '-']
    ];
    dataRows.forEach(function(row) {
        if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }
        pdf.text(row[0] + ' : ', margin, y);
        var splitText = pdf.splitTextToSize(row[1], 130);
        pdf.text(splitText, margin + 45, y);
        y += (splitText.length * 5) + 2;
    });
    y += 4;
    
    // HASIL TUGAS
    if (y > pdfHeight - margin - 20) { pdf.addPage(); y = margin; }
    pdf.setFont('times', 'bold');
    pdf.setFontSize(10);
    pdf.text('Hasil Tugas :', margin, y);
    y += 6;
    y = renderQuillToPdf(pdf, hasil_tugas, margin, y, contentWidth, pdfHeight, margin);
    y += 4;
    
    // TEMUAN
    if (temuan && temuan.trim() !== '') {
        if (y > pdfHeight - margin - 20) { pdf.addPage(); y = margin; }
        pdf.setFont('times', 'bold');
        pdf.setFontSize(10);
        pdf.text('Temuan :', margin, y);
        y += 6;
        y = renderQuillToPdf(pdf, temuan, margin, y, contentWidth, pdfHeight, margin);
        y += 4;
    }
    
    // TINDAK LANJUT
    if (tindak_lanjut && tindak_lanjut.trim() !== '') {
        if (y > pdfHeight - margin - 20) { pdf.addPage(); y = margin; }
        pdf.setFont('times', 'bold');
        pdf.setFontSize(10);
        pdf.text('Tindak Lanjut :', margin, y);
        y += 6;
        y = renderQuillToPdf(pdf, tindak_lanjut, margin, y, contentWidth, pdfHeight, margin);
        y += 4;
    }
    
    // PENUTUP
    if (penutup && penutup.trim() !== '') {
        if (y > pdfHeight - margin - 20) { pdf.addPage(); y = margin; }
        pdf.setFont('times', 'bold');
        pdf.setFontSize(10);
        pdf.text('Penutup :', margin, y);
        y += 6;
        y = renderQuillToPdf(pdf, penutup, margin, y, contentWidth, pdfHeight, margin);
        y += 4;
    }
    
    // TTD - RATA KANAN
    if (y > pdfHeight - margin - 50) { pdf.addPage(); y = margin; }
    pdf.setFont('times', 'normal');
    pdf.setFontSize(9);
    var ttdKota = ttd_kota || '-';
    var ttdTgl = ttd_tgl || '-';
    var ttdJabatan = ttd_jabatan || '-';
    var ttdNama = ttd_nama || '-';
    
    var ttdText1 = ttdKota + ', ' + ttdTgl;
    var width1 = pdf.getStringUnitWidth(ttdText1) * 9 / pdf.internal.scaleFactor;
    pdf.text(ttdText1, pdfWidth - margin - width1, y);
    y += 8;
    
    var ttdText2 = 'Yang Melaksanakan Perjalanan Dinas';
    var width2 = pdf.getStringUnitWidth(ttdText2) * 9 / pdf.internal.scaleFactor;
    pdf.text(ttdText2, pdfWidth - margin - width2, y);
    y += 8;
    
    var ttdText3 = ttdJabatan;
    var width3 = pdf.getStringUnitWidth(ttdText3) * 9 / pdf.internal.scaleFactor;
    pdf.text(ttdText3, pdfWidth - margin - width3, y);
    y += 10;
    
    y += 4;
    
    pdf.setFont('times', 'bold');
    var ttdText4 = ttdNama;
    var width4 = pdf.getStringUnitWidth(ttdText4) * 9 / pdf.internal.scaleFactor;
    pdf.text(ttdText4, pdfWidth - margin - width4, y);
    y += 10;
    
    // FOTO
    if (photos.length > 0) {
        pdf.addPage();
        y = margin + 20;
        pdf.setFont('times', 'bold');
        pdf.setFontSize(12);
        var judulFoto = foto_judul || 'DOKUMENTASI KEGIATAN';
        pdf.text(judulFoto, pdfWidth/2, y, { align: 'center' });
        y += 10;
        
        var imgWidth = 74;
        var imgHeight = 55.5;
        var cols = 2;
        var rowsPerPage = 4;
        var photosPerPage = cols * rowsPerPage;
        var spacing = 6;
        var rowStep = imgHeight + spacing + 10;
        var totalWidth = (cols * imgWidth) + ((cols - 1) * spacing);
        var startX = (pdfWidth - totalWidth) / 2;
        var pageStartY = y;
        
        photos.forEach(function(p, index) {
            var posInPage = index % photosPerPage;
            var col = posInPage % cols;
            var row = Math.floor(posInPage / cols);
            
            if (posInPage === 0 && index !== 0) {
                pdf.addPage();
                pageStartY = margin + 10;
            }
            
            var x = startX + (col * (imgWidth + spacing));
            var yPos = pageStartY + (row * rowStep);
            
            try {
                pdf.addImage(p.src, 'JPEG', x, yPos, imgWidth, imgHeight);
                if (p.caption) {
                    pdf.setFont('times', 'italic');
                    pdf.setFontSize(7);
                    pdf.text(p.caption, x + imgWidth/2, yPos + imgHeight + 4, { align: 'center' });
                }
            } catch(e) {
                console.log('Gagal load foto: ' + e.message);
            }
        });
    }
    
    pdf.save('Laporan_Hasil_Perjalanan_Dinas_' + new Date().toISOString().slice(0,10) + '.pdf');
    showToast('📄 PDF F4 berhasil di-download!', 'success');
}

// ================================================================
// LOAD RIWAYAT - SYNC DENGAN SERVER + AUTO-CLEANUP
// ================================================================
function loadRiwayat() {
    try {
        var history = JSON.parse(localStorage.getItem('form_history') || '[]');
        var formKey = 'form_sppd';  // ← GANTI 'form_sppd' untuk form_sppd
        var userId = <?= $_SESSION['user_id'] ?>;
        
        // ============================================================
        // 1. AMBIL & FILTER BERDASARKAN FORM & USER
        // ============================================================
        var myHistory = history.filter(function(item) {
            return item.form_key === formKey && item.user_id === userId;
        });
        
        if (myHistory.length === 0) {
            renderRiwayat([]);
            return;
        }
        
        // ============================================================
        // 2. FETCH DARI SERVER → CEK MANA YANG MASIH ADA
        // ============================================================
        fetch('api/get_submissions.php?form_key=' + formKey)
            .then(function(res) { return res.json(); })
            .then(function(serverData) {
                if (!Array.isArray(serverData)) serverData = [];
                
                // Buat map: submission_id → serverItem
                var serverMap = {};
                serverData.forEach(function(s) {
                    serverMap[s.id] = s;
                });
                
                // ============================================================
                // 3. FILTER: HANYA ENTRY YANG MASIH ADA DI DATABASE
                // ============================================================
                var validHistory = myHistory.filter(function(item) {
                    return serverMap[item.submission_id];  // ← HANYA yang ada di server
                });
                
                // ============================================================
                // 4. HAPUS ENTRY INVALID DARI LOCALSTORAGE
                // ============================================================
                if (validHistory.length !== myHistory.length) {
                    console.log('🧹 Cleanup: ' + myHistory.length + ' → ' + validHistory.length);
                    
                    var otherHistory = history.filter(function(i) {
                        return !(i.form_key === formKey && i.user_id === userId);
                    });
                    var newHistory = otherHistory.concat(validHistory);
                    localStorage.setItem('form_history', JSON.stringify(newHistory));
                }
                
                // ============================================================
                // 5. AUTO-CLEANUP DUPLIKAT (jaga-jaga)
                // ============================================================
                validHistory.sort(function(a, b) {
                    var dateA = new Date(a.updated_at || a.created_at || 0);
                    var dateB = new Date(b.updated_at || b.created_at || 0);
                    return dateB - dateA;
                });
                
                var seen = {};
                var cleaned = [];
                validHistory.forEach(function(item) {
                    var key = item.form_key + '_' + item.user_id + '_' + item.submission_id;
                    if (!seen[key]) {
                        seen[key] = true;
                        cleaned.push(item);
                    }
                });
                
                validHistory = cleaned;
                
                // ============================================================
                // 6. UPDATE STATUS DARI SERVER
                // ============================================================
                validHistory.forEach(function(item) {
                    var serverItem = serverMap[item.submission_id];
                    if (serverItem) {
                        item.status = serverItem.status;
                        item.admin_note = serverItem.admin_note || '';
                        item.updated_at = serverItem.updated_at;
                    }
                });
                
                // ============================================================
                // 7. SIMPAN KEMBALI KE LOCALSTORAGE
                // ============================================================
                var allHistory = JSON.parse(localStorage.getItem('form_history') || '[]');
                validHistory.forEach(function(updatedItem) {
                    var idx = allHistory.findIndex(function(h) {
                        return h.submission_id === updatedItem.submission_id && 
                               h.form_key === formKey && 
                               h.user_id === userId;
                    });
                    if (idx >= 0) {
                        allHistory[idx] = updatedItem;
                    }
                });
                localStorage.setItem('form_history', JSON.stringify(allHistory));
                
                // ============================================================
                // 8. RENDER
                // ============================================================
                renderRiwayat(validHistory);
            })
            .catch(function(err) {
                console.error('Fetch error:', err);
                
                // Fallback: render dari localStorage (kalau server tidak bisa diakses)
                myHistory.sort(function(a, b) {
                    var dateA = new Date(a.updated_at || a.created_at || 0);
                    var dateB = new Date(b.updated_at || b.created_at || 0);
                    return dateB - dateA;
                });
                
                var seen = {};
                var cleaned = [];
                myHistory.forEach(function(item) {
                    var key = item.form_key + '_' + item.user_id + '_' + item.submission_id;
                    if (!seen[key]) {
                        seen[key] = true;
                        cleaned.push(item);
                    }
                });
                
                renderRiwayat(cleaned);
            });
        
    } catch (e) {
        console.error('Load riwayat error:', e);
        document.getElementById('riwayatContent').innerHTML = 
            '<p style="text-align:center;color:#C62828;padding:20px;">❌ Gagal memuat riwayat</p>';
    }
}

// ================================================================
// RENDER RIWAYAT
// ================================================================
function renderRiwayat(myHistory) {
    var container = document.getElementById('riwayatContent');
    
    if (myHistory.length === 0) {
        container.innerHTML = '<p style="text-align:center;color:#6B7A99;padding:20px;">📭 Belum ada riwayat</p>';
        return;
    }
    
    var html = '<table class="submission-table"><thead><tr><th>#</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead><tbody>';
    var reversed = [...myHistory].reverse();
    
    reversed.forEach(function(item, index) {
        var statusLabel = {
            'draft': '📝 Draft',
            'downloaded': '⬇ Downloaded',
            'submitted': '📤 Terkirim',
            'approved': '✅ Disetujui',
            'rejected': '❌ Ditolak'
        }[item.status] || item.status;
        
        var statusClass = 'status-' + (item.status || 'draft');
        var date = item.updated_at || item.created_at || new Date().toISOString();
        
        html += '<tr>';
        html += '<td>' + (index + 1) + '</td>';
        html += '<td>' + new Date(date).toLocaleString() + '</td>';
        html += '<td><span class="status-badge ' + statusClass + '">' + statusLabel + '</span></td>';
        html += '<td>';
        html += '<button class="btn-edit" onclick="loadFromHistory(' + index + ')">✏️ Buka</button>';
        
        if (item.status === 'downloaded' || item.status === 'submitted' || item.status === 'approved') {
            html += ' <button class="btn-preview" onclick="previewFromHistory(' + index + ')">👁 Preview</button>';
        }
        
        if (item.status === 'downloaded') {
            html += ' <button class="btn-kirim" onclick="openUploadModal(' + index + ')" style="background:#E53935;color:#fff;border:none;padding:2px 12px;border-radius:4px;font-size:11px;cursor:pointer;">📤 Kirim</button>';
        }
        
        if (item.status === 'submitted') {
            html += ' <span style="color:#F5A623;font-size:11px;font-weight:600;">⏳ Menunggu Verifikasi</span>';
        }
        
        if (item.status === 'approved') {
            html += ' <span style="color:#1A7A45;font-size:11px;font-weight:600;">✅ Disetujui</span>';
        }
        
        if (item.status === 'rejected') {
            html += ' <span style="color:#C62828;font-size:11px;font-weight:600;">❌ Ditolak</span>';
            if (item.admin_note) {
                html += '<br><small style="color:#C62828;font-size:10px;">📝 ' + item.admin_note + '</small>';
            }
        }
        
        if (item.status === 'draft' || item.status === 'downloaded') {
            html += ' <button class="btn-delete" onclick="deleteHistory(' + index + ')">🗑 Hapus</button>';
        }
        
        html += '</td></tr>';
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}
// ================================================================
// EDIT SUBMISSION
// ================================================================
function editSubmission(id) {
    fetch('api/get_submission.php?id='+id)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data && data.form_data) {
                var formData = JSON.parse(data.form_data);
                for (var key in formData) {
                    if (key === 'photos') { photos = formData.photos || []; renderPhotos(); continue; }
                    if (quills[key] && formData[key]) {
                        quills[key].root.innerHTML = formData[key];
                        continue;
                    }
                    var el = document.getElementById(key);
                    if (el) {
                        if (el.type === 'checkbox') el.checked = formData[key] === true;
                        else el.value = formData[key] || '';
                    }
                }
                submissionId = id;
                var draft = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
                draft.submission_id = id;
                localStorage.setItem(STORAGE_KEY, JSON.stringify(draft));
                switchTab('form');
                showToast('📝 Data dimuat untuk diedit', 'info');
            }
        })
        .catch(function() {});
}

function previewSubmission(id) {
    fetch('api/get_submission.php?id='+id)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data && data.form_data) {
                var formData = JSON.parse(data.form_data);
                for (var key in formData) {
                    if (key === 'photos') { photos = formData.photos || []; continue; }
                    if (quills[key] && formData[key]) {
                        quills[key].root.innerHTML = formData[key];
                        continue;
                    }
                    var el = document.getElementById(key);
                    if (el) {
                        if (el.type === 'checkbox') el.checked = formData[key] === true;
                        else el.value = formData[key] || '';
                    }
                }
                generatePreview();
                switchTab('preview');
            }
        })
        .catch(function() {});
}

// ================================================================
// DELETE SUBMISSION
// ================================================================
function deleteSubmission(id) {
    if (!confirm('Yakin ingin menghapus data ini?')) return;
    fetch('api/delete_submission.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
    })
    .then(function(res) { return res.json(); })
    .then(function(result) {
        if (result.success) {
            showToast('🗑 Data berhasil dihapus!', 'success');
            loadRiwayat();
        } else {
            showToast('❌ Gagal hapus data', 'error');
        }
    })
    .catch(function() {});
}

// ============================================================
// TOAST NOTIFICATION
// ============================================================
function showToast(msg, type, persistent = false) {
    // Hapus toast lama
    var old = document.querySelector('.toast-message');
    if (old) old.remove();
    
    var toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        padding: 12px 24px;
        border-radius: 10px;
        font-weight: 600;
        z-index: 9999;
        box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        max-width: 90%;
        transition: opacity 0.3s;
        font-size: 14px;
    `;
    
    var colors = {
        success: '#2E7D32',
        error: '#C62828',
        warning: '#F5A623',
        info: '#2D5BE3'
    };
    
    toast.style.background = colors[type] || '#1A1A2E';
    toast.style.color = '#fff';
    
    if (persistent) {
        toast.innerHTML = msg + ' <span class="spinner">⟳</span>';
    } else {
        toast.textContent = msg;
    }
    
    document.body.appendChild(toast);
    
    if (!persistent) {
        setTimeout(function() {
            toast.style.opacity = '0';
            setTimeout(function() { toast.remove(); }, 300);
        }, 3000);
    }
}

// ================================================================
// INSERT TABLE - custom Quill toolbar button
// ================================================================
if (window.Quill) {
    var qlIcons = Quill.import('ui/icons');
    qlIcons['insertTable'] = '<span class="ql-table-icon">▦</span>';
}

if (window.Quill) {
    var qlIcons = Quill.import('ui/icons');
    qlIcons['insertTable'] = '<span class="ql-table-icon">▦</span>';

    // ✅ FIX: daftarkan <table> sebagai blot embed mandiri.
    // Ini mencegah Quill "mengoreksi ulang" struktur tabel jadi teks polos
    // setiap kali editor melakukan reconciliation internal.
    var BlockEmbed = Quill.import('blots/block/embed');
    class RtTable extends BlockEmbed {}
    RtTable.blotName = 'rt-table';
    RtTable.tagName = 'TABLE';
    Quill.register(RtTable, true);
}

function insertTableIntoEditor(quillInstance) {
    var rowsInput = prompt('Jumlah baris (termasuk header):', '3');
    if (rowsInput === null) return;
    var colsInput = prompt('Jumlah kolom:', '3');
    if (colsInput === null) return;
    var rows = parseInt(rowsInput, 10);
    var cols = parseInt(colsInput, 10);
    if (!rows || !cols || rows < 1 || cols < 1) {
        showToast('❌ Jumlah baris/kolom tidak valid', 'error');
        return;
    }

    // Lebar kolom awal dibagi rata sesuai lebar editor saat ini,
    // supaya kolom langsung terlihat proporsional dan siap di-drag ubah ukurannya.
    var editorWidth = quillInstance.root.clientWidth || 600;
    var colWidth = Math.max(60, Math.floor((editorWidth - (cols * 2)) / cols));

    var html = '<table class="ql-table">';
    html += '<colgroup>';
    for (var g = 0; g < cols; g++) {
        html += '<col style="width:' + colWidth + 'px">';
    }
    html += '</colgroup><tbody>';
    for (var r = 0; r < rows; r++) {
        html += '<tr>';
        for (var c = 0; c < cols; c++) {
            var cellTag = (r === 0) ? 'th' : 'td';
            html += '<' + cellTag + '></' + cellTag + '>';
        }
        html += '</tr>';
    }
    html += '</tbody></table><p><br></p>';

    // PENTING: JANGAN pakai quillInstance.clipboard.dangerouslyPasteHTML() —
    // clipboard matcher Quill tidak mengenali <table>/<tr>/<td> sebagai format
    // valid (tidak ada modul tabel terdaftar), sehingga semua tag tabel dibuang
    // dan yang tersisa cuma teks polos. Sisipkan langsung ke DOM di titik yang
    // AMAN: quill.getLine() (blok <p>/<h> yang jadi anak langsung editor),
    // BUKAN quill.getLeaf() (bisa berupa node <br>/teks DI DALAM sebuah blok,
    // yang kalau disisip "afterend" akan memicu error Parchment "Cannot
    // insert block into block").
    quillInstance.focus();
    var sel = quillInstance.getSelection(true);
    var idx = sel ? sel.index : quillInstance.getLength();
    var lineBlot = quillInstance.getLine(idx)[0];
    var blockNode = lineBlot ? lineBlot.domNode : null;

    if (blockNode && blockNode.parentNode === quillInstance.root) {
        blockNode.insertAdjacentHTML('afterend', html);
    } else {
        quillInstance.root.insertAdjacentHTML('beforeend', html);
    }

    // Sinkronkan manual ke field hidden karena penyisipan DOM langsung
    // tidak selalu memicu event 'text-change' bawaan Quill.
    for (var key in quills) {
        if (quills[key] === quillInstance) {
            var hiddenEl = document.getElementById(key);
            if (hiddenEl) hiddenEl.value = quillInstance.root.innerHTML;
            break;
        }
    }

    showToast('📊 Tabel ditambahkan — tarik garis tepi kolom/baris untuk ubah ukuran', 'success');
}

// ================================================================
// RESIZE TABEL - drag garis tepi kolom (lebar) & baris (tinggi)
// Berlaku untuk semua editor Quill (hasil_tugas, temuan, tindak_lanjut, penutup)
// Tidak menambah elemen baru ke DOM, jadi tidak mengotori HTML yang disimpan/di-preview.
// ================================================================
(function() {
    var ZONE = 6;          // toleransi px dari garis tepi sel untuk memicu resize
    var MIN_COL_WIDTH = 40;
    var MIN_ROW_HEIGHT = 24;
    var drag = null;       // { type:'col'|'row', col, tr, startX, startY, startWidth, startHeight }

    function findCell(target) {
        return (target && target.closest) ? target.closest('.ql-editor table.ql-table td, .ql-editor table.ql-table th') : null;
    }

    function edgeInfo(cell, clientX, clientY) {
        var rect = cell.getBoundingClientRect();
        var tr = cell.parentElement;
        var table = cell.closest('table');
        var isLastCol = cell.cellIndex === (tr.cells.length - 1);
        var isLastRow = tr === table.rows[table.rows.length - 1];
        var nearRight = !isLastCol && Math.abs(rect.right - clientX) <= ZONE;
        var nearBottom = !isLastRow && Math.abs(rect.bottom - clientY) <= ZONE;
        return { rect: rect, tr: tr, table: table, nearRight: nearRight, nearBottom: nearBottom };
    }

    function ensureColgroup(table) {
        var colgroup = table.querySelector('colgroup');
        var firstRow = table.rows[0];
        if (!firstRow) return colgroup;
        if (!colgroup) {
            colgroup = document.createElement('colgroup');
            for (var i = 0; i < firstRow.cells.length; i++) {
                var col = document.createElement('col');
                col.style.width = firstRow.cells[i].getBoundingClientRect().width + 'px';
                colgroup.appendChild(col);
            }
            table.insertBefore(colgroup, table.firstChild);
        }
        return colgroup;
    }

    var ZONE = 6;
    var MIN_COL_WIDTH = 40;
    var MIN_ROW_HEIGHT = 24;
    var drag = null;

    function findCell(target) {
        return (target && target.closest) ? target.closest('.ql-editor table.ql-table td, .ql-editor table.ql-table th') : null;
    }

    function edgeInfo(cell, clientX, clientY) {
        var rect = cell.getBoundingClientRect();
        var tr = cell.parentElement;
        var table = cell.closest('table');
        var isLastCol = cell.cellIndex === (tr.cells.length - 1);
        var isLastRow = tr === table.rows[table.rows.length - 1];
        var nearRight = !isLastCol && Math.abs(rect.right - clientX) <= ZONE;
        var nearBottom = !isLastRow && Math.abs(rect.bottom - clientY) <= ZONE;
        return { rect: rect, tr: tr, table: table, nearRight: nearRight, nearBottom: nearBottom };
    }

    function ensureColgroup(table) {
        var colgroup = table.querySelector('colgroup');
        var firstRow = table.rows[0];
        if (!firstRow) return colgroup;
        if (!colgroup) {
            colgroup = document.createElement('colgroup');
            for (var i = 0; i < firstRow.cells.length; i++) {
                var col = document.createElement('col');
                col.style.width = firstRow.cells[i].getBoundingClientRect().width + 'px';
                colgroup.appendChild(col);
            }
            table.insertBefore(colgroup, table.firstChild);
        }
        return colgroup;
    }

    function handleMove(clientX, clientY) {
        if (!drag) return;
        if (drag.type === 'col') {
            var newWidth = Math.max(MIN_COL_WIDTH, Math.round(drag.startWidth + (clientX - drag.startX)));
            drag.col.style.width = newWidth + 'px';
        } else if (drag.type === 'row') {
            var newHeight = Math.max(MIN_ROW_HEIGHT, Math.round(drag.startHeight + (clientY - drag.startY)));
            drag.tr.style.height = newHeight + 'px';
            Array.prototype.forEach.call(drag.tr.cells, function(c) { c.style.height = newHeight + 'px'; });
        }
    }

    function startDrag(cell, clientX, clientY) {
        var info = edgeInfo(cell, clientX, clientY);
        if (info.nearRight) {
            var colgroup = ensureColgroup(info.table);
            var col = colgroup ? colgroup.children[cell.cellIndex] : null;
            if (!col) return false;
            drag = { type: 'col', col: col, startX: clientX, startWidth: col.getBoundingClientRect().width || info.rect.width };
            document.body.classList.add('rt-col-resizing');
            return true;
        } else if (info.nearBottom) {
            drag = { type: 'row', tr: info.tr, startY: clientY, startHeight: info.rect.height };
            document.body.classList.add('rt-row-resizing');
            return true;
        }
        return false;
    }

    function endDrag() {
        if (drag) {
            drag = null;
            document.body.classList.remove('rt-col-resizing', 'rt-row-resizing');
        }
    }

    // ---- Mouse (desktop) ----
    document.addEventListener('mousemove', function(e) {
        if (drag) { handleMove(e.clientX, e.clientY); return; }
        var cell = findCell(e.target);
        if (!cell) return;
        var info = edgeInfo(cell, e.clientX, e.clientY);
        cell.style.cursor = info.nearRight ? 'col-resize' : (info.nearBottom ? 'row-resize' : '');
    });

    document.addEventListener('mousedown', function(e) {
        var cell = findCell(e.target);
        if (!cell) return;
        if (startDrag(cell, e.clientX, e.clientY)) {
            e.preventDefault();
            e.stopPropagation();
        }
    }, true);

    document.addEventListener('mouseup', endDrag);

    // ---- Touch (mobile) ----
    // Layar sentuh tidak pernah memicu mousedown/mousemove/mouseup, jadi
    // resize kolom/baris tabel butuh pasangan event touch sendiri.
    document.addEventListener('touchstart', function(e) {
        var touch = e.touches[0];
        var target = document.elementFromPoint(touch.clientX, touch.clientY);
        var cell = findCell(target);
        if (!cell) return;
        if (startDrag(cell, touch.clientX, touch.clientY)) {
            e.preventDefault(); // cegah scroll halaman saat mulai drag di tepi sel
        }
    }, { passive: false });

    document.addEventListener('touchmove', function(e) {
        if (!drag) return;
        e.preventDefault();
        var touch = e.touches[0];
        handleMove(touch.clientX, touch.clientY);
    }, { passive: false });

    document.addEventListener('touchend', endDrag);
    document.addEventListener('touchcancel', endDrag);
})();

function submitForm() {
    if (!submissionId) {
        showToast('⚠️ Simpan draft terlebih dahulu!', 'warning');
        return;
    }
    if (!confirm('Kirim form ini untuk verifikasi?')) return;
    
    fetch('api/submit_form.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ submission_id: submissionId })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast('✅ ' + data.message, 'success');
            location.reload();
        } else {
            showToast('❌ ' + data.message, 'error');
        }
    })
    .catch(() => showToast('❌ Gagal mengirim form', 'error'));
}

// ================================================================
// LOAD FROM HISTORY - MUAT DATA DARI RIWAYAT
// ================================================================
function loadFromHistory(index) {
    try {
        var history = JSON.parse(localStorage.getItem('form_history') || '[]');
        var formKey = 'form_sppd';
        var userId = <?= $_SESSION['user_id'] ?>;
        
        var myHistory = history.filter(function(item) {
            return item.form_key === formKey && item.user_id === userId;
        });
        
        var reversed = [...myHistory].reverse();
        var item = reversed[index];
        
        if (!item || !item.form_data) {
            showToast('❌ Data tidak ditemukan', 'error');
            return;
        }
        
        var data = item.form_data;
        
        for (var key in data) {
            if (key === 'photos') {
                photos = data.photos || [];
                renderPhotos();
                continue;
            }
            if (key === 'submission_id') {
                submissionId = data.submission_id;
                continue;
            }
            if (key === 'status' || key === 'created_at' || key === 'updated_at' || key === 'downloaded_at') {
                continue;
            }
            
            if (quills[key] && data[key]) {
                quills[key].root.innerHTML = data[key];
                continue;
            }
            
            var el = document.getElementById(key);
            if (el) {
                if (el.type === 'checkbox') {
                    el.checked = data[key] === true;
                } else {
                    el.value = data[key] || '';
                }
            }
        }
        
        if (item.submission_id) {
            submissionId = item.submission_id;
            var draft = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
            draft.submission_id = item.submission_id;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(draft));
        }
        
        showToast('📝 Data dimuat dari riwayat', 'success');
        switchTab('form');
        
    } catch (e) {
        console.error('Load from history error:', e);
        showToast('❌ Gagal memuat data', 'error');
    }
}

// ================================================================
// PREVIEW FROM HISTORY - PREVIEW DARI RIWAYAT
// ================================================================
function previewFromHistory(index) {
    try {
        var history = JSON.parse(localStorage.getItem('form_history') || '[]');
        var formKey = 'form_sppd';
        var userId = <?= $_SESSION['user_id'] ?>;
        
        var myHistory = history.filter(function(item) {
            return item.form_key === formKey && item.user_id === userId;
        });
        
        var reversed = [...myHistory].reverse();
        var item = reversed[index];
        
        if (!item || !item.form_data) {
            showToast('❌ Data tidak ditemukan', 'error');
            return;
        }
        
        var data = item.form_data;
        
        for (var key in data) {
            if (key === 'photos') {
                photos = data.photos || [];
                continue;
            }
            if (key === 'submission_id') {
                submissionId = data.submission_id;
                continue;
            }
            if (key === 'status' || key === 'created_at' || key === 'updated_at' || key === 'downloaded_at') {
                continue;
            }
            
            if (quills[key] && data[key]) {
                quills[key].root.innerHTML = data[key];
                continue;
            }
            
            var el = document.getElementById(key);
            if (el) {
                if (el.type === 'checkbox') {
                    el.checked = data[key] === true;
                } else {
                    el.value = data[key] || '';
                }
            }
        }
        
        generatePreview();
        switchTab('preview');
        
    } catch (e) {
        console.error('Preview from history error:', e);
        showToast('❌ Gagal preview', 'error');
    }
}

// ================================================================
// DELETE HISTORY - HAPUS RIWAYAT
// ================================================================
function deleteHistory(index) {
    if (!confirm('Yakin ingin menghapus riwayat ini?')) return;
    
    try {
        var history = JSON.parse(localStorage.getItem('form_history') || '[]');
        var formKey = 'form_sppd';
        var userId = <?= $_SESSION['user_id'] ?>;
        
        var myHistory = history.filter(function(item) {
            return item.form_key === formKey && item.user_id === userId;
        });
        
        var reversed = [...myHistory].reverse();
        var item = reversed[index];
        
        // Cari index asli di history
        var originalIndex = history.findIndex(function(h) {
            return h.submission_id === item.submission_id && h.form_key === formKey && h.user_id === userId;
        });
        
        if (originalIndex >= 0) {
            history.splice(originalIndex, 1);
            localStorage.setItem('form_history', JSON.stringify(history));
            loadRiwayat();
            showToast('🗑 Riwayat dihapus', 'success');
        }
        
    } catch (e) {
        console.error('Delete history error:', e);
        showToast('❌ Gagal hapus', 'error');
    }
}

// ================================================================
// SWITCH TAB
// ================================================================
function switchTab(tab) {
    // Update tab button active
    document.querySelectorAll('.tab-btn').forEach(function(btn) {
        btn.classList.remove('active');
    });
    
    // Show/hide tabs
    document.getElementById('tabForm').style.display = 'none';
    document.getElementById('tabPreview').style.display = 'none';
    document.getElementById('tabRiwayat').style.display = 'none';
    
    if (tab === 'form') {
        document.querySelectorAll('.tab-btn')[0].classList.add('active');
        document.getElementById('tabForm').style.display = 'block';
    } else if (tab === 'preview') {
        document.querySelectorAll('.tab-btn')[1].classList.add('active');
        document.getElementById('tabPreview').style.display = 'block';
        generatePreview();  // ← Auto generate preview!
    } else if (tab === 'riwayat') {
        document.querySelectorAll('.tab-btn')[2].classList.add('active');
        document.getElementById('tabRiwayat').style.display = 'block';
        loadRiwayat();
    }
}

// ================================================================
// PREVIEW - TOMBOL PREVIEW BAWAH
// ================================================================
function preview() {
    generatePreview();
    switchTab('preview');
    showToast('👁 Preview siap dilihat', 'info');
}

// ================================================================
// SAVE TO HISTORY - SIMPAN RIWAYAT DI LOCAL STORAGE
// ================================================================
function saveToHistory(data) {
    try {
        var history = JSON.parse(localStorage.getItem('form_history') || '[]');
        var formKey = 'form_sppd';
        var userId = <?= $_SESSION['user_id'] ?>;
        
        // Cek apakah sudah ada entry dengan submission_id yang sama
        var existingIndex = -1;
        if (data.submission_id) {
            existingIndex = history.findIndex(function(item) {
                return item.form_key === formKey && 
                       item.user_id === userId && 
                       item.submission_id === data.submission_id;
            });
        }
        
        var entry = {
            form_key: formKey,
            user_id: userId,
            submission_id: data.submission_id || Date.now(),
            status: data.status || 'draft',
            created_at: data.created_at || new Date().toISOString(),
            updated_at: data.updated_at || new Date().toISOString(),
            form_data: data // Simpan semua data
        };
        
        if (existingIndex >= 0) {
            // Update existing
            history[existingIndex] = entry;
        } else {
            // Tambah baru di awal
            history.unshift(entry);
        }
        
        // Batasi maksimal 50 riwayat
        if (history.length > 50) {
            history = history.slice(0, 50);
        }
        
        localStorage.setItem('form_history', JSON.stringify(history));
        
    } catch (e) {
        console.error('Save history error:', e);
    }
}

// ================================================================
// INIT
// ================================================================
document.addEventListener('DOMContentLoaded', function() {
    var today = new Date().toISOString().slice(0,10);
    ['ttd_tgl'].forEach(function(id) {
        var el = document.getElementById(id);
        if (el && !el.value) el.value = today;
    });

    var textareaIds = ['hasil_tugas', 'temuan', 'tindak_lanjut', 'penutup'];
    textareaIds.forEach(function(id) {
        var el = document.getElementById('editor_' + id);
        if (el) {
            var isPenutup = (id === 'penutup');
    
            quills[id] = new Quill('#editor_' + id, {
                theme: 'snow',
                modules: {
                    toolbar: isPenutup ? false : {
                        container: [
                            [{ 'header': [1, 2, 3, false] }],
                            ['bold', 'italic', 'underline', 'strike'],
                            [{ 'color': [] }, { 'background': [] }],
                            [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                            [{ 'indent': '-1' }, { 'indent': '+1' }],
                            [{ 'align': [] }],
                            ['blockquote', 'code-block'],
                            ['link'],
                            ['insertTable'],
                            ['clean']
                        ],
                        handlers: {
                            insertTable: function() { insertTableIntoEditor(this.quill); }
                        }
                    }
                },
                placeholder: 'Masukkan ' + (document.getElementById(id)?.placeholder || '')
            });
    
            quills[id].on('text-change', function() {
                document.getElementById(id).value = quills[id].root.innerHTML;
            });
        }
    });

    loadDraft();
    loadRiwayat();
});

// ================================================================
// UPLOAD FILE - MODAL KIRIM PDF
// ================================================================
var uploadModal = null;
function openUploadModal(index) {
try {
var history = JSON.parse(localStorage.getItem('form_history') || '[]');
var formKey = 'form_sppd';
var userId = <?= $_SESSION['user_id'] ?>;
var myHistory = history.filter(function(item) {
return item.form_key === formKey && item.user_id === userId;
});
var reversed = [...myHistory].reverse();
var item = reversed[index];
if (!item || !item.submission_id) {
showToast('Data tidak ditemukan', 'error');
return;
}
// Buat modal
var modal = document.createElement('div');
modal.id = 'uploadModal';
modal.style.cssText = `
position: fixed;
inset: 0;
background: rgba(0,0,0,0.5);
z-index: 9999;
display: flex;
align-items: center;
justify-content: center;
`;
modal.innerHTML = `
<div style="background:#fff;border-radius:12px;padding:24px;max-width:450px;width:90%;">
<h3 style="margin:0 0 8px;">Kirim File PDF</h3>
<p style="color:#6B7A99;font-size:13px;margin-bottom:16px;">
Kirim file PDF hasil generate ke admin untuk diverifikasi.
</p>
<div style="border:2px dashed #DDE3F0;border-radius:8px;padding:20px;text-align:center;cursor:pointer;"
onclick="document.getElementById('fileInput').click()">
<div style="font-size:36px;">􀀂</div>
<p style="margin:4px 0;font-size:13px;color:#6B7A99;">Klik untuk pilih file PDF</p>
<small style="color:#999;">Maks. 10MB</small>
<input type="file" id="fileInput" accept=".pdf" style="display:none;"
onchange="uploadFile(this, ${item.submission_id})">
</div>
<div id="uploadProgress" style="display:none;margin-top:12px;">
<div style="background:#f0f0f0;border-radius:4px;height:6px;overflow:hidden;">
<div id="progressBar" style="background:#E53935;height:100%;width:0%;transition:width 0.3s;"></div>
</div>
<p id="progressText" style="font-size:12px;color:#6B7A99;margin-top:4px;">Mengupload...</p>
</div>
<div style="display:flex;gap:8px;margin-top:16px;justify-content:flex-end;">
<button class="btn btn-outline btn-sm" onclick="closeUploadModal()">Batal</button>
</div>
</div>
`;
document.body.appendChild(modal);
uploadModal = modal;
} catch (e) {
showToast('Gagal membuka modal: ' + e.message, 'error');
}
}
function closeUploadModal() {
if (uploadModal) {
uploadModal.remove();
uploadModal = null;
}
}
function uploadFile(input, submissionId) {
var file = input.files[0];
if (!file) return;
// Validasi
if (file.type !== 'application/pdf') {
showToast('Hanya file PDF yang diizinkan', 'error');
input.value = '';
return;
}
if (file.size > 10 * 1024 * 1024) {
showToast('File terlalu besar. Maks 10MB', 'error');
input.value = '';
return;
}
// Tampilkan progress
document.getElementById('uploadProgress').style.display = 'block';
document.getElementById('progressText').textContent = 'Mengupload ' + file.name + '...';
document.getElementById('progressBar').style.width = '30%';
var formData = new FormData();
formData.append('file', file);
formData.append('submission_id', submissionId);
fetch('api/upload_file.php', {
method: 'POST',
body: formData
})
.then(function(res) { return res.json(); })
.then(function(result) {
document.getElementById('progressBar').style.width = '100%';
if (result.success) {
document.getElementById('progressText').textContent = result.message;
document.getElementById('progressText').style.color = '#1A7A45';
// Update status di localStorage
updateSubmissionStatus(submissionId, 'submitted');
setTimeout(function() {
closeUploadModal();
loadRiwayat();
showToast('File berhasil dikirim!', 'success');
}, 1500);
} else {
document.getElementById('progressText').textContent = result.message;
document.getElementById('progressText').style.color = '#C62828';
document.getElementById('progressBar').style.width = '0%';
showToast(result.message, 'error');
}
})
.catch(function(err) {
document.getElementById('progressText').textContent = 'Gagal upload: ' + err.message;
document.getElementById('progressText').style.color = '#C62828';
document.getElementById('progressBar').style.width = '0%';
showToast('Gagal upload', 'error');
});
}
function updateSubmissionStatus(submissionId, newStatus) {
try {
var history = JSON.parse(localStorage.getItem('form_history') || '[]');
var formKey = 'form_sppd';
var userId = <?= $_SESSION['user_id'] ?>;
var index = history.findIndex(function(item) {
return item.form_key === formKey &&
item.user_id === userId &&
item.submission_id === submissionId;
});
if (index >= 0) {
history[index].status = newStatus;
history[index].updated_at = new Date().toISOString();
localStorage.setItem('form_history', JSON.stringify(history));
}
} catch (e) {
console.error('Update status error:', e);
}
}

</script>
<?php include 'bottom_nav.php'; ?>

</body>
</html>