<?php
// ============================================================
// BOTTOM NAVIGATION - MOBILE ONLY
// ============================================================
$current_page = basename($_SERVER['PHP_SELF']);

// Hitung notifikasi yang belum dibaca (jika belum dihitung di file lain)
if (!isset($unreadTotal) && isset($_SESSION['user_id']) && isset($pdo)) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$_SESSION['user_id']]);
    $unreadTotal = $stmt->fetchColumn();
}
?>
<nav class="bottom-nav">
    <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>">
        <span class="nav-icon">🏠</span>
        <span class="nav-label">Dashboard</span>
    </a>
    
    <!-- MENU NOTIFIKASI DENGAN BADGE -->
    <a href="notifications.php" class="nav-item-notif <?= $current_page == 'notifications.php' ? 'active' : '' ?>">
        <span class="nav-icon">🔔</span>
        <span class="nav-label">Notif</span>
        <?php if (!empty($unreadTotal) && $unreadTotal > 0): ?>
            <span class="nav-badge"><?= $unreadTotal > 99 ? '99+' : $unreadTotal ?></span>
        <?php endif; ?>
    </a>
    
    <a href="profile.php" class="<?= $current_page == 'profile.php' ? 'active' : '' ?>">
        <span class="nav-icon">👤</span>
        <span class="nav-label">Profil</span>
    </a>
    <a href="logout.php" class="logout">
        <span class="nav-icon">🚪</span>
        <span class="nav-label">Logout</span>
    </a>
</nav>