<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) {
    die('ID tidak valid');
}

// Cek submission
$stmt = $pdo->prepare("
    SELECT s.*, f.form_name, f.form_key, u.fullname, u.username 
    FROM form_submissions s 
    JOIN forms f ON s.form_id = f.id 
    JOIN users u ON s.user_id = u.id 
    WHERE s.id = ?
");
$stmt->execute([$id]);
$submission = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$submission) {
    die('Submission tidak ditemukan');
}

// Cek akses: user bisa lihat milik sendiri, admin bisa lihat user yang dibuatnya
$role = $_SESSION['role'] ?? 'user';
$user_id = $_SESSION['user_id'];

if ($role === 'user' && $submission['user_id'] != $user_id) {
    die('⛔ Anda tidak memiliki akses');
}

if (!in_array($role, ['super_admin', 'admin']) && $submission['user_id'] != $user_id) {
    // Cek apakah user ini dibuat oleh admin yang login
    $stmt2 = $pdo->prepare("SELECT created_by FROM users WHERE id = ?");
    $stmt2->execute([$submission['user_id']]);
    $userData = $stmt2->fetch(PDO::FETCH_ASSOC);
    if ($userData['created_by'] != $user_id) {
        die('⛔ Anda tidak memiliki akses');
    }
}

$form_data = json_decode($submission['form_data'], true);
$form_key = $submission['form_key'];
$form_name = $submission['form_name'];

// Ambil file form untuk preview
$form_file = $form_key . '.php';
$file_exists = file_exists($form_file);

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Submission - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .detail-container { max-width: 900px; margin: 0 auto; }
        .detail-card { background: #fff; border-radius: 12px; padding: 24px; margin-bottom: 16px; border: 1px solid #DDE3F0; }
        .detail-card h3 { margin: 0 0 12px; color: #1A1A2E; }
        .detail-card .field { margin-bottom: 8px; }
        .detail-card .field .label { font-weight: 600; color: #6B7A99; font-size: 12px; text-transform: uppercase; }
        .detail-card .field .value { font-size: 14px; color: #1A1A2E; padding: 4px 8px; background: #F8F9FC; border-radius: 4px; }
        .status-badge { display: inline-block; padding: 4px 14px; border-radius: 20px; font-size: 13px; font-weight: 600; }
        .status-draft { background: #EEF0F6; color: #6B7A99; }
        .status-submitted { background: #FFFBEE; color: #B07A00; }
        .status-approved { background: #EEFAF4; color: #1A7A45; }
        .status-rejected { background: #FFE5E5; color: #C62828; }
        .btn-back { background: #6B7A99; color: #fff; padding: 8px 20px; border-radius: 8px; text-decoration: none; display: inline-block; }
        .btn-back:hover { background: #5a6a89; }
        .json-view { background: #1A1A2E; color: #9AA6C0; padding: 16px; border-radius: 8px; font-family: monospace; font-size: 12px; overflow-x: auto; white-space: pre-wrap; word-wrap: break-word; max-height: 400px; overflow-y: auto; }
    </style>
</head>
<body>
<div class="app">
    <main class="main">
        <div class="detail-container">
            <header class="topbar">
                <div class="topbar-left"><h2>📄 Detail Submission</h2></div>
                <div class="topbar-right">
                    <a href="admin.php" class="btn-back">← Kembali</a>
                </div>
            </header>

            <div class="detail-card">
                <h3>📋 Informasi Submission</h3>
                <div class="field"><span class="label">ID</span><div class="value">#<?= $submission['id'] ?></div></div>
                <div class="field"><span class="label">User</span><div class="value"><?= htmlspecialchars($submission['fullname']) ?> (<?= htmlspecialchars($submission['username']) ?>)</div></div>
                <div class="field"><span class="label">Form</span><div class="value"><?= htmlspecialchars($submission['form_name']) ?></div></div>
                <div class="field"><span class="label">Status</span><div class="value"><span class="status-badge status-<?= $submission['status'] ?>"><?= strtoupper($submission['status']) ?></span></div></div>
                <div class="field"><span class="label">Dikirim</span><div class="value"><?= date('d/m/Y H:i:s', strtotime($submission['submitted_at'] ?? $submission['created_at'])) ?></div></div>
                <?php if ($submission['admin_note']): ?>
                <div class="field"><span class="label">Catatan Admin</span><div class="value" style="background:#FFE5E5;color:#C62828;padding:8px 12px;"><?= htmlspecialchars($submission['admin_note']) ?></div></div>
                <?php endif; ?>
                <?php if ($submission['pdf_path']): ?>
                <div class="field"><span class="label">PDF</span><div class="value"><a href="<?= $submission['pdf_path'] ?>" target="_blank" class="btn btn-sm btn-primary">📄 Lihat PDF</a></div></div>
                <?php endif; ?>
            </div>

            <div class="detail-card">
                <h3>📝 Data Form</h3>
                <div class="json-view"><?= json_encode($form_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?></div>
            </div>

            <?php if ($file_exists): ?>
            <div class="detail-card">
                <h3>🔗 Buka Form</h3>
                <a href="<?= $form_file ?>?edit=<?= $submission['id'] ?>" class="btn btn-primary" target="_blank">📝 Buka Form</a>
            </div>
            <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>
