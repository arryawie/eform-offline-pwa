<?php
// ============================================================
// DASHBOARD STATISTIK - SUPER ADMIN
// ============================================================
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

if ($_SESSION['role'] !== 'super_admin') {
    header('Location: dashboard.php');
    exit;
}

// ============================================================
// STATISTIK GLOBAL
// ============================================================
$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user' AND created_by IS NOT NULL");
$totalUser = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM form_submissions");
$totalSubmission = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(DISTINCT instansi) FROM users WHERE role = 'user' AND instansi IS NOT NULL AND instansi != ''");
$totalInstansi = $stmt->fetchColumn();

// ============================================================
// STATISTIK STATUS SUBMISSION
// ============================================================
$stmt = $pdo->query("
    SELECT status, COUNT(*) as total 
    FROM form_submissions 
    GROUP BY status
");
$statusData = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$statusApproved = $statusData['approved'] ?? 0;
$statusPending = $statusData['submitted'] ?? 0;
$statusRejected = $statusData['rejected'] ?? 0;
$statusDraft = ($statusData['draft'] ?? 0) + ($statusData['downloaded'] ?? 0);

// ============================================================
// STATISTIK PER INSTANSI
// ============================================================
$stmt = $pdo->query("
    SELECT 
        u.instansi,
        COUNT(DISTINCT u.id) as total_user,
        COUNT(DISTINCT CASE WHEN f.form_key = 'form_a' AND s.status IN ('submitted', 'approved') THEN u.id END) as user_kirim_form_a,
        COUNT(DISTINCT CASE WHEN f.form_key = 'form_sppd' AND s.status IN ('submitted', 'approved') THEN u.id END) as user_kirim_form_sppd
    FROM users u
    LEFT JOIN form_submissions s ON s.user_id = u.id
    LEFT JOIN forms f ON s.form_id = f.id
    WHERE u.role = 'user'
      AND u.created_by IS NOT NULL
      AND u.instansi IS NOT NULL
      AND u.instansi != ''
    GROUP BY u.instansi
    ORDER BY u.instansi ASC
");
$perInstansi = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Super Admin</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .stats-top { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 24px; }
        .stat-card { background: #fff; border-radius: 12px; padding: 20px; text-align: center; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .stat-card .num { font-size: 32px; font-weight: 800; }
        .stat-card .label { font-size: 12px; color: #6B7A99; text-transform: uppercase; margin-top: 4px; }
        .stat-card.blue .num { color: #2D5BE3; }
        .stat-card.green .num { color: #1A7A45; }
        .stat-card.orange .num { color: #F5A623; }
        .charts-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; }
        .chart-card { background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .chart-card h3 { margin: 0 0 16px; font-size: 14px; color: #1A1A2E; }
        .chart-container { position: relative; height: 280px; }
        .card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .card h2 { margin: 0 0 16px; font-size: 16px; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th { background: #F8F9FC; padding: 12px; text-align: left; font-size: 11px; text-transform: uppercase; color: #6B7A99; border-bottom: 2px solid #DDE3F0; font-weight: 700; }
        td { padding: 12px; border-bottom: 1px solid #EEF0F6; }
        tr:hover { background: #FAFBFD; }
        .instansi-name { font-weight: 700; color: #1A1A2E; }
        .status-badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; }
        .status-badge.ok { background: #EEFAF4; color: #1A7A45; }
        .status-badge.partial { background: #FFFBEE; color: #B07A00; }
        .status-badge.none { background: #FFE5E5; color: #C62828; }
        @media (max-width: 768px) {
            .stats-top { grid-template-columns: 1fr; }
            .charts-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="app">
    <main class="main">
        <div class="container">
            <h1>📊 Dashboard Super Admin</h1>
            <p style="color: #6B7A99; margin-bottom: 20px;">Ringkasan aktivitas seluruh instansi</p>
            
            <div class="stats-top">
                <div class="stat-card blue">
                    <div class="num"><?= $totalInstansi ?></div>
                    <div class="label">🏢 Total Instansi</div>
                </div>
                <div class="stat-card green">
                    <div class="num"><?= $totalUser ?></div>
                    <div class="label">👥 Total User</div>
                </div>
                <div class="stat-card orange">
                    <div class="num"><?= $totalSubmission ?></div>
                    <div class="label">📋 Total Submission</div>
                </div>
            </div>
            
            <div class="charts-grid">
                <div class="chart-card">
                    <h3>📊 Status Submission</h3>
                    <div class="chart-container"><canvas id="chartStatus"></canvas></div>
                </div>
                <div class="chart-card">
                    <h3>📈 Submission Per Instansi</h3>
                    <div class="chart-container"><canvas id="chartInstansi"></canvas></div>
                </div>
            </div>
            
            <div class="card">
                <h2>🏢 Detail Per Instansi</h2>
                <?php if (empty($perInstansi)): ?>
                <div style="text-align:center;padding:40px;color:#6B7A99;">Belum ada data instansi</div>
                <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Instansi</th>
                            <th style="text-align:center;">Form A</th>
                            <th style="text-align:center;">Form SPPD</th>
                            <th style="text-align:center;">Status</th>
                            <th style="text-align:center;">User</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($perInstansi as $row): 
                            $totalU = $row['total_user'];
                            $formA = $row['user_kirim_form_a'];
                            $formSppd = $row['user_kirim_form_sppd'];
                            
                            if ($formA == $totalU && $formSppd == $totalU) {
                                $status = 'ok'; $statusLabel = '✅ Lengkap';
                            } elseif ($formA == 0 && $formSppd == 0) {
                                $status = 'none'; $statusLabel = '❌ Belum';
                            } else {
                                $status = 'partial'; $statusLabel = '⏳ Sebagian';
                            }
                        ?>
                        <tr>
                            <td><span class="instansi-name"><?= htmlspecialchars($row['instansi']) ?></span></td>
                            <td style="text-align:center;"><strong><?= $formA ?>/<?= $totalU ?></strong></td>
                            <td style="text-align:center;"><strong><?= $formSppd ?>/<?= $totalU ?></strong></td>
                            <td style="text-align:center;"><span class="status-badge <?= $status ?>"><?= $statusLabel ?></span></td>
                            <td style="text-align:center;"><strong><?= $totalU ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<script>
var ctxStatus = document.getElementById('chartStatus').getContext('2d');
new Chart(ctxStatus, {
    type: 'doughnut',
    data: {
        labels: ['✅ Approved', '⏳ Pending', '❌ Reject', '📝 Draft'],
        datasets: [{
            data: [<?= $statusApproved ?>, <?= $statusPending ?>, <?= $statusRejected ?>, <?= $statusDraft ?>],
            backgroundColor: ['#1A7A45', '#F5A623', '#C62828', '#6B7A99']
        }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
});

var ctxInstansi = document.getElementById('chartInstansi').getContext('2d');
new Chart(ctxInstansi, {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_column($perInstansi, 'instansi')) ?>,
        datasets: [{
            label: 'Total User',
            data: <?= json_encode(array_column($perInstansi, 'total_user')) ?>,
            backgroundColor: '#2D5BE3'
        }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
});
</script>
</body>
</html>