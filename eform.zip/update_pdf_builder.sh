#!/bin/bash

# Cari dan ganti fungsi buildPDFHTML dengan yang lengkap
sed -i '/function buildPDFHTML() {/,/^    }/c\
    function buildPDFHTML() {\
        function v(id) { var el = document.getElementById(id); return el ? el.value.trim() : ""; }\
        function esc(s) { return (s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }\
        function nl(s) { return esc(s||"").replace(/\\n/g,"<br>"); }\
        function yesno(val) { return val ? (val === "Ya" ? "Ya" : val) : ""; }\
        function fdate(s) { if(!s) return ""; var d=new Date(s); var M=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"]; return d.getDate()+" "+M[d.getMonth()]+" "+d.getFullYear(); }\
        function bool(val) { return val ? "Ya" : "Tidak"; }\
        function onoff(checked) { return checked ? "☑ Ada" : "☐ Tidak Ada"; }\
\
        var html = "<div class=\"pdf-page\">";\
        // KOP\
        html += "<div class=\"kop\">";\
        if ("<?= $kop_logo ?>") html += "<img src=\"<?= $kop_logo ?>\"><br>";\
        html += "<div class=\"instansi\"><?= htmlspecialchars($kop_instansi) ?></div>";\
        if ("<?= $kop_alamat ?>") html += "<div class=\"alamat\"><?= htmlspecialchars($kop_alamat) ?></div>";\
        if ("<?= $kop_telp ?>" || "<?= $kop_email ?>") {\
            html += "<div class=\"alamat\">";\
            if ("<?= $kop_telp ?>") html += "Telp: <?= htmlspecialchars($kop_telp) ?>";\
            if ("<?= $kop_telp ?>" && "<?= $kop_email ?>") html += " | ";\
            if ("<?= $kop_email ?>") html += "Email: <?= htmlspecialchars($kop_email) ?>";\
            html += "</div>";\
        }\
        html += "</div>";\
\
        html += "<div class=\"pdf-title\">FORM A</div>";\
        html += "<div class=\"pdf-subtitle\">LAPORAN HASIL PENGAWASAN PEMILIHAN</div>";\
        html += "<div class=\"pdf-nomor\">Nomor: "+esc(v("nomor"))+"</div>";\
\
        // I. DATA PENGAWASAN\
        html += "<div class=\"pdf-section\">I. Data Pengawasan</div>";\
        html += "<table class=\"pdf-tbl\">";\
        html += "<tr><td class=\"label-col\">1. Tahapan yang diawasi</td><td class=\"sep-col\">:</td><td>"+esc(v("tahapan"))+"</td></tr>";\
        html += "<tr><td class=\"label-col\">2. Nama Pelaksana Tugas Pengawasan</td><td class=\"sep-col\">:</td><td>"+nl(v("nama_pengawas"))+"</td></tr>";\
        html += "<tr><td class=\"label-col\">3. Jabatan</td><td class=\"sep-col\">:</td><td>"+nl(v("jabatan"))+"</td></tr>";\
        html += "<tr><td class=\"label-col\">4. Nomor Surat Perintah Tugas</td><td class=\"sep-col\">:</td><td>"+esc(v("no_st"))+"</td></tr>";\
        html += "<tr><td class=\"label-col\">5. Alamat</td><td class=\"sep-col\">:</td><td>"+nl(v("alamat"))+"</td></tr>";\
        html += "</table>";\
\
        // II. KEGIATAN PENGAWASAN\
        html += "<div class=\"pdf-section\">II. Kegiatan Pengawasan</div>";\
        html += "<table class=\"pdf-tbl\">";\
        html += "<tr><td class=\"label-col\">1. Bentuk</td><td class=\"sep-col\">:</td><td>"+esc(v("bentuk"))+"</td></tr>";\
        html += "<tr><td class=\"label-col\">2. Tujuan</td><td class=\"sep-col\">:</td><td>"+nl(v("tujuan"))+"</td></tr>";\
        html += "<tr><td class=\"label-col\">3. Sasaran</td><td class=\"sep-col\">:</td><td>"+nl(v("sasaran"))+"</td></tr>";\
        html += "<tr><td class=\"label-col\">4. Waktu dan Tempat</td><td class=\"sep-col\">:</td><td>"+fdate(v("tgl_kegiatan"))+"<br>"+esc(v("tempat_kegiatan"))+"</td></tr>";\
        html += "</table>";\
\
        // III. URAIAN SINGKAT\
        html += "<div class=\"pdf-section\">III. Uraian Singkat Hasil Pengawasan</div>";\
        html += "<p style=\"text-align:justify;\">"+nl(v("uraian"))+"</p>";\
\
        // IV. DUGAAAN PELANGGARAN\
        html += "<div class=\"pdf-section\">IV. Informasi Dugaan Pelanggaran</div>";\
        var adaP = document.getElementById("ada_pelanggaran").checked;\
        if (adaP) {\
            html += "<table class=\"pdf-tbl\">";\
            html += "<tr><td class=\"label-col\">1. Peristiwa</td><td class=\"sep-col\">:</td><td>"+nl(v("p_peristiwa"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">b. Tempat Kejadian</td><td class=\"sep-col\">:</td><td>"+esc(v("p_tempat"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">c. Waktu Kejadian</td><td class=\"sep-col\">:</td><td>"+esc(v("p_waktu"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">d. Pelaku</td><td class=\"sep-col\">:</td><td>"+esc(v("p_pelaku"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">e. Alamat</td><td class=\"sep-col\">:</td><td>"+esc(v("p_alamat_pelaku"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">2. Saksi-saksi</td><td class=\"sep-col\">:</td><td>"+esc(v("saksi1_nama"))+" ("+esc(v("saksi1_alamat"))+")<br>"+esc(v("saksi2_nama"))+" ("+esc(v("saksi2_alamat"))+")</td></tr>";\
            html += "<tr><td class=\"label-col\">3. Alat Bukti</td><td class=\"sep-col\">:</td><td>"+esc(v("bukti_a"))+"<br>"+esc(v("bukti_b"))+"<br>"+esc(v("bukti_c"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">4. Barang Bukti</td><td class=\"sep-col\">:</td><td>"+esc(v("barang_a"))+"<br>"+esc(v("barang_b"))+"<br>"+esc(v("barang_c"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">5. Uraian Singkat</td><td class=\"sep-col\">:</td><td>"+nl(v("uraian_pelanggaran"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">6. Fakta dan Keterangan</td><td class=\"sep-col\">:</td><td>"+nl(v("fakta"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">7. Analisa</td><td class=\"sep-col\">:</td><td>"+nl(v("analisa"))+"</td></tr>";\
            html += "</table>";\
        } else {\
            html += "<p style=\"font-style:italic;color:#666;\">Nihil</p>";\
        }\
\
        // V. POTENSI SENGKETA\
        html += "<div class=\"pdf-section\">V. Informasi Potensi Sengketa</div>";\
        var adaS = document.getElementById("ada_sengketa").checked;\
        if (adaS) {\
            html += "<table class=\"pdf-tbl\">";\
            html += "<tr><td class=\"label-col\">1. Peristiwa</td><td class=\"sep-col\">:</td><td>"+esc(v("s_peserta"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">b. Tempat Kejadian</td><td class=\"sep-col\">:</td><td>"+esc(v("s_tempat"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">c. Waktu Kejadian</td><td class=\"sep-col\">:</td><td>"+esc(v("s_waktu"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">2. Obyek Sengketa</td><td class=\"sep-col\">:</td><td>"+esc(v("s_bentuk"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">b. Identitas</td><td class=\"sep-col\">:</td><td>"+esc(v("s_identitas"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">c. Tanggal</td><td class=\"sep-col\">:</td><td>"+esc(v("s_tgl_keluar"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">d. Kerugian</td><td class=\"sep-col\">:</td><td>"+esc(v("s_kerugian"))+"</td></tr>";\
            html += "<tr><td class=\"label-col\">3. Uraian Singkat</td><td class=\"sep-col\">:</td><td>"+nl(v("s_uraian"))+"</td></tr>";\
            html += "</table>";\
        } else {\
            html += "<p style=\"font-style:italic;color:#666;\">Nihil</p>";\
        }\
\
        // TTD\
        html += "<div class=\"pdf-ttd\">";\
        html += "<p>"+esc(v("ttd_kota"))+", "+fdate(v("ttd_tgl"))+"</p>";\
        html += "<p class=\"jabatan\">"+esc(v("ttd_jabatan"))+"</p>";\
        html += "<span class=\"nama\">"+esc(v("ttd_nama"))+"</span>";\
        html += "</div>";\
\
        // FOTO\
        if (photos.length > 0) {\
            html += "<div class=\"pdf-foto-title\">DOKUMENTASI</div>";\
            if (v("foto_judul")) html += "<p style=\"text-align:center;font-size:9pt;font-style:italic;\">"+esc(v("foto_judul"))+"</p>";\
            html += "<div class=\"pdf-foto-grid\">";\
            photos.forEach(function(p) {\
                html += "<div class=\"pdf-foto-item\"><img src=\""+p.src+"\"><p>"+esc(p.caption||"")+"</p></div>";\
            });\
            html += "</div>";\
        }\
\
        html += "</div>";\
        return html;\
    }' form_a.php

echo "✅ PDF Builder sudah diupdate - menampilkan SEMUA field!"
