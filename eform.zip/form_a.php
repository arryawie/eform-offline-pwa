<?php
// ============================================================
// FORM A - LAPORAN HASIL PENGAWASAN PEMILIHAN
// ============================================================
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

$form_key = 'form_a';
$form_title = 'Form A - Laporan Hasil Pengawasan Pemilu';

if (!canAccessForm($form_key)) {
    die("<h1>⛔ Akses Ditolak</h1><p>Anda tidak memiliki akses ke form ini.</p><a href='dashboard.php'>← Kembali</a>");
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? 'user';

// Cek apakah user Super Admin atau Admin
if (in_array($role, ['super_admin', 'admin'])) {
    // Ambil form milik user tersebut
    $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id = ?");
    $stmt->execute([$form_key, $user_id]);
    $form = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$form) {
        // Buat form default untuk user
        $stmt = $pdo->prepare("INSERT INTO forms (form_key, form_name, user_id, is_active) VALUES (?, ?, ?, 1)");
        $stmt->execute([$form_key, $form_title, $user_id]);
        
        $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id = ?");
        $stmt->execute([$form_key, $user_id]);
        $form = $stmt->fetch(PDO::FETCH_ASSOC);
    }
} else {
    // User: ambil dari admin yang membuatnya (created_by)
    $stmt = $pdo->prepare("SELECT created_by FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($userData && $userData['created_by']) {
        $adminId = $userData['created_by'];
        $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id = ?");
        $stmt->execute([$form_key, $adminId]);
        $form = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    if (!$form) {
        // Fallback: ambil form default (user_id NULL)
        $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id IS NULL");
        $stmt->execute([$form_key]);
        $form = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

$kop_logo = $form['kop_logo'] ?? '';
$kop_instansi = $form['kop_instansi'] ?? 'BADAN PENGAWAS PEMILIHAN UMUM';
$kop_alamat = $form['kop_alamat'] ?? '';
$kop_telp = $form['kop_telp'] ?? '';
$kop_email = $form['kop_email'] ?? '';

if (!$form || $form['is_active'] != 1) {
    die("<h1>⚠️ Form sedang tidak aktif</h1>");
}

$kop_logo = $form['kop_logo'] ?? '';
$kop_instansi = $form['kop_instansi'] ?? 'BADAN PENGAWAS PEMILIHAN UMUM';
$kop_alamat = $form['kop_alamat'] ?? '';
$kop_telp = $form['kop_telp'] ?? '';
$kop_email = $form['kop_email'] ?? '';

$submissions = $pdo->prepare("
    SELECT s.*, f.form_name, f.icon 
    FROM form_submissions s 
    JOIN forms f ON s.form_id = f.id 
    WHERE s.user_id = ? AND f.form_key = ? 
    ORDER BY s.created_at DESC 
    LIMIT 20
");
$submissions->execute([$_SESSION['user_id'], $form_key]);
$submissionList = $submissions->fetchAll(PDO::FETCH_ASSOC);
// Ambil submission_id terbaru
$submission_id = 0; // ← Jangan auto-ambil dari database

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $form_title ?> - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- Quill Editor -->
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>

    <!-- Quill Better Table (insert / edit / merge tabel di dalam editor) -->
    <link href="https://cdn.jsdelivr.net/npm/quill-better-table@1.2.10/dist/quill-better-table.css" rel="stylesheet">
    <script>
    // Coba beberapa sumber CDN berbeda untuk quill-better-table. Kalau salah satu
    // gagal (mis. diblok jaringan), otomatis coba sumber berikutnya sebelum
    // benar-benar menyerah ke mode fallback.
    window.__loadBetterTable = function () {
        return new Promise(function (resolve) {
            if (typeof QuillBetterTable !== 'undefined') { resolve(true); return; }
            var sources = [
                'https://cdn.jsdelivr.net/npm/quill-better-table@1.2.10/dist/quill-better-table.js',
                'https://unpkg.com/quill-better-table@1.2.10/dist/quill-better-table.js',
                'https://cdnjs.cloudflare.com/ajax/libs/quill-better-table/1.2.10/quill-better-table.js'
            ];
            var i = 0;
            (function tryNext() {
                if (i >= sources.length) { resolve(false); return; }
                var s = document.createElement('script');
                s.src = sources[i++];
                s.onload = function () { resolve(typeof QuillBetterTable !== 'undefined'); };
                s.onerror = tryNext;
                document.head.appendChild(s);
            })();
        });
    };
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    
    <style>
        * { box-sizing: border-box; }
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; margin:0; }
        .form-container { max-width: 900px; margin: 0 auto; padding: 20px; }
        .topbar { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; background: #fff; padding: 15px 20px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .topbar h2 { margin: 0; font-size: 18px; color: #1A1A2E; }
        .tab-bar { display: flex; gap: 4px; background: #fff; border-radius: 12px; padding: 4px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); flex-wrap:wrap; }
        .tab-btn { padding: 10px 24px; border: none; border-radius: 8px; background: transparent; font-weight: 600; cursor: pointer; color: #6B7A99; transition: 0.2s; font-size: 14px; }
        .tab-btn.active { background: #E53935; color: #fff; }
        .tab-btn:hover:not(.active) { background: #f0f0f0; }
        .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); margin-bottom: 16px; overflow: hidden; }
        .card-header { padding: 12px 20px; background: #f8f9fc; border-bottom: 1px solid #eee; font-weight: 700; color: #1A1A2E; font-size: 14px; }
        .card-body { padding: 16px 20px; }
        .form-group { margin-bottom: 12px; }
        .form-group label { display: block; font-weight: 600; font-size: 13px; color: #2c3e50; margin-bottom: 4px; }
        .form-group label .req { color: #E53935; }
        .form-group input, .form-group textarea, .form-group select { width: 100%; padding: 8px 12px; border: 1.5px solid #DDE3F0; border-radius: 8px; font-size: 14px; font-family: inherit; transition: 0.2s; background: #fff; }
        .form-group input:focus, .form-group textarea:focus { border-color: #E53935; outline: none; box-shadow: 0 0 0 3px rgba(229,57,53,0.1); }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
        .btn { padding: 8px 20px; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 13px; transition: 0.2s; text-decoration: none; display: inline-block; }
        .btn-primary { background: #E53935; color: #fff; }
        .btn-primary:hover { background: #c62828; }
        .btn-secondary { background: #6B7A99; color: #fff; }
        .btn-secondary:hover { background: #5a6a89; }
        .btn-success { background: #2E7D32; color: #fff; }
        .btn-success:hover { background: #1B5E20; }
        .btn-outline { background: transparent; color: #E53935; border: 1.5px solid #E53935; }
        .btn-outline:hover { background: #FFF5F5; }
        .btn-sm { padding: 4px 12px; font-size: 12px; }
        .btn-row { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 16px; }
        .btn-row .btn { flex: 1; min-width: 100px; text-align: center; }
        .alert { padding: 10px 16px; border-radius: 8px; margin-bottom: 12px; font-size: 13px; }
        .alert-info { background: #EEF4FF; color: #2D5BE3; border: 1px solid #C3D4F9; }
        .toggle-row { display: flex; align-items: center; gap: 12px; margin: 8px 0; }
        .toggle-switch { position: relative; width: 44px; height: 24px; flex-shrink: 0; }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .toggle-slider { position: absolute; inset: 0; background: #ccc; border-radius: 24px; transition: 0.2s; cursor: pointer; }
        .toggle-slider::before { content: ""; position: absolute; width: 18px; height: 18px; left: 3px; bottom: 3px; background: #fff; border-radius: 50%; transition: 0.2s; }
        .toggle-switch input:checked + .toggle-slider { background: #E53935; }
        .toggle-switch input:checked + .toggle-slider::before { transform: translateX(20px); }
        .toggle-extra { display: none; padding: 10px 0; }
        .toggle-extra.show { display: block; }
        .toggle-empty { text-align: center; padding: 10px 0; color: #999; font-size: 12px; font-style: italic; }
        .sec-label { font-size: 12px; font-weight: 700; color: #E53935; margin: 12px 0 6px; padding-bottom: 4px; border-bottom: 2px solid rgba(229,57,53,0.12); text-transform: uppercase; }
        .photo-zone { border: 2px dashed #DDE3F0; border-radius: 8px; padding: 16px; text-align: center; cursor: pointer; transition: 0.2s; background: #FAFBFD; }
        .photo-zone:hover { border-color: #E53935; background: #FFF5F5; }
        .photo-zone input { display: none; }
        .photo-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 10px; margin-top: 10px; }
        .photo-item { position: relative; border-radius: 8px; overflow: hidden; aspect-ratio: 4/3; border: 1.5px solid #DDE3F0; background: #f0f0f0; }
        .photo-item img { width: 100%; height: 100%; object-fit: cover; }
        .photo-item .caption-input { position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0,0,0,0.6); padding: 4px 7px; border: none; color: #fff; font-size: 10px; font-family: inherit; width: 100%; outline: none; }
        .photo-item .remove-btn { position: absolute; top: 4px; right: 4px; width: 22px; height: 22px; background: rgba(229,57,53,0.85); border: none; border-radius: 50%; color: #fff; font-size: 12px; cursor: pointer; }
        .status-badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
        .status-badge.draft { background: #EEF0F6; color: #6B7A99; }
        .status-badge.previewed { background: #EEF4FF; color: #2D5BE3; }
        .status-badge.downloaded { background: #EEFAF4; color: #1A7A45; }
        .status-badge.submitted { background: #FFFBEE; color: #B07A00; }
        .status-badge.approved { background: #EEFAF4; color: #1A7A45; }
        .status-badge.rejected { background: #FFE5E5; color: #C62828; }
        .submission-table { width: 100%; border-collapse: collapse; font-size: 12px; }
        .submission-table th { text-align: left; padding: 6px 8px; background: #F8F9FC; color: #6B7A99; font-weight: 700; font-size: 11px; text-transform: uppercase; border-bottom: 2px solid #DDE3F0; }
        .submission-table td { padding: 6px 8px; border-bottom: 1px solid #EEF0F6; vertical-align: middle; }
        .submission-table tr:hover { background: #FAFBFD; }
        .btn-edit { background: #2D5BE3; color: #fff; border: none; padding: 2px 10px; border-radius: 4px; font-size: 11px; cursor: pointer; }
        .btn-edit:hover { background: #1A3F8A; }
        .btn-preview { background: #F5A623; color: #fff; border: none; padding: 2px 10px; border-radius: 4px; font-size: 11px; cursor: pointer; }
        .btn-preview:hover { background: #d4911a; }
        #previewArea { background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); overflow: hidden; }
        .preview-toolbar { background: #f8f9fc; padding: 12px 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; }
        .preview-content { padding: 20px; max-height: 700px; overflow-y: auto; }
        .pdf-page { background: #fff; padding: 30px 35px; max-width: 680px; margin: 0 auto 16px; font-family: 'Times New Roman', serif; font-size: 10.5pt; line-height: 1.6; border: 1px solid #ddd; border-radius: 4px; }
        .pdf-page .kop { text-align: center; margin-bottom: 12px; border-bottom: 2px solid #1A1A2E; padding-bottom: 10px; }
        .pdf-page .kop img { max-height: 60px; width: auto; }
        .pdf-page .kop .instansi { font-size: 13pt; font-weight: 700; color: #1A1A2E; }
        .pdf-page .kop .alamat { font-size: 8.5pt; color: #666; }
        .pdf-title { font-size: 12pt; font-weight: 700; text-align: center; text-transform: uppercase; }
        .pdf-subtitle { font-size: 11pt; font-weight: 700; text-align: center; text-transform: uppercase; margin-bottom: 4px; }
        .pdf-nomor { font-size: 10.5pt; font-weight: 700; text-align: center; margin-bottom: 12px; }
        .pdf-section { font-weight: 700; font-size: 11pt; margin: 10px 0 4px; }
        .pdf-tbl { width: 100%; border-collapse: collapse; font-size: 10pt; margin: 4px 0; }
        .pdf-tbl td { border: 1px solid #444; padding: 4px 8px; vertical-align: top; }
        .pdf-tbl .label-col { width: 180px; font-weight: 600; }
        .pdf-tbl .sep-col { width: 14px; text-align: center; }
        .pdf-ttd { text-align: center; margin-top: 20px; }
        .pdf-ttd .nama { font-weight: 700; text-decoration: underline; display: block; margin-top: 40px; }
        .pdf-ttd .jabatan { font-weight: 600; display: block; }
        .pdf-foto-title { text-align: center; font-weight: 700; font-size: 11pt; margin: 12px 0 8px; }
        .pdf-foto-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .pdf-foto-item img { width: 100%; border: 1px solid #ccc; border-radius: 4px; }
        .pdf-foto-item p { text-align: center; font-size: 8.5pt; margin-top: 3px; font-style: italic; color: #555; }
        .app { display: flex; min-height: 100vh; }
        .sidebar { width: 240px; background: #1A1A2E; color: #fff; padding: 20px; flex-shrink: 0; }
        .sidebar-brand { font-size: 20px; font-weight: 700; margin-bottom: 30px; }
        .sidebar-nav a { display: block; padding: 10px 12px; color: rgba(255,255,255,0.7); text-decoration: none; border-radius: 8px; margin-bottom: 4px; transition: 0.2s; }
        .sidebar-nav a:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .sidebar-nav .logout { color: #E53935; margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 16px; }
        .main { flex: 1; padding: 20px; background: #f0f2f5; }
        .hamburger { display: none; background: none; border: none; font-size: 24px; cursor: pointer; }
        .user-badge { background: rgba(0,0,0,0.08); padding: 4px 12px; border-radius: 20px; font-size: 13px; }
        .ql-editor { min-height: 200px; font-size: 14px; }

        /* ===== LIST RAPI: bullet/numbering dengan hanging indent ===== */
        /* Quill (quill.snow.css) punya aturan bawaan untuk ::before (margin-left: -1.5em, dll)
           dengan selector yang lebih spesifik (pakai :not(.ql-direction-rtl)) sehingga selalu
           menang dan bikin nomor/bullet "geser" tidak sejajar dengan baris lanjutan. Di bawah ini
           semua aturan bawaan tsb dinetralkan dulu (!important), baru hanging indent kita pasang. */
        .ql-editor li:not(.ql-direction-rtl)::before,
        .ql-editor li.ql-direction-rtl::before,
        .pdf-page .ql-editor li::before {
            margin-left: 0 !important;
            margin-right: 0 !important;
            text-align: left !important;
        }
        .ql-editor ol, .ql-editor ul,
        .pdf-page .ql-editor ol, .pdf-page .ql-editor ul {
            padding-left: 0 !important;
            margin: 0 0 6px 0;
        }
        .ql-editor li,
        .pdf-page .ql-editor li {
            padding-left: 1.6em !important;
            text-indent: -1.6em !important; /* hanging indent: nomor/bullet menggantung di kiri, teks lanjutan rata dgn baris pertama */
            list-style-type: none;
        }
        .ql-editor li::before,
        .pdf-page .ql-editor li::before {
            display: inline-block;
            width: 1.4em;
            text-indent: 0;
        }
        /* level indent tambahan (tombol Indent di toolbar) - !important supaya menang dari
           aturan bawaan Quill (.ql-editor .ql-indent-1:not(.ql-direction-rtl), dst) */
        .ql-editor li.ql-indent-1, .pdf-page .ql-editor li.ql-indent-1 { padding-left: 4.6em !important; text-indent: -1.6em !important; }
        .ql-editor li.ql-indent-2, .pdf-page .ql-editor li.ql-indent-2 { padding-left: 7.6em !important; text-indent: -1.6em !important; }
        .ql-editor li.ql-indent-3, .pdf-page .ql-editor li.ql-indent-3 { padding-left: 10.6em !important; text-indent: -1.6em !important; }

        /* ===== TABEL di dalam konten uraian ===== */
        .ql-editor table, .ql-editor table.ql-table {
            border-collapse: collapse;
            width: 100%;
            margin: 8px 0;
            table-layout: fixed;
        }
        .ql-editor table td, .ql-editor table th {
            border: 1px solid #888;
            padding: 5px 8px;
            vertical-align: top;
            font-size: inherit;
            text-align: left;
        }
        .ql-editor table th { background: #f0f0f0; font-weight: 700; }
        .pdf-page .ql-editor table td, .pdf-page .ql-editor table th { font-size: 10pt; }
        .ql-toolbar .ql-insertTable .ql-table-icon { font-size: 15px; line-height: 1; }

        /* ===== TABEL FALLBACK (tanpa quill-better-table): editable + resizable ===== */
        .simple-table-wrap { position: relative; margin: 6px 0; display: inline-block; max-width: 100%; }
        .simple-table-wrap table.ql-table { border-collapse: collapse; width: auto; table-layout: fixed; margin: 0; }
        .simple-table-wrap table.ql-table td { border: 1px solid #888; padding: 5px 8px; min-width: 30px; vertical-align: top; }
        .col-resize-handle {
            position: absolute; width: 6px; cursor: col-resize; background: transparent; z-index: 5;
            touch-action: none; /* penting: cegah browser scroll saat drag di layar sentuh */
        }
        .col-resize-handle:hover { background: rgba(229,57,53,0.35); }
        .row-resize-handle {
            position: absolute; height: 6px; cursor: row-resize; background: transparent; z-index: 5;
            touch-action: none;
        }
        .row-resize-handle:hover { background: rgba(229,57,53,0.35); }
        
        @media (max-width: 768px) {
            .col-resize-handle { width: 14px; margin-left: -4px; }
            .row-resize-handle { height: 14px; margin-top: -4px; }
        }
    </style>
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">📋 E-Form</div>
        <nav class="sidebar-nav">
            <a href="dashboard.php">📊 Dashboard</a>
            <?php if (hasRole('super_admin') || hasRole('admin')): ?>
            <a href="admin_users.php">👥 Manajemen User</a>
            <a href="forms.php">📝 Manajemen Form</a>
            <?php endif; ?>
            <a href="notifications.php">🔔 Notifikasi</a>
            <a href="profile.php">⚙️ Profile</a>
            <a href="logout.php" class="logout">🚪 Logout</a>
        </nav>
    </aside>
    <main class="main">
        <div class="form-container">
            <div class="topbar">
                <div style="display:flex;align-items:center;gap:10px;">
                    <button class="hamburger" onclick="toggleSidebar()">☰</button>
                    <h2>📋 <?= $form_title ?></h2>
                </div>
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <span class="user-badge">👤 <?= htmlspecialchars($_SESSION['fullname']) ?></span>
                    <a href="dashboard.php" class="btn btn-secondary btn-sm" style="padding:4px 12px;font-size:12px;">← Kembali</a>
                </div>
            </div>

            <div class="tab-bar">
                <button class="tab-btn active" onclick="switchTab('form')">📝 Form</button>
                <button class="tab-btn" onclick="switchTab('preview')">👁 Preview</button>
                <button class="tab-btn" onclick="switchTab('riwayat')">📋 Riwayat</button>
            </div>

            <!-- TAB FORM -->
            <div id="tabForm">
                <div class="alert alert-info">ℹ️ Isi data lengkap. Klik <strong>Preview</strong> untuk melihat hasil dokumen.</div>
                <div id="formContainer">

                <!-- NOMOR LAPORAN -->
                <div class="card">
                    <div class="card-header">🔢 Nomor Laporan</div>
                    <div class="card-body">
                        <div class="grid-2">
                            <div class="form-group">
                                <label>Nomor Laporan <span class="req">*</span></label>
                                <input type="text" id="nomor" placeholder="">
                            </div>
                            <div class="form-group">
                                <label>Tanggal Laporan <span class="req">*</span></label>
                                <input type="date" id="tgl_laporan">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- I. DATA PENGAWASAN -->
                <div class="card">
                    <div class="card-header">I. 👤 Data Pengawasan</div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>1. Tahapan yang diawasi <span class="req">*</span></label>
                            <input type="text" id="tahapan" placeholder="">
                        </div>
                        <div class="form-group">
                            <label>2. Nama Pelaksana Tugas Pengawasan <span class="req">*</span></label>
                            <input type="text" id="nama_pengawas" placeholder="">
                        </div>
                        <div class="form-group">
                            <label>3. Jabatan <span class="req">*</span></label>
                            <input type="text" id="jabatan" placeholder="">
                        </div>
                        <div class="form-group">
                            <label>4. Nomor Surat Perintah Tugas</label>
                            <input type="text" id="no_st" placeholder="">
                        </div>
                        <div class="form-group">
                            <label>5. Alamat Sekretariat</label>
                            <input type="text" id="alamat" placeholder="">
                        </div>
                        <div class="form-group">
                            <label>Telepon</label>
                            <input type="text" id="no_telp" placeholder="">
                        </div>
                    </div>
                </div>

                <!-- II. KEGIATAN PENGAWASAN -->
                <div class="card">
                    <div class="card-header">II. 📋 Kegiatan Pengawasan</div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>1. Bentuk <span class="req">*</span></label>
                            <input type="text" id="bentuk" placeholder="">
                        </div>
                        <div class="form-group">
                            <label>2. Tujuan <span class="req">*</span></label>
                            <textarea id="tujuan" rows="2" placeholder=""></textarea>
                        </div>
                        <div class="form-group">
                            <label>3. Sasaran <span class="req">*</span></label>
                            <input type="text" id="sasaran" placeholder="">
                        </div>
                        <div class="grid-2">
                            <div class="form-group">
                                <label>4. Tanggal</label>
                                <input type="date" id="tgl_kegiatan">
                            </div>
                            <div class="form-group">
                                <label>Tempat</label>
                                <input type="text" id="tempat_kegiatan" placeholder="">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- III. URAIAN SINGKAT -->
                <div class="card">
                    <div class="card-header">III. 📝 Uraian Singkat Hasil Pengawasan</div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Uraian <span class="req">*</span></label>
                            <div id="editor_uraian" style="height: 300px; border: 1px solid #DDE3F0; border-radius: 8px;"></div>
                            <input type="hidden" id="uraian" name="uraian">
                            <small style="display:block;margin-top:6px;color:#6B7A99;">💡 Gunakan tombol <strong>list</strong> untuk bullet/nomor bertingkat rapi, dan tombol tabel (📊) di toolbar untuk menyisipkan tabel — isi sel langsung dengan mengetik, dan tarik garis tepi kolom/baris untuk mengubah ukurannya.</small>
                        </div>
                    </div>
                </div>

                <!-- IV. DUGAAAN PELANGGARAN -->
                <div class="card">
                    <div class="card-header">IV. ⚠️ Informasi Dugaan Pelanggaran</div>
                    <div class="card-body">
                        <div class="toggle-row">
                            <label class="toggle-switch">
                                <input type="checkbox" id="ada_pelanggaran" onchange="togglePelanggaran()">
                                <span class="toggle-slider"></span>
                            </label>
                            <span>Ada dugaan pelanggaran?</span>
                        </div>
                        <div id="pelanggaranFields" class="toggle-extra">
                            <div class="sec-label">1. Peristiwa</div>
                            <div class="form-group"><label>a. Peristiwa</label><textarea id="p_peristiwa" rows="2" placeholder=""></textarea></div>
                            <div class="grid-2">
                                <div class="form-group"><label>b. Tempat</label><input type="text" id="p_tempat" placeholder=""></div>
                                <div class="form-group"><label>c. Waktu</label><input type="text" id="p_waktu" placeholder=""></div>
                            </div>
                            <div class="grid-2">
                                <div class="form-group"><label>d. Pelaku</label><input type="text" id="p_pelaku" placeholder=""></div>
                                <div class="form-group"><label>e. Alamat Pelaku</label><input type="text" id="p_alamat_pelaku" placeholder=""></div>
                            </div>
                            <div class="sec-label">2. Saksi-saksi</div>
                            <div class="grid-2">
                                <div class="form-group"><label>a. Nama</label><input type="text" id="saksi1_nama" placeholder=""></div>
                                <div class="form-group"><label>Alamat</label><input type="text" id="saksi1_alamat" placeholder=""></div>
                            </div>
                            <div class="grid-2">
                                <div class="form-group"><label>b. Nama</label><input type="text" id="saksi2_nama" placeholder=""></div>
                                <div class="form-group"><label>Alamat</label><input type="text" id="saksi2_alamat" placeholder=""></div>
                            </div>
                            <div class="sec-label">3. Alat Bukti</div>
                            <div class="grid-3">
                                <div class="form-group"><label>a.</label><input type="text" id="bukti_a" placeholder=""></div>
                                <div class="form-group"><label>b.</label><input type="text" id="bukti_b" placeholder=""></div>
                                <div class="form-group"><label>c.</label><input type="text" id="bukti_c" placeholder=""></div>
                            </div>
                            <div class="sec-label">4. Barang Bukti</div>
                            <div class="grid-3">
                                <div class="form-group"><label>a.</label><input type="text" id="barang_a" placeholder=""></div>
                                <div class="form-group"><label>b.</label><input type="text" id="barang_b" placeholder=""></div>
                                <div class="form-group"><label>c.</label><input type="text" id="barang_c" placeholder=""></div>
                            </div>
                            <div class="sec-label">5. Uraian Singkat Dugaan Pelanggaran</div>
                            <div class="form-group"><textarea id="uraian_pelanggaran" rows="4" placeholder=""></textarea></div>
                            <div class="sec-label">6. Fakta dan Keterangan</div>
                            <div class="form-group"><textarea id="fakta" rows="4" placeholder=""></textarea></div>
                            <div class="sec-label">7. Analisa</div>
                            <div class="form-group"><textarea id="analisa" rows="4" placeholder=""></textarea></div>
                        </div>
                        <div id="tidakPelanggaran" class="toggle-empty">Nihil</div>
                    </div>
                </div>

                <!-- V. POTENSI SENGKETA -->
                <div class="card">
                    <div class="card-header">V. ⚡ Informasi Potensi Sengketa</div>
                    <div class="card-body">
                        <div class="toggle-row">
                            <label class="toggle-switch">
                                <input type="checkbox" id="ada_sengketa" onchange="toggleSengketa()">
                                <span class="toggle-slider"></span>
                            </label>
                            <span>Ada potensi sengketa?</span>
                        </div>
                        <div id="sengketaFields" class="toggle-extra">
                            <div class="sec-label">1. Peristiwa</div>
                            <div class="form-group"><label>a. Peserta</label><input type="text" id="s_peserta" placeholder=""></div>
                            <div class="grid-2">
                                <div class="form-group"><label>b. Tempat</label><input type="text" id="s_tempat" placeholder=""></div>
                                <div class="form-group"><label>c. Waktu</label><input type="text" id="s_waktu" placeholder=""></div>
                            </div>
                            <div class="sec-label">2. Obyek Sengketa</div>
                            <div class="form-group"><label>a. Bentuk</label><input type="text" id="s_bentuk" placeholder=""></div>
                            <div class="form-group"><label>b. Identitas</label><input type="text" id="s_identitas" placeholder=""></div>
                            <div class="grid-2">
                                <div class="form-group"><label>c. Tanggal</label><input type="text" id="s_tgl_keluar" placeholder=""></div>
                                <div class="form-group"><label>d. Kerugian</label><input type="text" id="s_kerugian" placeholder=""></div>
                            </div>
                            <div class="sec-label">3. Uraian Singkat Potensi Sengketa</div>
                            <div class="form-group"><textarea id="s_uraian" rows="4" placeholder=""></textarea></div>
                        </div>
                        <div id="tidakSengketa" class="toggle-empty">Nihil</div>
                    </div>
                </div>

                <!-- VI. TTD -->
                <div class="card">
                    <div class="card-header">VI. ✍️ Penandatangan</div>
                    <div class="card-body">
                        <div class="grid-2">
                            <div class="form-group"><label>Kota <span class="req">*</span></label><input type="text" id="ttd_kota" placeholder=""></div>
                            <div class="form-group"><label>Tanggal TTD <span class="req">*</span></label><input type="date" id="ttd_tgl"></div>
                        </div>
                        <div class="form-group"><label>Jabatan <span class="req">*</span></label><input type="text" id="ttd_jabatan" placeholder=""></div>
                        <div class="form-group"><label>Nama Lengkap <span class="req">*</span></label><input type="text" id="ttd_nama" placeholder=""></div>
                    </div>
                </div>

                <!-- DOKUMENTASI -->
                <div class="card">
                    <div class="card-header">📸 Dokumentasi</div>
                    <div class="card-body">
                        <div class="form-group"><label>Judul Dokumentasi</label><input type="text" id="foto_judul" placeholder=""></div>
                        <div class="photo-zone" onclick="document.getElementById('photoInput').click()">
                            <input type="file" id="photoInput" accept="image/*" multiple onchange="addPhotos(event)">
                            <div style="font-size:28px;">📷</div>
                            <p>Tap untuk pilih foto</p>
                            <small>JPG, PNG</small>
                        </div>
                        <div class="photo-grid" id="photoGrid"></div>
                    </div>
                </div>

                <!-- BUTTONS -->
                <div class="btn-row">
                    <button class="btn btn-outline" onclick="resetForm()">🗑 Reset</button>
                    <button class="btn btn-secondary" onclick="saveDraft()">💾 Simpan Draf</button>
                    <button class="btn btn-primary" onclick="preview()">👁 Preview</button>
                    <button class="btn btn-success" onclick="downloadPDF()">⬇ Download PDF</button>
                    
                    <?php if ($submission_id > 0): ?>
                        <?php 
                            $stmt = $pdo->prepare("SELECT status FROM form_submissions WHERE id = ?");
                            $stmt->execute([$submission_id]);
                            $submissionStatus = $stmt->fetchColumn();
                        ?>
                        <?php if (in_array($submissionStatus, ['draft', 'rejected', null])): ?>
                            <!-- <button class="btn btn-primary" onclick="submitForm()">📤 Kirim</button> -->
                        <?php elseif ($submissionStatus === 'submitted'): ?>
                            <button class="btn btn-warning" disabled style="opacity:0.7;">⏳ Menunggu Verifikasi</button>
                        <?php elseif ($submissionStatus === 'approved'): ?>
                            <button class="btn btn-success" disabled>✅ Disetujui</button>
                        <?php elseif ($submissionStatus === 'rejected'): ?>
                            <button class="btn btn-danger" disabled>❌ Ditolak</button>
                            <?php 
                                $stmt = $pdo->prepare("SELECT admin_note FROM form_submissions WHERE id = ?");
                                $stmt->execute([$submission_id]);
                                $note = $stmt->fetchColumn();
                            ?>
                            <?php if ($note): ?>
                                <small style="color:#C62828;display:block;margin-top:4px;">Catatan: <?= htmlspecialchars($note) ?></small>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                </div><!-- end formContainer -->
            </div><!-- end tabForm -->

            <!-- TAB PREVIEW -->
            <div id="tabPreview" style="display:none;">
                <div id="previewArea">
                    <div class="preview-toolbar">
                        <span>👁 Preview Dokumen</span>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            <button class="btn btn-outline btn-sm" onclick="switchTab('form')">← Edit</button>
                            <button class="btn btn-primary btn-sm" onclick="downloadPDF()">⬇ Download PDF</button>
                        </div>
                    </div>
                    <div class="preview-content">
                        <div id="previewDoc">
                            <p style="text-align:center;color:#9AA6C0;padding:40px 0;">Isi form lalu klik <strong>Preview</strong></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB RIWAYAT -->
            <div id="tabRiwayat" style="display:none;">
                <div class="card">
                    <div class="card-header">📋 Riwayat Submission</div>
                    <div class="card-body" id="riwayatContent">
                        <?php if (empty($submissionList)): ?>
                            <p style="text-align:center;color:#6B7A99;padding:20px;">Belum ada submission</p>
                        <?php else: ?>
                        <table class="submission-table">
                            <thead><tr><th>#</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead>
                            <tbody>
                            <?php $no=1; foreach ($submissionList as $s):
                                $statusLabel = ['draft'=>'📝 Draf','previewed'=>'👁 Preview','downloaded'=>'⬇ Downloaded','submitted'=>'📤 submitted','approved'=>'✅ Diterima','rejected'=>'❌ Ditolak'][$s['status']] ?? $s['status'];
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($s['created_at'])) ?></td>
                                <td><span class="status-badge <?= $s['status'] ?>"><?= $statusLabel ?></span></td>
                                <td>
                                    <button class="btn-edit" onclick="editSubmission(<?= $s['id'] ?>)">✏️ Edit</button>
                                    <button class="btn-preview" onclick="previewSubmission(<?= $s['id'] ?>)">👁 Preview</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div><!-- form-container -->
    </main>
</div>

<script>
// ================================================================
// STATE
// ================================================================
var STORAGE_KEY = 'form_a_draft';
var photos = [];
var submissionId = null;
var quills = {};
var isSaving = false;  // ← HARUS ADA!

// ================================================================
// SIDEBAR TOGGLE
// ================================================================
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

// ================================================================
// TOGGLE PELANGGARAN & SENGKETA
// ================================================================
function togglePelanggaran() {
    var on = document.getElementById('ada_pelanggaran').checked;
    document.getElementById('pelanggaranFields').classList.toggle('show', on);
    document.getElementById('tidakPelanggaran').style.display = on ? 'none' : 'block';
}

function toggleSengketa() {
    var on = document.getElementById('ada_sengketa').checked;
    document.getElementById('sengketaFields').classList.toggle('show', on);
    document.getElementById('tidakSengketa').style.display = on ? 'none' : 'block';
}

// ================================================================
// PHOTOS
// ================================================================
function addPhotos(e) {
    var files = Array.from(e.target.files);
    files.forEach(function(file) {
        if (!file.type || file.type.indexOf('image/') !== 0) return;
        
        compressImage(file, 1280, 0.5).then(function(dataUrl) {
            photos.push({ src: dataUrl, caption: '' });
            renderPhotos();
        }).catch(function(err) {
            console.error('Gagal kompres:', err);
            // Fallback: pakai file asli
            var reader = new FileReader();
            reader.onload = function(ev) {
                photos.push({ src: ev.target.result, caption: '' });
                renderPhotos();
            };
            reader.readAsDataURL(file);
        });
    });
    e.target.value = '';
}

// ================================================================
// KOMPRESI FOTO SEBELUM DISIMPAN
// Resize sisi terpanjang ke maxDim px + re-encode JPEG (quality)
// supaya ukuran foto yang ditanam ke PDF jauh lebih kecil,
// tanpa mengubah proses generate PDF itu sendiri.
// ================================================================
function compressImage(file, maxDim, quality) {
    return new Promise(function(resolve, reject) {
        if (!file.type || file.type.indexOf('image/') !== 0) {
            reject(new Error('Bukan file gambar'));
            return;
        }
        var reader = new FileReader();
        reader.onload = function(ev) {
            var img = new Image();
            img.onload = function() {
                var w = img.width, h = img.height;
                if (w > maxDim || h > maxDim) {
                    if (w >= h) {
                        h = Math.round(h * (maxDim / w));
                        w = maxDim;
                    } else {
                        w = Math.round(w * (maxDim / h));
                        h = maxDim;
                    }
                }
                var canvas = document.createElement('canvas');
                canvas.width = w;
                canvas.height = h;
                var ctx = canvas.getContext('2d');
                // Latar putih dulu (jaga-jaga kalau sumbernya PNG transparan)
                ctx.fillStyle = '#ffffff';
                ctx.fillRect(0, 0, w, h);
                ctx.drawImage(img, 0, 0, w, h);
                try {
                    resolve(canvas.toDataURL('image/jpeg', quality));
                } catch (err) {
                    reject(err);
                }
            };
            img.onerror = function() { reject(new Error('Gagal memuat gambar')); };
            img.src = ev.target.result;
        };
        reader.onerror = function() { reject(new Error('Gagal membaca file')); };
        reader.readAsDataURL(file);
    });
}

function renderPhotos() {
    var grid = document.getElementById('photoGrid');
    grid.innerHTML = '';
    photos.forEach(function(p, i) {
        var div = document.createElement('div');
        div.className = 'photo-item';
        div.innerHTML = '<img src="' + p.src + '"><input class="caption-input" placeholder="Keterangan..." value="' + (p.caption||'') + '" onchange="photos['+i+'].caption=this.value;"><button class="remove-btn" onclick="removePhoto('+i+')">✕</button>';
        // ✅ SAVE DRAFT DIHAPUS!
        grid.appendChild(div);
    });
}

function removePhoto(i) {
    photos.splice(i,1);
    renderPhotos();
    // ✅ SAVE DRAFT DIHAPUS!
}
// ================================================================
// UTIL: ambil HTML editor tanpa handle resize (dipakai utk simpan & PDF)
// ================================================================
function getCleanUraianHTML() {
    if (!quill) return document.getElementById('uraian').value;
    var clone = quill.root.cloneNode(true);
    clone.querySelectorAll('.col-resize-handle, .row-resize-handle').forEach(function(h) { h.remove(); });
    return clone.innerHTML;
}

function syncUraianField() {
    document.getElementById('uraian').value = getCleanUraianHTML();
}

// ================================================================
// GET ALL DATA
// ================================================================
function getAllData() {
    var fields = document.querySelectorAll('#formContainer input, #formContainer textarea, #formContainer select');
    var data = {};
    fields.forEach(function(el) {
        if (el.id) {
            if (el.type === 'checkbox') data[el.id] = el.checked;
            else data[el.id] = el.value;
        }
    });
    if (quill) {
        data.uraian = getCleanUraianHTML();
    }
    data.photos = photos;
    return data;
}

// ================================================================
// SAVE DRAFT
// ================================================================
// ================================================================
// SAVE DRAFT
// ================================================================
var isSaving = false;

function saveDraft() {
    if (isSaving) {
        showToast('⏳ Sedang menyimpan, tunggu...', 'warning');
        return;
    }
    
    isSaving = true;
    var btns = document.querySelectorAll('.btn-secondary, .btn-primary, .btn-outline');
    btns.forEach(function(btn) {
        btn.disabled = true;
        btn.style.opacity = '0.5';
        btn.style.cursor = 'not-allowed';
    });
    
    showToast('💾 Menyimpan draft...', 'info', true);
    
    try {
        var data = getAllData();
        data.status = 'draft';
        data.updated_at = new Date().toISOString();
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));

        
        var payload = {
            form_key: 'form_a',  // ← BEDA!
            status: 'draft',
            submission_id: submissionId || 0,  // ← PAKAI INI!
            timestamp: data.updated_at
        };
        
        fetch('api/save_status.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(function(res) { 
            if (!res.ok) throw new Error('Network error');
            return res.json(); 
        })
        .then(function(result) {
            isSaving = false;
            btns.forEach(function(btn) {
                btn.disabled = false;
                btn.style.opacity = '1';
                btn.style.cursor = 'pointer';
            });
            
            if (result.success) {
                submissionId = result.submission_id;
                var draft = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
                draft.submission_id = result.submission_id;
                localStorage.setItem(STORAGE_KEY, JSON.stringify(draft));
                saveToHistory(draft);  // ← TAMBAHKAN!
                showToast('✅ Draft berhasil disimpan!', 'success');
            } else {
                showToast('⚠️ ' + (result.message || 'Gagal update status'), 'warning');
            }
        })
        .catch(function(err) {
            isSaving = false;
            btns.forEach(function(btn) {
                btn.disabled = false;
                btn.style.opacity = '1';
                btn.style.cursor = 'pointer';
            });
            showToast('⚠️ Data tersimpan lokal', 'warning');
            console.error('Save status error:', err);
        });
        
    } catch (error) {
        isSaving = false;
        btns.forEach(function(btn) {
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
        });
        showToast('❌ Gagal menyimpan: ' + error.message, 'error');
        console.error('Save error:', error);
    }
}

// ================================================================
// LOAD DRAFT
// ================================================================
function loadDraft() {
    try {
        var saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
            var data = JSON.parse(saved);
            for (var key in data) {
                if (key === 'photos') { photos = data.photos || []; renderPhotos(); continue; }
                if (key === 'uraian') {
                    if (quill && data.uraian) {
                        quill.root.innerHTML = data.uraian;
                    }
                    document.getElementById('uraian').value = data.uraian || '';
                    continue;
                }
                if (key === 'submission_id') {
                    submissionId = data.submission_id;  // ← BACA!
                    continue;
                }
                if (key === 'status' || key === 'created_at' || key === 'updated_at' || key === 'downloaded_at') {
                    continue;
                }
                var el = document.getElementById(key);
                if (el) {
                    if (el.type === 'checkbox') {
                        el.checked = data[key] === true;
                    } else {
                        el.value = data[key] || '';
                    }
                }
            }
            if (data.ada_pelanggaran) { document.getElementById('ada_pelanggaran').checked = true; togglePelanggaran(); }
            if (data.ada_sengketa) { document.getElementById('ada_sengketa').checked = true; toggleSengketa(); }
        }
    } catch(e) { console.error('Load draft error:', e); }
}

// ================================================================
// RESET
// ================================================================
function resetForm() {
    if (!confirm('Reset semua data?')) return;
    submissionId = null;  // ← TAMBAHKAN!
    localStorage.removeItem(STORAGE_KEY);
    location.reload();
}

// ================================================================
// PREVIEW
// ================================================================
function preview() {
    generatePreview();
    switchTab('preview');
    showToast('👁 Preview siap dilihat', 'info');
}

function generatePreview() {
    var html = buildPDFHTML();
    document.getElementById('previewDoc').innerHTML = html;
}

// ================================================================
// BUILD PDF HTML - UNTUK PREVIEW
// ================================================================
function buildPDFHTML() {
    function v(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }
    function esc(s) { return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
    function nl(s) { return esc(s||'').replace(/\n/g,'<br>'); }
    function fdate(s) { if(!s) return ''; var d=new Date(s); var M=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']; return d.getDate()+' '+M[d.getMonth()]+' '+d.getFullYear(); }

    var uraianContent = quill ? getCleanUraianHTML() : document.getElementById('uraian').value;

    var html = '<div class="pdf-page">';
    html += '<div class="kop">';
    if ('<?= $kop_logo ?>') html += '<img src="<?= $kop_logo ?>"><br>';
    html += '<div class="instansi"><?= htmlspecialchars($kop_instansi) ?></div>';
    if ('<?= $kop_alamat ?>') html += '<div class="alamat"><?= htmlspecialchars($kop_alamat) ?></div>';
    if ('<?= $kop_telp ?>' || '<?= $kop_email ?>') {
        html += '<div class="alamat">';
        if ('<?= $kop_telp ?>') html += 'Telp: <?= htmlspecialchars($kop_telp) ?>';
        if ('<?= $kop_telp ?>' && '<?= $kop_email ?>') html += ' | ';
        if ('<?= $kop_email ?>') html += 'Email: <?= htmlspecialchars($kop_email) ?>';
        html += '</div>';
    }
    html += '</div>';

    html += '<div class="pdf-title">FORM A</div>';
    html += '<div class="pdf-subtitle">LAPORAN HASIL PENGAWASAN PEMILIHAN</div>';
    html += '<div class="pdf-nomor">Nomor: '+esc(v('nomor'))+'</div>';

    html += '<div class="pdf-section">I. Data Pengawasan</div>';
    html += '<table class="pdf-tbl">';
    html += '<tr><td class="label-col">1. Tahapan yang diawasi</td><td class="sep-col">:</td><td>'+esc(v('tahapan'))+'</td></tr>';
    html += '<tr><td class="label-col">2. Nama Pelaksana Tugas Pengawasan</td><td class="sep-col">:</td><td>'+nl(v('nama_pengawas'))+'</td></tr>';
    html += '<tr><td class="label-col">3. Jabatan</td><td class="sep-col">:</td><td>'+nl(v('jabatan'))+'</td></tr>';
    html += '<tr><td class="label-col">4. Nomor Surat Perintah Tugas</td><td class="sep-col">:</td><td>'+esc(v('no_st'))+'</td></tr>';
    html += '<tr><td class="label-col">5. Alamat</td><td class="sep-col">:</td><td>'+nl(v('alamat'))+'</td></tr>';
    html += '</table>';

    html += '<div class="pdf-section">II. Kegiatan Pengawasan</div>';
    html += '<table class="pdf-tbl">';
    html += '<tr><td class="label-col">1. Bentuk</td><td class="sep-col">:</td><td>'+esc(v('bentuk'))+'</td></tr>';
    html += '<tr><td class="label-col">2. Tujuan</td><td class="sep-col">:</td><td>'+nl(v('tujuan'))+'</td></tr>';
    html += '<tr><td class="label-col">3. Sasaran</td><td class="sep-col">:</td><td>'+nl(v('sasaran'))+'</td></tr>';
    html += '<tr><td class="label-col">4. Waktu dan Tempat</td><td class="sep-col">:</td><td>'+fdate(v('tgl_kegiatan'))+'<br>'+esc(v('tempat_kegiatan'))+'</td></tr>';
    html += '</table>';

    html += '<div class="pdf-section">III. Uraian Singkat Hasil Pengawasan</div>';
    html += '<div class="ql-editor" style="text-align:justify;padding:0;min-height:0;">'+uraianContent+'</div>';

    html += '<div class="pdf-section">IV. Informasi Dugaan Pelanggaran</div>';
    var adaP = document.getElementById('ada_pelanggaran').checked;
    if (adaP) {
        html += '<table class="pdf-tbl">';
        html += '<tr><td class="label-col">1. Peristiwa</td><td class="sep-col">:</td><td>'+nl(v('p_peristiwa'))+'</td></tr>';
        html += '<tr><td class="label-col">b. Tempat Kejadian</td><td class="sep-col">:</td><td>'+esc(v('p_tempat'))+'</td></tr>';
        html += '<tr><td class="label-col">c. Waktu Kejadian</td><td class="sep-col">:</td><td>'+esc(v('p_waktu'))+'</td></tr>';
        html += '<tr><td class="label-col">d. Pelaku</td><td class="sep-col">:</td><td>'+esc(v('p_pelaku'))+'</td></tr>';
        html += '<tr><td class="label-col">e. Alamat</td><td class="sep-col">:</td><td>'+esc(v('p_alamat_pelaku'))+'</td></tr>';
        html += '<tr><td class="label-col">2. Saksi-saksi</td><td class="sep-col">:</td><td>'+esc(v('saksi1_nama'))+' ('+esc(v('saksi1_alamat'))+')<br>'+esc(v('saksi2_nama'))+' ('+esc(v('saksi2_alamat'))+')</td></tr>';
        html += '<tr><td class="label-col">3. Alat Bukti</td><td class="sep-col">:</td><td>'+esc(v('bukti_a'))+'<br>'+esc(v('bukti_b'))+'<br>'+esc(v('bukti_c'))+'</td></tr>';
        html += '<tr><td class="label-col">4. Barang Bukti</td><td class="sep-col">:</td><td>'+esc(v('barang_a'))+'<br>'+esc(v('barang_b'))+'<br>'+esc(v('barang_c'))+'</td></tr>';
        html += '<tr><td class="label-col">5. Uraian Singkat</td><td class="sep-col">:</td><td>'+nl(v('uraian_pelanggaran'))+'</td></tr>';
        html += '<tr><td class="label-col">6. Fakta dan Keterangan</td><td class="sep-col">:</td><td>'+nl(v('fakta'))+'</td></tr>';
        html += '<tr><td class="label-col">7. Analisa</td><td class="sep-col">:</td><td>'+nl(v('analisa'))+'</td></tr>';
        html += '</table>';
    } else {
        html += '<p style="font-style:italic;color:#666;">Nihil</p>';
    }

    html += '<div class="pdf-section">V. Informasi Potensi Sengketa</div>';
    var adaS = document.getElementById('ada_sengketa').checked;
    if (adaS) {
        html += '<table class="pdf-tbl">';
        html += '<tr><td class="label-col">1. Peristiwa</td><td class="sep-col">:</td><td>'+esc(v('s_peserta'))+'</td></tr>';
        html += '<tr><td class="label-col">b. Tempat Kejadian</td><td class="sep-col">:</td><td>'+esc(v('s_tempat'))+'</td></tr>';
        html += '<tr><td class="label-col">c. Waktu Kejadian</td><td class="sep-col">:</td><td>'+esc(v('s_waktu'))+'</td></tr>';
        html += '<tr><td class="label-col">2. Obyek Sengketa</td><td class="sep-col">:</td><td>'+esc(v('s_bentuk'))+'</td></tr>';
        html += '<tr><td class="label-col">b. Identitas</td><td class="sep-col">:</td><td>'+esc(v('s_identitas'))+'</td></tr>';
        html += '<tr><td class="label-col">c. Tanggal</td><td class="sep-col">:</td><td>'+esc(v('s_tgl_keluar'))+'</td></tr>';
        html += '<tr><td class="label-col">d. Kerugian</td><td class="sep-col">:</td><td>'+esc(v('s_kerugian'))+'</td></tr>';
        html += '<tr><td class="label-col">3. Uraian Singkat</td><td class="sep-col">:</td><td>'+nl(v('s_uraian'))+'</td></tr>';
        html += '</table>';
    } else {
        html += '<p style="font-style:italic;color:#666;">Nihil</p>';
    }

    html += '<div class="pdf-ttd">';
    html += '<p>'+esc(v('ttd_kota'))+', '+fdate(v('ttd_tgl'))+'</p>';
    html += '<p class="jabatan">'+esc(v('ttd_jabatan'))+'</p>';
    html += '<span class="nama">'+esc(v('ttd_nama'))+'</span>';
    html += '</div>';

    if (photos.length > 0) {
        html += '<div style="page-break-before: always;"></div>';
        html += '<div class="pdf-page" style="text-align:center;">';
        html += '<div class="pdf-foto-title">DOKUMENTASI KEGIATAN</div>';
        if (v('foto_judul')) html += '<p style="text-align:center;font-size:9pt;font-style:italic;margin-bottom:12px;">'+esc(v('foto_judul'))+'</p>';
        html += '<div class="pdf-foto-grid">';
        photos.forEach(function(p) {
            html += '<div class="pdf-foto-item" style="margin-bottom:10px;">';
            html += '<img src="'+p.src+'" style="width:100%;max-width:280px;border:1px solid #ccc;border-radius:4px;">';
            html += '<p style="text-align:center;font-size:8.5pt;margin-top:3px;font-style:italic;color:#555;">'+esc(p.caption||'')+'</p>';
            html += '</div>';
        });
        html += '</div>';
        html += '</div>';
    }

    html += '</div>';
    return html;
}

// ================================================================
// DOWNLOAD PDF — dibangun native pakai jsPDF (text/table/image
// langsung), TIDAK lagi pakai html2canvas. Hasilnya jauh lebih
// kecil karena bukan gambar screenshot, tapi teks & gambar asli.
// Kertas F4 (210x330mm), margin 8mm — dipakai konsisten di semua
// bagian termasuk halaman dokumentasi foto.
// ================================================================
function downloadPDF() {
    // ============================================================
    // UPDATE STATUS (GANTI saveToServer)
    // ============================================================
    var data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    data.status = 'downloaded';
    data.downloaded_at = new Date().toISOString();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    
    var payload = {
        form_key: 'form_a',
        status: 'downloaded',
        submission_id: submissionId || 0,
        timestamp: data.downloaded_at
    };
    
    fetch('api/save_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(function(res) { return res.json(); })
    .then(function(result) {
        if (result.success) {
            submissionId = result.submission_id;
            data.submission_id = result.submission_id;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
            saveToHistory(data);
        }
    })
    .catch(function() {});
    
    showToast('⏳ Menyiapkan PDF...', 'info');

    buildNativePDF().then(function(doc) {
        doc.save('Laporan_Hasil_Pengawasan_' + new Date().toISOString().slice(0, 10) + '.pdf');
        showToast('📄 PDF berhasil di-download!', 'success');
    }).catch(function(err) {
        console.error(err);
        showToast('❌ Gagal membuat PDF', 'error');
    });
}

// Ambil gambar dari URL (mis. logo kop surat) lalu ubah ke dataURL,
// supaya bisa ditanam ke PDF lewat addImage (tanpa html2canvas).
function loadImageAsDataURL(url) {
    return new Promise(function(resolve) {
        if (!url) { resolve(null); return; }
        fetch(url).then(function(r) {
            if (!r.ok) throw new Error('fetch gagal');
            return r.blob();
        }).then(function(blob) {
            var reader = new FileReader();
            reader.onload = function() { resolve(reader.result); };
            reader.onerror = function() { resolve(null); };
            reader.readAsDataURL(blob);
        }).catch(function() { resolve(null); });
    });
}

// ================================================================
// PDF BUILDER NATIVE (tanpa html2canvas)
// ================================================================
function buildNativePDF() {
    return new Promise(function(resolve, reject) {
        try {
            var doc = new jspdf.jsPDF({ orientation: 'p', unit: 'mm', format: [210, 330] }); // F4
            var pageW = 210, pageH = 330, margin = 8;
            var contentW = pageW - margin * 2;
            var bottomY = pageH - margin;
            var y = margin;

            function v(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }
            function fdate(s) { if (!s) return ''; var d = new Date(s); var M = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']; return d.getDate() + ' ' + M[d.getMonth()] + ' ' + d.getFullYear(); }
            function centerText(text, yy) { doc.text(text, pageW / 2, yy, { align: 'center' }); }
            function ensureSpace(h) { if (y + h > bottomY) { doc.addPage([pageW, pageH], 'p'); y = margin; } }
            function drawLines(lines, x, startY, lineH) { lines.forEach(function(line, i) { doc.text(line, x, startY + i * lineH); }); }

            function sectionLabel(text) {
                ensureSpace(9);
                doc.setFont('times', 'bold'); doc.setFontSize(11);
                doc.text(text, margin, y + 4);
                y += 7;
            }

            function nihil() {
                ensureSpace(7);
                doc.setFont('times', 'italic'); doc.setFontSize(10);
                doc.text('Nihil', margin, y + 4);
                y += 8;
            }

            // ---- tabel label : value (mengikuti tampilan .pdf-tbl) ----
            function drawLabelValueTable(rows) {
                var labelColW = 55, sepColW = 5, valueColW = contentW - labelColW - sepColW;
                var lineH = 4.3;
                rows.forEach(function(row) {
                    var label = row[0], value = row[1] || '';
                    doc.setFontSize(10);
                    doc.setFont('times', 'bold');
                    var labelLines = doc.splitTextToSize(label, labelColW - 4);
                    doc.setFont('times', 'normal');
                    var valueLines = doc.splitTextToSize(value, valueColW - 4);
                    var rowH = Math.max(labelLines.length, valueLines.length, 1) * lineH + 3;
                    ensureSpace(rowH);
                    var top = y;
                    doc.setDrawColor(80, 80, 80); doc.setLineWidth(0.2);
                    doc.rect(margin, top, labelColW, rowH);
                    doc.rect(margin + labelColW, top, sepColW, rowH);
                    doc.rect(margin + labelColW + sepColW, top, valueColW, rowH);
                    doc.setFont('times', 'bold');
                    drawLines(labelLines, margin + 2, top + 4.3, lineH);
                    doc.setFont('times', 'normal');
                    doc.text(':', margin + labelColW + 1.5, top + 4.3);
                    drawLines(valueLines, margin + labelColW + sepColW + 2, top + 4.3, lineH);
                    y = top + rowH;
                });
                y += 3;
            }

            // ---- render rich text uraian (dari Quill: paragraf, bold/italic/underline, list, tabel) ----
            function renderRichText(htmlString) {
                var container = document.createElement('div');
                container.innerHTML = htmlString || '';
                var lineH = 4.7;
                doc.setFont('times', 'normal'); doc.setFontSize(10.5);

                function getIndentLevel(node) {
                    var cls = node.className || '';
                    var m = /ql-indent-(\d)/.exec(cls);
                    return m ? parseInt(m[1], 10) : 0;
                }
                function fontStyleFor(run) {
                    if (run.bold && run.italic) return 'bolditalic';
                    if (run.bold) return 'bold';
                    if (run.italic) return 'italic';
                    return 'normal';
                }
                function extractRuns(node) {
                    var runs = [];
                    function walk(n, style) {
                        if (n.nodeType === 3) { if (n.textContent) runs.push({ text: n.textContent, bold: style.bold, italic: style.italic }); return; }
                        if (n.nodeType !== 1) return;
                        var tag = n.tagName.toLowerCase();
                        if (tag === 'br') { runs.push({ text: '\n', bold: false, italic: false }); return; }
                        var s = { bold: style.bold || tag === 'strong' || tag === 'b', italic: style.italic || tag === 'em' || tag === 'i' };
                        Array.prototype.forEach.call(n.childNodes, function(c) { walk(c, s); });
                    }
                    walk(node, { bold: false, italic: false });
                    return runs;
                }
                function runsToLines(runs, x, maxW) {
                    // pecah runs jadi baris-baris siap gambar: [{text, x, w, style}]
                    var lines = []; var cur = []; var curX = x;
                    runs.forEach(function(run) {
                        run.text.split('\n').forEach(function(part, pi) {
                            if (pi > 0) { lines.push(cur); cur = []; curX = x; }
                            var words = part.split(/(\s+)/).filter(function(w) { return w.length > 0; });
                            words.forEach(function(word) {
                                doc.setFont('times', fontStyleFor(run));
                                var w = doc.getTextWidth(word);
                                if (curX + w > x + maxW && word.trim() !== '' && cur.length) { lines.push(cur); cur = []; curX = x; }
                                cur.push({ text: word, x: curX, w: w, style: fontStyleFor(run) });
                                curX += w;
                            });
                        });
                    });
                    if (cur.length) lines.push(cur);
                    return lines;
                }
                // Rata kiri-kanan (hanging indent + justify) - sama seperti perilaku
                // "text-align: justify" pada preview: baris terakhir tiap paragraf/item
                // tetap rata kiri, baris-baris sebelumnya direntangkan penuh sampai
                // tepi kanan (maxW) dengan menambah jarak antar-kata, tanpa mengubah
                // gaya (bold/italic) tiap kata.
                function justifyLine(tokens, startX, targetWidth) {
                    var totalW = 0;
                    tokens.forEach(function(t) { totalW += t.w; });
                    var slack = targetWidth - totalW;
                    var gapIdxs = [];
                    tokens.forEach(function(t, i) { if (t.text.trim() === '') gapIdxs.push(i); });
                    var cx = startX;
                    if (slack <= 0 || !gapIdxs.length) {
                        tokens.forEach(function(t) { t.x = cx; cx += t.w; });
                        return tokens;
                    }
                    var extra = slack / gapIdxs.length;
                    tokens.forEach(function(t) {
                        t.x = cx;
                        cx += t.w;
                        if (t.text.trim() === '') cx += extra;
                    });
                    return tokens;
                }
                function drawRunLines(lines, startX, maxW) {
                    lines.forEach(function(lineParts, li) {
                        ensureSpace(lineH);
                        var yy = y + lineH * 0.75;
                        var isLastLine = (li === lines.length - 1);
                        var drawParts = (!isLastLine && maxW) ? justifyLine(lineParts, startX, maxW) : lineParts;
                        drawParts.forEach(function(part) {
                            doc.setFont('times', part.style); doc.setFontSize(10.5);
                            doc.text(part.text, part.x, yy);
                        });
                        y += lineH;
                    });
                }
                function renderParagraph(node) {
                    var indentPx = getIndentLevel(node) * 8;
                    var x = margin + indentPx, maxW = contentW - indentPx;
                    var runs = extractRuns(node);
                    if (!runs.length) { y += lineH * 0.4; return; }
                    drawRunLines(runsToLines(runs, x, maxW), x, maxW);
                    y += 1.2;
                }
                function renderList(listNode, ordered, lvl) {
                    var idx = 1;
                    Array.prototype.forEach.call(listNode.children, function(li) {
                        if (!li.tagName || li.tagName.toLowerCase() !== 'li') return;
                        var thisLvl = getIndentLevel(li) || lvl;
                        var marker = ordered ? (idx + '.') : '\u2022';
                        idx++;
                        var indentPx = 6 + thisLvl * 8, markerW = 6;
                        var x = margin + indentPx, textX = x + markerW, maxW = contentW - indentPx - markerW;
                        var runs = [];
                        Array.prototype.forEach.call(li.childNodes, function(c) {
                            var tag = c.tagName ? c.tagName.toLowerCase() : '';
                            if (tag === 'ol' || tag === 'ul') return; // list bersarang digambar terpisah di bawah
                            runs = runs.concat(extractRuns(c.nodeType === 3 ? c : c));
                        });
                        ensureSpace(lineH);
                        doc.setFont('times', 'normal'); doc.setFontSize(10.5);
                        doc.text(marker, x, y + lineH * 0.75);
                        if (runs.length) drawRunLines(runsToLines(runs, textX, maxW), textX, maxW);
                        else y += lineH;
                        var nested = li.querySelector(':scope > ol, :scope > ul');
                        if (nested) renderList(nested, nested.tagName.toLowerCase() === 'ol', thisLvl + 1);
                    });
                }
                function renderTable(tableNode) {
    var rows = Array.prototype.slice.call(tableNode.querySelectorAll('tr'));
    if (!rows.length) return;
    var numCols = 0;
    rows.forEach(function(tr) { var c = 0; Array.prototype.forEach.call(tr.children, function(td) { c += parseInt(td.getAttribute('colspan') || '1', 10); }); numCols = Math.max(numCols, c); });
    if (!numCols) return;

    // ---- Ambil lebar kolom ASLI dari <col style="width:Xpx"> (hasil drag-resize
    // pengguna) lalu diproporsikan ke lebar konten halaman (mm). Tidak pakai
    // getBoundingClientRect karena tabel diproses dari elemen yang TIDAK
    // menempel ke DOM saat build PDF, sehingga ukurannya selalu nol. ----
    var colWidthsPx = [];
    var colgroup = tableNode.querySelector('colgroup');
    if (colgroup) {
        Array.prototype.forEach.call(colgroup.children, function(col) {
            colWidthsPx.push(parseFloat(col.style.width) || 0);
        });
    }
    if (colWidthsPx.length < numCols) {
        colWidthsPx = [];
        var firstRow = rows[0];
        Array.prototype.forEach.call(firstRow.children, function(td) {
            var w = parseFloat(td.style.width) || 0;
            var cs = parseInt(td.getAttribute('colspan') || '1', 10);
            for (var k = 0; k < cs; k++) colWidthsPx.push(w / cs);
        });
    }
    var totalPx = colWidthsPx.reduce(function(a, b) { return a + b; }, 0);
    var colW;
    if (totalPx > 0 && colWidthsPx.length === numCols) {
        colW = colWidthsPx.map(function(w) { return (w / totalPx) * contentW; });
    } else {
        var uniform = contentW / numCols;
        colW = []; for (var ci = 0; ci < numCols; ci++) colW.push(uniform);
    }
    function colX(colStart) { var x = margin; for (var i = 0; i < colStart; i++) x += colW[i]; return x; }
    function colSpanW(colStart, span) { var w = 0; for (var i = colStart; i < colStart + span; i++) w += colW[i]; return w; }

    var lineHT = 4.2;
    var occ = [], cellData = [];
    rows.forEach(function(tr, rIdx) {
        occ[rIdx] = occ[rIdx] || [];
        var colPtr = 0, rowCells = [];
        Array.prototype.forEach.call(tr.children, function(td) {
            while (occ[rIdx][colPtr]) colPtr++;
            var cs = parseInt(td.getAttribute('colspan') || '1', 10);
            var rs = parseInt(td.getAttribute('rowspan') || '1', 10);
            for (var rr = rIdx; rr < rIdx + rs; rr++) { occ[rr] = occ[rr] || []; for (var cc = colPtr; cc < colPtr + cs; cc++) occ[rr][cc] = true; }
            // ---- Ambil tinggi baris ASLI (px) hasil drag-resize pengguna ----
            var customHeightPx = parseFloat(td.style.height) || 0;
            rowCells.push({ colStart: colPtr, colSpan: cs, rowSpan: rs, text: (td.textContent || '').trim(), customHeightPx: customHeightPx });
            colPtr += cs;
        });
        cellData.push(rowCells);
    });

    // Konversi px (dari browser, ~96dpi) ke mm untuk PDF
    var PX_TO_MM = 0.264;

    doc.setFont('times', 'normal'); doc.setFontSize(9.5);
    var rowHeights = rows.map(function() { return 0; });
    cellData.forEach(function(rowCells, rIdx) {
        rowCells.forEach(function(cell) {
            var w = colSpanW(cell.colStart, cell.colSpan) - 4;
            var lines = doc.splitTextToSize(cell.text, w);
            var neededFromText = lines.length * lineHT + 3;
            var neededFromResize = cell.customHeightPx ? (cell.customHeightPx * PX_TO_MM) : 0;
            // Pakai yang LEBIH BESAR: kalau user set baris lebih tinggi dari
            // kebutuhan teks, hormati itu; kalau teksnya lebih panjang dari
            // tinggi yang diset, tetap perbesar supaya teks tidak terpotong.
            var needed = Math.max(neededFromText, neededFromResize);
            rowHeights[rIdx] = Math.max(rowHeights[rIdx], cell.rowSpan === 1 ? needed : needed / cell.rowSpan);
        });
        if (!rowHeights[rIdx]) rowHeights[rIdx] = lineHT + 3;
    });

    var rowTops = [];
    for (var r = 0; r < rows.length; r++) { ensureSpace(rowHeights[r]); rowTops[r] = y; y += rowHeights[r]; }
    doc.setDrawColor(120, 120, 120); doc.setLineWidth(0.15);
    cellData.forEach(function(rowCells, rIdx) {
        rowCells.forEach(function(cell) {
            var top = rowTops[rIdx];
            var bottom = (rIdx + cell.rowSpan < rowTops.length) ? rowTops[rIdx + cell.rowSpan] : (rowTops[rowTops.length - 1] + rowHeights[rowHeights.length - 1]);
            var x0 = colX(cell.colStart), w0 = colSpanW(cell.colStart, cell.colSpan);
            doc.rect(x0, top, w0, bottom - top);
            doc.setFont('times', 'normal'); doc.setFontSize(9.5);
            var lines = doc.splitTextToSize(cell.text, w0 - 4);
            drawLines(lines, x0 + 2, top + 4.2, lineHT);
        });
    });
}

                Array.prototype.forEach.call(container.childNodes, function(node) {
                    if (node.nodeType === 3) { if (node.textContent.trim()) renderParagraph(node); return; }
                    if (node.nodeType !== 1) return;
                    var tag = node.tagName.toLowerCase();
                    if (tag === 'table') { renderTable(node); y += 2; return; }
                    if (tag === 'ol' || tag === 'ul') { renderList(node, tag === 'ol', 0); y += 1.2; return; }
                    // jaga-jaga: kalau <table> ternyata dibungkus div lain (mis. wrapper
                    // tabel fallback .simple-table-wrap), cari tabel di dalamnya dulu
                    // sebelum dianggap paragraf biasa
                    var innerTable = node.querySelector ? node.querySelector('table') : null;
                    if (innerTable) { renderTable(innerTable); y += 2; return; }
                    if (tag === 'p' || tag === 'div' || tag === 'blockquote' || tag === 'h1' || tag === 'h2' || tag === 'h3' || tag === 'h4' || tag === 'h5' || tag === 'h6') renderParagraph(node);
                });
                if (!container.childNodes.length) { doc.setFont('times', 'italic'); doc.setFontSize(10); ensureSpace(6); doc.text('-', margin, y + 4); y += 8; }
            }

            // ---- kop surat ----
            function drawKop() {
                var logoUrl = <?= json_encode($kop_logo) ?>;
                var instansi = <?= json_encode($kop_instansi) ?>;
                var alamat = <?= json_encode($kop_alamat) ?>;
                var telp = <?= json_encode($kop_telp) ?>;
                var email = <?= json_encode($kop_email) ?>;

                return loadImageAsDataURL(logoUrl).then(function(dataUrl) {
                    if (dataUrl) {
                        try {
                            var props = doc.getImageProperties(dataUrl);
                            var logoH = 14, logoW = (props.width / props.height) * logoH;
                            doc.addImage(dataUrl, props.fileType || 'PNG', pageW / 2 - logoW / 2, y, logoW, logoH);
                            y += logoH + 2;
                        } catch (e) {}
                    }
                    doc.setFont('times', 'bold'); doc.setFontSize(13);
                    centerText(instansi, y + 4); y += 6;
                    doc.setFont('times', 'normal'); doc.setFontSize(8.5);
                    if (alamat) { centerText(alamat, y + 3); y += 4; }
                    var kontak = [];
                    if (telp) kontak.push('Telp: ' + telp);
                    if (email) kontak.push('Email: ' + email);
                    if (kontak.length) { centerText(kontak.join(' | '), y + 3); y += 4; }
                    y += 2;
                    doc.setDrawColor(26, 26, 46); doc.setLineWidth(0.6);
                    doc.line(margin, y, pageW - margin, y);
                    y += 7;
                });
            }

            // ---- halaman dokumentasi foto: grid tetap 2 kolom x 4 baris = 8 foto/halaman (F4, margin 8mm) ----
            function drawPhotoPages() {
                if (!photos.length) return;
                doc.addPage([pageW, pageH], 'p');
                y = margin;
                doc.setFont('times', 'bold'); doc.setFontSize(11);
                centerText('DOKUMENTASI KEGIATAN', y + 4); y += 7;
                var judul = v('foto_judul');
                if (judul) {
                    doc.setFont('times', 'italic'); doc.setFontSize(9);
                    centerText(judul, y + 3); y += 6;
                }
                y += 2;

                var cols = 2, rows = 4; // = 8 foto per halaman
                var gap = 5;
                var cellW = (contentW - gap * (cols - 1)) / cols;
                var gridTop = y;
                var availH = bottomY - gridTop;
                var cellH = (availH - gap * (rows - 1)) / rows;
                var captionH = 5;
                var imgMaxH = cellH - captionH;

                var col = 0, row = 0;
                photos.forEach(function(p) {
                    if (row === rows) { doc.addPage([pageW, pageH], 'p'); gridTop = margin; row = 0; col = 0; }
                    var cellX = margin + col * (cellW + gap);
                    var cellY = gridTop + row * (cellH + gap);
                    try {
                        var props = doc.getImageProperties(p.src);
                        var ratio = props.width / props.height;
                        var drawW = cellW, drawH = drawW / ratio;
                        if (drawH > imgMaxH) { drawH = imgMaxH; drawW = drawH * ratio; }
                        var offsetX = cellX + (cellW - drawW) / 2;
                        doc.addImage(p.src, 'JPEG', offsetX, cellY, drawW, drawH);
                        doc.setDrawColor(200, 200, 200); doc.setLineWidth(0.15);
                        doc.rect(offsetX, cellY, drawW, drawH);
                    } catch (e) {}
                    if (p.caption) {
                        doc.setFont('times', 'italic'); doc.setFontSize(8);
                        var capLines = doc.splitTextToSize(p.caption, cellW);
                        doc.text(capLines[0] || '', cellX + cellW / 2, cellY + imgMaxH + 3.5, { align: 'center' });
                    }
                    col++;
                    if (col === cols) { col = 0; row++; }
                });
            }

            drawKop().then(function() {
                var uraianContent = quill ? getCleanUraianHTML() : document.getElementById('uraian').value;
                var adaP = document.getElementById('ada_pelanggaran').checked;
                var adaS = document.getElementById('ada_sengketa').checked;

                doc.setFont('times', 'bold'); doc.setFontSize(12);
                centerText('FORM A', y + 4); y += 6;
                doc.setFontSize(11);
                centerText('LAPORAN HASIL PENGAWASAN PEMILIHAN', y + 4); y += 6;
                doc.setFont('times', 'bold'); doc.setFontSize(10.5);
                centerText('Nomor: ' + v('nomor'), y + 4); y += 8;

                sectionLabel('I. Data Pengawasan');
                drawLabelValueTable([
                    ['1. Tahapan yang diawasi', v('tahapan')],
                    ['2. Nama Pelaksana Tugas Pengawasan', v('nama_pengawas')],
                    ['3. Jabatan', v('jabatan')],
                    ['4. Nomor Surat Perintah Tugas', v('no_st')],
                    ['5. Alamat', v('alamat')]
                ]);

                sectionLabel('II. Kegiatan Pengawasan');
                drawLabelValueTable([
                    ['1. Bentuk', v('bentuk')],
                    ['2. Tujuan', v('tujuan')],
                    ['3. Sasaran', v('sasaran')],
                    ['4. Waktu dan Tempat', fdate(v('tgl_kegiatan')) + '\n' + v('tempat_kegiatan')]
                ]);

                sectionLabel('III. Uraian Singkat Hasil Pengawasan');
                renderRichText(uraianContent);

                sectionLabel('IV. Informasi Dugaan Pelanggaran');
                if (adaP) {
                    drawLabelValueTable([
                        ['1. Peristiwa', v('p_peristiwa')],
                        ['b. Tempat Kejadian', v('p_tempat')],
                        ['c. Waktu Kejadian', v('p_waktu')],
                        ['d. Pelaku', v('p_pelaku')],
                        ['e. Alamat', v('p_alamat_pelaku')],
                        ['2. Saksi-saksi', v('saksi1_nama') + ' (' + v('saksi1_alamat') + ')\n' + v('saksi2_nama') + ' (' + v('saksi2_alamat') + ')'],
                        ['3. Alat Bukti', [v('bukti_a'), v('bukti_b'), v('bukti_c')].filter(Boolean).join('\n')],
                        ['4. Barang Bukti', [v('barang_a'), v('barang_b'), v('barang_c')].filter(Boolean).join('\n')],
                        ['5. Uraian Singkat', v('uraian_pelanggaran')],
                        ['6. Fakta dan Keterangan', v('fakta')],
                        ['7. Analisa', v('analisa')]
                    ]);
                } else { nihil(); }

                sectionLabel('V. Informasi Potensi Sengketa');
                if (adaS) {
                    drawLabelValueTable([
                        ['1. Peristiwa', v('s_peserta')],
                        ['b. Tempat Kejadian', v('s_tempat')],
                        ['c. Waktu Kejadian', v('s_waktu')],
                        ['2. Obyek Sengketa', v('s_bentuk')],
                        ['b. Identitas', v('s_identitas')],
                        ['c. Tanggal', v('s_tgl_keluar')],
                        ['d. Kerugian', v('s_kerugian')],
                        ['3. Uraian Singkat', v('s_uraian')]
                    ]);
                } else { nihil(); }

                ensureSpace(32);
                y += 4;
                doc.setFont('times', 'normal'); doc.setFontSize(10.5);
                centerText(v('ttd_kota') + ', ' + fdate(v('ttd_tgl')), y + 4); y += 6;
                centerText(v('ttd_jabatan'), y + 4); y += 20;
                doc.setFont('times', 'bold');
                centerText(v('ttd_nama'), y + 4);
                var namaW = doc.getTextWidth(v('ttd_nama'));
                doc.setLineWidth(0.2);
                doc.line(pageW / 2 - namaW / 2, y + 5, pageW / 2 + namaW / 2, y + 5);

                drawPhotoPages();
                resolve(doc);
            }).catch(reject);
        } catch (err) {
            reject(err);
        }
    });
}

// ================================================================
// TAB
// ================================================================
function switchTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(function(btn) {
        btn.classList.remove('active');
    });
    
    document.getElementById('tabForm').style.display = 'none';
    document.getElementById('tabPreview').style.display = 'none';
    document.getElementById('tabRiwayat').style.display = 'none';
    
    if (tab === 'form') {
        document.querySelectorAll('.tab-btn')[0].classList.add('active');
        document.getElementById('tabForm').style.display = 'block';
    } else if (tab === 'preview') {
        document.querySelectorAll('.tab-btn')[1].classList.add('active');
        document.getElementById('tabPreview').style.display = 'block';
        generatePreview();  // ← TAMBAHKAN INI!
    } else if (tab === 'riwayat') {
        document.querySelectorAll('.tab-btn')[2].classList.add('active');
        document.getElementById('tabRiwayat').style.display = 'block';
        loadRiwayat();
    }
}

// ================================================================
// LOAD RIWAYAT - SYNC DENGAN SERVER + AUTO-CLEANUP
// ================================================================
function loadRiwayat() {
    try {
        var history = JSON.parse(localStorage.getItem('form_history') || '[]');
        var formKey = 'form_a';  // ← GANTI 'form_sppd' untuk form_sppd
        var userId = <?= $_SESSION['user_id'] ?>;
        
        // ============================================================
        // 1. AMBIL & FILTER BERDASARKAN FORM & USER
        // ============================================================
        var myHistory = history.filter(function(item) {
            return item.form_key === formKey && item.user_id === userId;
        });
        
        if (myHistory.length === 0) {
            renderRiwayat([]);
            return;
        }
        
        // ============================================================
        // 2. FETCH DARI SERVER → CEK MANA YANG MASIH ADA
        // ============================================================
        fetch('api/get_submissions.php?form_key=' + formKey)
            .then(function(res) { return res.json(); })
            .then(function(serverData) {
                if (!Array.isArray(serverData)) serverData = [];
                
                // Buat map: submission_id → serverItem
                var serverMap = {};
                serverData.forEach(function(s) {
                    serverMap[s.id] = s;
                });
                
                // ============================================================
                // 3. FILTER: HANYA ENTRY YANG MASIH ADA DI DATABASE
                // ============================================================
                var validHistory = myHistory.filter(function(item) {
                    return serverMap[item.submission_id];  // ← HANYA yang ada di server
                });
                
                // ============================================================
                // 4. HAPUS ENTRY INVALID DARI LOCALSTORAGE
                // ============================================================
                if (validHistory.length !== myHistory.length) {
                    console.log('🧹 Cleanup: ' + myHistory.length + ' → ' + validHistory.length);
                    
                    var otherHistory = history.filter(function(i) {
                        return !(i.form_key === formKey && i.user_id === userId);
                    });
                    var newHistory = otherHistory.concat(validHistory);
                    localStorage.setItem('form_history', JSON.stringify(newHistory));
                }
                
                // ============================================================
                // 5. AUTO-CLEANUP DUPLIKAT (jaga-jaga)
                // ============================================================
                validHistory.sort(function(a, b) {
                    var dateA = new Date(a.updated_at || a.created_at || 0);
                    var dateB = new Date(b.updated_at || b.created_at || 0);
                    return dateB - dateA;
                });
                
                var seen = {};
                var cleaned = [];
                validHistory.forEach(function(item) {
                    var key = item.form_key + '_' + item.user_id + '_' + item.submission_id;
                    if (!seen[key]) {
                        seen[key] = true;
                        cleaned.push(item);
                    }
                });
                
                validHistory = cleaned;
                
                // ============================================================
                // 6. UPDATE STATUS DARI SERVER
                // ============================================================
                validHistory.forEach(function(item) {
                    var serverItem = serverMap[item.submission_id];
                    if (serverItem) {
                        item.status = serverItem.status;
                        item.admin_note = serverItem.admin_note || '';
                        item.updated_at = serverItem.updated_at;
                    }
                });
                
                // ============================================================
                // 7. SIMPAN KEMBALI KE LOCALSTORAGE
                // ============================================================
                var allHistory = JSON.parse(localStorage.getItem('form_history') || '[]');
                validHistory.forEach(function(updatedItem) {
                    var idx = allHistory.findIndex(function(h) {
                        return h.submission_id === updatedItem.submission_id && 
                               h.form_key === formKey && 
                               h.user_id === userId;
                    });
                    if (idx >= 0) {
                        allHistory[idx] = updatedItem;
                    }
                });
                localStorage.setItem('form_history', JSON.stringify(allHistory));
                
                // ============================================================
                // 8. RENDER
                // ============================================================
                renderRiwayat(validHistory);
            })
            .catch(function(err) {
                console.error('Fetch error:', err);
                
                // Fallback: render dari localStorage (kalau server tidak bisa diakses)
                myHistory.sort(function(a, b) {
                    var dateA = new Date(a.updated_at || a.created_at || 0);
                    var dateB = new Date(b.updated_at || b.created_at || 0);
                    return dateB - dateA;
                });
                
                var seen = {};
                var cleaned = [];
                myHistory.forEach(function(item) {
                    var key = item.form_key + '_' + item.user_id + '_' + item.submission_id;
                    if (!seen[key]) {
                        seen[key] = true;
                        cleaned.push(item);
                    }
                });
                
                renderRiwayat(cleaned);
            });
        
    } catch (e) {
        console.error('Load riwayat error:', e);
        document.getElementById('riwayatContent').innerHTML = 
            '<p style="text-align:center;color:#C62828;padding:20px;">❌ Gagal memuat riwayat</p>';
    }
}
// ================================================================
// RENDER RIWAYAT
// ================================================================
function renderRiwayat(myHistory) {
    var container = document.getElementById('riwayatContent');
    
    if (myHistory.length === 0) {
        container.innerHTML = '<p style="text-align:center;color:#6B7A99;padding:20px;">📭 Belum ada riwayat</p>';
        return;
    }
    
    var html = '<table class="submission-table"><thead><tr><th>#</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead><tbody>';
    var reversed = [...myHistory].reverse();
    
    reversed.forEach(function(item, index) {
        var statusLabel = {
            'draft': '📝 Draft',
            'downloaded': '⬇ Downloaded',
            'submitted': '📤 Terkirim',
            'approved': '✅ Disetujui',
            'rejected': '❌ Ditolak'
        }[item.status] || item.status;
        
        var statusClass = 'status-' + (item.status || 'draft');
        var date = item.updated_at || item.created_at || new Date().toISOString();
        
        html += '<tr>';
        html += '<td>' + (index + 1) + '</td>';
        html += '<td>' + new Date(date).toLocaleString() + '</td>';
        html += '<td><span class="status-badge ' + statusClass + '">' + statusLabel + '</span></td>';
        html += '<td>';
        html += '<button class="btn-edit" onclick="loadFromHistory(' + index + ')">✏️ Buka</button>';
        
        if (item.status === 'downloaded' || item.status === 'submitted' || item.status === 'approved') {
            html += ' <button class="btn-preview" onclick="previewFromHistory(' + index + ')">👁 Preview</button>';
        }
        
        if (item.status === 'downloaded') {
            html += ' <button class="btn-kirim" onclick="openUploadModal(' + index + ')" style="background:#E53935;color:#fff;border:none;padding:2px 12px;border-radius:4px;font-size:11px;cursor:pointer;">📤 Kirim</button>';
        }
        
        if (item.status === 'submitted') {
            html += ' <span style="color:#F5A623;font-size:11px;font-weight:600;">⏳ Menunggu Verifikasi</span>';
        }
        
        if (item.status === 'approved') {
            html += ' <span style="color:#1A7A45;font-size:11px;font-weight:600;">✅ Disetujui</span>';
        }
        
        if (item.status === 'rejected') {
            html += ' <span style="color:#C62828;font-size:11px;font-weight:600;">❌ Ditolak</span>';
            if (item.admin_note) {
                html += '<br><small style="color:#C62828;font-size:10px;">📝 ' + item.admin_note + '</small>';
            }
        }
        
        if (item.status === 'draft' || item.status === 'downloaded') {
            html += ' <button class="btn-delete" onclick="deleteHistory(' + index + ')">🗑 Hapus</button>';
        }
        
        html += '</td></tr>';
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// ================================================================
// EDIT SUBMISSION
// ================================================================
function editSubmission(id) {
    fetch('api/get_submission.php?id='+id)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data && data.form_data) {
                var formData = JSON.parse(data.form_data);
                for (var key in formData) {
                    if (key === 'photos') { photos = formData.photos || []; renderPhotos(); continue; }
                    if (key === 'uraian') {
                        if (quill && formData.uraian) {
                            quill.root.innerHTML = formData.uraian;
                            enhanceSimpleTables(quill.root);
                        }
                        document.getElementById('uraian').value = formData.uraian || '';
                        continue;
                    }
                    var el = document.getElementById(key);
                    if (el) {
                        if (el.type === 'checkbox') el.checked = formData[key] === true;
                        else el.value = formData[key] || '';
                    }
                }
                submissionId = id;
                var draft = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
                draft.submission_id = id;
                localStorage.setItem(STORAGE_KEY, JSON.stringify(draft));
                if (formData.ada_pelanggaran) { document.getElementById('ada_pelanggaran').checked = true; togglePelanggaran(); }
                if (formData.ada_sengketa) { document.getElementById('ada_sengketa').checked = true; toggleSengketa(); }
                switchTab('form');
                showToast('📝 Data dimuat untuk diedit', 'info');
            }
        })
        .catch(function() {});
}

function previewSubmission(id) {
    fetch('api/get_submission.php?id='+id)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data && data.form_data) {
                var formData = JSON.parse(data.form_data);
                for (var key in formData) {
                    if (key === 'photos') { photos = formData.photos || []; continue; }
                    if (key === 'uraian') {
                        if (quill && formData.uraian) {
                            quill.root.innerHTML = formData.uraian;
                            enhanceSimpleTables(quill.root);
                        }
                        document.getElementById('uraian').value = formData.uraian || '';
                        continue;
                    }
                    var el = document.getElementById(key);
                    if (el) {
                        if (el.type === 'checkbox') el.checked = formData[key] === true;
                        else el.value = formData[key] || '';
                    }
                }
                generatePreview();
                switchTab('preview');
            }
        })
        .catch(function() {});
}

// ================================================================
// SAVE TO HISTORY
// ================================================================
function saveToHistory(data) {
    try {
        var history = JSON.parse(localStorage.getItem('form_history') || '[]');
        var formKey = 'form_a';
        var userId = <?= $_SESSION['user_id'] ?>;
        
        var existingIndex = -1;
        if (data.submission_id) {
            existingIndex = history.findIndex(function(item) {
                return item.form_key === formKey && item.user_id === userId && item.submission_id === data.submission_id;
            });
        }
        
        var entry = {
            form_key: formKey,
            user_id: userId,
            submission_id: data.submission_id || Date.now(),
            status: data.status || 'draft',
            created_at: data.created_at || new Date().toISOString(),
            updated_at: data.updated_at || new Date().toISOString(),
            form_data: data
        };
        
        if (existingIndex >= 0) {
            history[existingIndex] = entry;
        } else {
            history.unshift(entry);
        }
        
        if (history.length > 50) {
            history = history.slice(0, 50);
        }
        localStorage.setItem('form_history', JSON.stringify(history));
    } catch (e) {
        console.error('Save history error:', e);
    }
}

// ================================================================
// LOAD FROM HISTORY
// ================================================================
function loadFromHistory(index) {
    try {
        var history = JSON.parse(localStorage.getItem('form_history') || '[]');
        var formKey = 'form_a';
        var userId = <?= $_SESSION['user_id'] ?>;
        
        var myHistory = history.filter(function(item) {
            return item.form_key === formKey && item.user_id === userId;
        });
        var reversed = [...myHistory].reverse();
        var item = reversed[index];
        
        if (!item || !item.form_data) {
            showToast('❌ Data tidak ditemukan', 'error');
            return;
        }
        
        var data = item.form_data;
        for (var key in data) {
            if (key === 'photos') {
                photos = data.photos || [];
                renderPhotos();
                continue;
            }
            if (key === 'submission_id') {
                submissionId = data.submission_id;
                continue;
            }
            if (key === 'status' || key === 'created_at' || key === 'updated_at' || key === 'downloaded_at') {
                continue;
            }
            if (key === 'uraian') {
                if (quill && data.uraian) {
                    quill.root.innerHTML = data.uraian;
                }
                document.getElementById('uraian').value = data.uraian || '';
                continue;
            }
            var el = document.getElementById(key);
            if (el) {
                if (el.type === 'checkbox') {
                    el.checked = data[key] === true;
                } else {
                    el.value = data[key] || '';
                }
            }
        }
        
        if (item.submission_id) {
            submissionId = item.submission_id;
            var draft = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
            draft.submission_id = item.submission_id;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(draft));
        }
        
        if (data.ada_pelanggaran) { document.getElementById('ada_pelanggaran').checked = true; togglePelanggaran(); }
        if (data.ada_sengketa) { document.getElementById('ada_sengketa').checked = true; toggleSengketa(); }
        
        showToast('📝 Data dimuat dari riwayat', 'success');
        switchTab('form');
    } catch (e) {
        showToast('❌ Gagal memuat data', 'error');
    }
}

// ================================================================
// PREVIEW FROM HISTORY
// ================================================================
function previewFromHistory(index) {
    try {
        var history = JSON.parse(localStorage.getItem('form_history') || '[]');
        var formKey = 'form_a';
        var userId = <?= $_SESSION['user_id'] ?>;
        
        var myHistory = history.filter(function(item) {
            return item.form_key === formKey && item.user_id === userId;
        });
        var reversed = [...myHistory].reverse();
        var item = reversed[index];
        
        if (!item || !item.form_data) {
            showToast('❌ Data tidak ditemukan', 'error');
            return;
        }
        
        var data = item.form_data;
        for (var key in data) {
            if (key === 'photos') {
                photos = data.photos || [];
                continue;
            }
            if (key === 'submission_id') {
                submissionId = data.submission_id;
                continue;
            }
            if (key === 'status' || key === 'created_at' || key === 'updated_at' || key === 'downloaded_at') {
                continue;
            }
            if (key === 'uraian') {
                if (quill && data.uraian) {
                    quill.root.innerHTML = data.uraian;
                }
                document.getElementById('uraian').value = data.uraian || '';
                continue;
            }
            var el = document.getElementById(key);
            if (el) {
                if (el.type === 'checkbox') {
                    el.checked = data[key] === true;
                } else {
                    el.value = data[key] || '';
                }
            }
        }
        generatePreview();
        switchTab('preview');
    } catch (e) {
        showToast('❌ Gagal preview', 'error');
    }
}

// ================================================================
// DELETE HISTORY
// ================================================================
function deleteHistory(index) {
    if (!confirm('Yakin ingin menghapus riwayat ini?')) return;
    try {
        var history = JSON.parse(localStorage.getItem('form_history') || '[]');
        var formKey = 'form_a';
        var userId = <?= $_SESSION['user_id'] ?>;
        
        var myHistory = history.filter(function(item) {
            return item.form_key === formKey && item.user_id === userId;
        });
        var reversed = [...myHistory].reverse();
        var item = reversed[index];
        
        var originalIndex = history.findIndex(function(h) {
            return h.submission_id === item.submission_id && h.form_key === formKey && h.user_id === userId;
        });
        
        if (originalIndex >= 0) {
            history.splice(originalIndex, 1);
            localStorage.setItem('form_history', JSON.stringify(history));
            loadRiwayat();
            showToast('🗑 Riwayat dihapus', 'success');
        }
    } catch (e) {
        showToast('❌ Gagal hapus', 'error');
    }
}

// ================================================================
// TOAST
// ================================================================
function showToast(msg, type, persistent = false) {
    var old = document.querySelector('.toast-message');
    if (old) old.remove();
    
    var toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        padding: 12px 24px;
        border-radius: 10px;
        font-weight: 600;
        z-index: 9999;
        box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        max-width: 90%;
        transition: opacity 0.3s;
        font-size: 14px;
    `;
    
    var colors = {
        success: '#2E7D32',
        error: '#C62828',
        warning: '#F5A623',
        info: '#2D5BE3'
    };
    
    toast.style.background = colors[type] || '#1A1A2E';
    toast.style.color = '#fff';
    
    if (persistent) {
        toast.innerHTML = msg + ' <span class="spinner">⟳</span>';
    } else {
        toast.textContent = msg;
    }
    
    document.body.appendChild(toast);
    
    if (!persistent) {
        setTimeout(function() {
            toast.style.opacity = '0';
            setTimeout(function() { toast.remove(); }, 300);
        }, 3000);
    }
}

// ================================================================
// INIT
// ================================================================
document.addEventListener('DOMContentLoaded', async function() {
    var today = new Date().toISOString().slice(0,10);
    ['tgl_laporan', 'tgl_kegiatan', 'ttd_tgl'].forEach(function(id) {
        var el = document.getElementById(id);
        if (el && !el.value) el.value = today;
    });
    
    // Ikon tombol tabel (tanpa dependency library eksternal - andal & selalu tersedia)
    var Icons = Quill.import('ui/icons');
    Icons['insertTable'] = '<span class="ql-table-icon">▦</span>';

    // Coba muat modul Quill Better Table (dicoba dari beberapa CDN). Modul ini
    // mendukung tabel asli yang bisa diedit, di-resize kolomnya, dan di-merge/split.
    // Kalau semua sumber gagal (mis. CDN diblok jaringan), editor tetap jalan normal
    // dan insert tabel otomatis jatuh ke mode fallback (tetap editable & resizable).
    window.BETTER_TABLE_READY = false;
    var loaded = await window.__loadBetterTable();
    if (loaded && typeof QuillBetterTable !== 'undefined') {
        try {
            Quill.register({ 'modules/better-table': QuillBetterTable }, true);
            window.BETTER_TABLE_READY = true;
        } catch (regErr) {
            console.error('Gagal mendaftarkan modul better-table:', regErr);
        }
    } else {
        console.warn('Semua sumber CDN QuillBetterTable gagal dimuat - insert tabel akan pakai mode fallback (tetap bisa diedit & di-resize).');
    }

    // Toolbar dirampingkan, konsisten dengan editor "Hasil Tugas" di form a
    var quillModules = {
        toolbar: {
            container: [
                [{ 'header': [1, 2, 3, false] }],
                ['bold', 'italic', 'underline', 'strike'],
                [{ 'color': [] }, { 'background': [] }],
                [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                [{ 'indent': '-1' }, { 'indent': '+1' }],
                [{ 'align': [] }],
                ['blockquote', 'code-block'],
                ['link'],
                ['insertTable'],
                ['clean']
            ],
            handlers: {
                insertTable: function() { openTablePicker(); }
            }
        }
    };

    // Kunci 'better-table' dan override keyboard bindings HANYA ditambahkan kalau modulnya
    // sukses terdaftar. Kalau tidak, jangan sampai Quill mencoba mencari modul yang tidak
    // ada (itu yang bikin "new Quill(...)" gagal total dan variabel quill jadi null).
    if (window.BETTER_TABLE_READY) {
        quillModules.table = false; // matikan modul table bawaan, dipakai better-table
        quillModules['better-table'] = {
            operationMenu: {
                items: {
                    unmergeCells: { text: 'Pisah sel' }
                }
            }
        };
        quillModules.keyboard = { bindings: QuillBetterTable.keyboardBindings };
    }

    try {
        quill = new Quill('#editor_uraian', {
            theme: 'snow',
            modules: quillModules,
            placeholder: 'Tulis uraian hasil pengawasan di sini...'
        });
    } catch (err) {
        console.error('Gagal inisialisasi editor:', err);
        showToast('❌ Editor uraian gagal dimuat', 'error');
        return;
    }

    // Beri tooltip pada tombol tabel
    var tableBtn = document.querySelector('.ql-insertTable');
    if (tableBtn) { tableBtn.title = 'Sisipkan Tabel'; }

    quill.on('text-change', function() {
        document.getElementById('uraian').value = getCleanUraianHTML();
    });

    loadDraft();
    enhanceSimpleTables(quill.root);
    loadRiwayat();
});

// ================================================================
// TABEL: picker jumlah baris/kolom lalu insert ke editor
// ================================================================
function openTablePicker() {
    var existing = document.getElementById('tablePickerModal');
    if (existing) existing.remove();

    var modal = document.createElement('div');
    modal.id = 'tablePickerModal';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.35);z-index:9998;display:flex;align-items:center;justify-content:center;';
    modal.innerHTML =
        '<div style="background:#fff;border-radius:12px;padding:20px;width:260px;box-shadow:0 10px 40px rgba(0,0,0,0.25);">' +
            '<h3 style="margin:0 0 12px;font-size:15px;color:#1A1A2E;">📊 Sisipkan Tabel</h3>' +
            '<div class="form-group"><label>Jumlah Baris</label><input type="number" id="tblRows" min="1" max="20" value="3"></div>' +
            '<div class="form-group"><label>Jumlah Kolom</label><input type="number" id="tblCols" min="1" max="10" value="3"></div>' +
            '<div class="btn-row" style="margin-top:6px;">' +
                '<button class="btn btn-outline btn-sm" onclick="closeTablePicker()">Batal</button>' +
                '<button class="btn btn-primary btn-sm" onclick="confirmInsertTable()">Sisipkan</button>' +
            '</div>' +
        '</div>';
    document.body.appendChild(modal);
}

function closeTablePicker() {
    var modal = document.getElementById('tablePickerModal');
    if (modal) modal.remove();
}

// ----------------------------------------------------------------
// Bangun markup tabel fallback: dibungkus wrapper contenteditable="false"
// tapi <table> di dalamnya contenteditable="true" ("pulau editable"), supaya
// Quill tidak menghapus/merapikan strukturnya, sementara isi sel tetap bisa
// diketik langsung oleh pengguna.
// ----------------------------------------------------------------
function buildSimpleTableHTML(rows, cols) {
    var colWidth = 100;
    var html = '<div class="simple-table-wrap" data-simple-table="1" contenteditable="false">';
    html += '<table class="ql-table" contenteditable="true"><colgroup>';
    for (var c = 0; c < cols; c++) html += '<col style="width:' + colWidth + 'px;">';
    html += '</colgroup><tbody>';
    for (var r = 0; r < rows; r++) {
        html += '<tr>';
        for (c = 0; c < cols; c++) {
            var cellText = (r === 0) ? ('Kolom ' + (c + 1)) : '';
            html += '<td style="height:32px;">' + cellText + '</td>';
        }
        html += '</tr>';
    }
    html += '</tbody></table></div><p><br></p>';
    return html;
}

// Pasang handle resize kolom & baris pada semua tabel fallback yang belum diaktifkan
function enhanceSimpleTables(root) {
    if (!root) return;
    var wraps = root.querySelectorAll('.simple-table-wrap[data-simple-table="1"]');
    wraps.forEach(function(wrap) {
        if (wrap.dataset.enhanced === '1') return;
        wrap.dataset.enhanced = '1';
        var table = wrap.querySelector('table');
        if (!table) return;
        addColumnHandles(wrap, table);
        addRowHandles(wrap, table);
        if (window.ResizeObserver) {
            var ro = new ResizeObserver(function() { repositionAllHandles(wrap); });
            ro.observe(table);
        }
    });
}

function addColumnHandles(wrap, table) {
    var colgroup = table.querySelector('colgroup');
    var cols = colgroup ? Array.prototype.slice.call(colgroup.children) : [];
    var headerRow = table.querySelector('tr');
    if (!headerRow) return;
    var cells = Array.prototype.slice.call(headerRow.children);

    cells.forEach(function(cell, idx) {
        if (idx === cells.length - 1) return; // kolom terakhir tidak perlu handle

        var handle = document.createElement('div');
        handle.className = 'col-resize-handle';
        handle.contentEditable = 'false';
        wrap.appendChild(handle);

        function reposition() {
            var wrapRect = wrap.getBoundingClientRect();
            var cellRect = cell.getBoundingClientRect();
            handle.style.left = (cellRect.right - wrapRect.left - 3) + 'px';
            handle.style.top = '0px';
            handle.style.height = wrap.offsetHeight + 'px';
        }
        reposition();
        handle._reposition = reposition;

        function startColResize(startX) {
            var col = cols[idx];
            var startWidth = (col ? col.getBoundingClientRect().width : cell.getBoundingClientRect().width);

            function onMove(clientX) {
                var newW = Math.max(30, startWidth + (clientX - startX));
                if (col) col.style.width = newW + 'px'; else cell.style.width = newW + 'px';
                repositionAllHandles(wrap);
            }
            function onMouseMove(ev) { onMove(ev.clientX); }
            function onTouchMove(ev) { ev.preventDefault(); onMove(ev.touches[0].clientX); }
            function onUp() {
                document.removeEventListener('mousemove', onMouseMove);
                document.removeEventListener('mouseup', onUp);
                document.removeEventListener('touchmove', onTouchMove);
                document.removeEventListener('touchend', onUp);
                syncUraianField();
            }

            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onUp);
            document.addEventListener('touchmove', onTouchMove, { passive: false });
            document.addEventListener('touchend', onUp);
        }

        handle.addEventListener('mousedown', function(e) {
            e.preventDefault();
            startColResize(e.clientX);
        });
        handle.addEventListener('touchstart', function(e) {
            e.preventDefault();
            startColResize(e.touches[0].clientX);
        }, { passive: false });
    });
}

function addRowHandles(wrap, table) {
    var rows = Array.prototype.slice.call(table.querySelectorAll('tr'));

    rows.forEach(function(row) {
        var handle = document.createElement('div');
        handle.className = 'row-resize-handle';
        handle.contentEditable = 'false';
        wrap.appendChild(handle);

        function reposition() {
            var wrapRect = wrap.getBoundingClientRect();
            var rowRect = row.getBoundingClientRect();
            handle.style.top = (rowRect.bottom - wrapRect.top - 3) + 'px';
            handle.style.left = '0px';
            handle.style.width = wrap.offsetWidth + 'px';
        }
        reposition();
        handle._reposition = reposition;

        function startRowResize(startY) {
            var startHeight = row.getBoundingClientRect().height;

            function onMove(clientY) {
                var newH = Math.max(20, startHeight + (clientY - startY));
                Array.prototype.forEach.call(row.children, function(td) { td.style.height = newH + 'px'; });
                repositionAllHandles(wrap);
            }
            function onMouseMove(ev) { onMove(ev.clientY); }
            function onTouchMove(ev) { ev.preventDefault(); onMove(ev.touches[0].clientY); }
            function onUp() {
                document.removeEventListener('mousemove', onMouseMove);
                document.removeEventListener('mouseup', onUp);
                document.removeEventListener('touchmove', onTouchMove);
                document.removeEventListener('touchend', onUp);
                syncUraianField();
            }

            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onUp);
            document.addEventListener('touchmove', onTouchMove, { passive: false });
            document.addEventListener('touchend', onUp);
        }

        handle.addEventListener('mousedown', function(e) {
            e.preventDefault();
            startRowResize(e.clientY);
        });
        handle.addEventListener('touchstart', function(e) {
            e.preventDefault();
            startRowResize(e.touches[0].clientY);
        }, { passive: false });
    });
}

function repositionAllHandles(wrap) {
    Array.prototype.forEach.call(wrap.querySelectorAll('.col-resize-handle, .row-resize-handle'), function(h) {
        if (h._reposition) h._reposition();
    });
}

function confirmInsertTable() {
    var rows = parseInt(document.getElementById('tblRows').value, 10) || 3;
    var cols = parseInt(document.getElementById('tblCols').value, 10) || 3;
    closeTablePicker();
    if (!rows || !cols || rows < 1 || cols < 1) {
        showToast('❌ Jumlah baris/kolom tidak valid', 'error');
        return;
    }
    if (!quill) {
        showToast('❌ Editor belum siap, muat ulang halaman', 'error');
        return;
    }

    // Mode utama: pakai modul Quill Better Table (tabel asli, bisa merge/split/resize)
    if (window.BETTER_TABLE_READY) {
        try {
            var tableModule = quill.getModule('better-table');
            if (!tableModule) throw new Error('Modul tabel belum siap');

            var range = quill.getSelection(true) || { index: quill.getLength() };
            quill.setSelection(range.index, 0);
            tableModule.insertTable(rows, cols);

            // Isi baris pertama sebagai header "Kolom 1..N" (opsional, best-effort)
            setTimeout(function() {
                try {
                    var tables = quill.root.querySelectorAll('table.quill-better-table');
                    var tbl = tables[tables.length - 1];
                    if (tbl) {
                        var firstRow = tbl.querySelector('tr');
                        if (firstRow) {
                            var cells = firstRow.querySelectorAll('td');
                            cells.forEach(function(cell, idx) {
                                var target = cell.querySelector('p') || cell;
                                if (!target.textContent.trim()) target.textContent = 'Kolom ' + (idx + 1);
                            });
                            syncUraianField();
                        }
                    }
                } catch (e) { /* isi header opsional, abaikan jika gagal */ }
            }, 50);

            showToast('📊 Tabel disisipkan', 'success');
            return;
        } catch (err) {
            console.error('Gagal insert tabel (better-table):', err);
            // lanjut ke fallback di bawah, jangan langsung menyerah
        }
    }

    // Fallback: modul better-table tidak tersedia (CDN gagal dimuat, dsb).
    // Sisipkan tabel sebagai "pulau" contenteditable=true di dalam wrapper
    // contenteditable=false, supaya Quill tidak merusak isinya saat re-render,
    // lalu dilengkapi handle drag untuk resize kolom/baris.
    try {
        var html = buildSimpleTableHTML(rows, cols);
    
        quill.focus();
        var sel = quill.getSelection(true);
        var idx = sel ? sel.index : quill.getLength();
        var leaf = quill.getLeaf(idx)[0];
        var domNode = (leaf && leaf.domNode) ? leaf.domNode : quill.root;
        var anchor = (domNode.nodeType === 3) ? domNode.parentNode : domNode;
        anchor.insertAdjacentHTML('afterend', html);
    
        enhanceSimpleTables(quill.root);
        syncUraianField();
    
        showToast('📊 Tabel disisipkan (mode fallback - bisa diedit & di-resize)', 'success');
    } catch (err) {
        console.error('Gagal insert tabel:', err);
        showToast('❌ Gagal menyisipkan tabel: ' + (err && err.message ? err.message : 'error tidak diketahui'), 'error');
    }
}

// ================================================================
// UPLOAD FILE - MODAL KIRIM PDF
// ================================================================
var uploadModal = null;
function openUploadModal(index) {
try {
var history = JSON.parse(localStorage.getItem('form_history') || '[]');
var formKey = '<?= $form_key ?>';
var userId = <?= $_SESSION['user_id'] ?>;
var myHistory = history.filter(function(item) {
return item.form_key === formKey && item.user_id === userId;
});
var reversed = [...myHistory].reverse();
var item = reversed[index];
if (!item || !item.submission_id) {
showToast('Data tidak ditemukan', 'error');
return;
}
// Buat modal
var modal = document.createElement('div');
modal.id = 'uploadModal';
modal.style.cssText = `
position: fixed;
inset: 0;
background: rgba(0,0,0,0.5);
z-index: 9999;
display: flex;
align-items: center;
justify-content: center;
`;
modal.innerHTML = `
<div style="background:#fff;border-radius:12px;padding:24px;max-width:450px;width:90%;">
<h3 style="margin:0 0 8px;">Kirim File PDF</h3>
<p style="color:#6B7A99;font-size:13px;margin-bottom:16px;">
Kirim file PDF hasil generate ke admin untuk diverifikasi.
</p>
<div style="border:2px dashed #DDE3F0;border-radius:8px;padding:20px;text-align:center;cursor:pointer;"
onclick="document.getElementById('fileInput').click()">
<div style="font-size:36px;">􀀂</div>
<p style="margin:4px 0;font-size:13px;color:#6B7A99;">Klik untuk pilih file PDF</p>
<small style="color:#999;">Maks. 10MB</small>
<input type="file" id="fileInput" accept=".pdf" style="display:none;"
onchange="uploadFile(this, ${item.submission_id})">
</div>
<div id="uploadProgress" style="display:none;margin-top:12px;">
<div style="background:#f0f0f0;border-radius:4px;height:6px;overflow:hidden;">
<div id="progressBar" style="background:#E53935;height:100%;width:0%;transition:width 0.3s;"></div>
</div>
<p id="progressText" style="font-size:12px;color:#6B7A99;margin-top:4px;">Mengupload...</p>
</div>
<div style="display:flex;gap:8px;margin-top:16px;justify-content:flex-end;">
<button class="btn btn-outline btn-sm" onclick="closeUploadModal()">Batal</button>
</div>
</div>
`;
document.body.appendChild(modal);
uploadModal = modal;
} catch (e) {
showToast('Gagal membuka modal: ' + e.message, 'error');
}
}
function closeUploadModal() {
if (uploadModal) {
uploadModal.remove();
uploadModal = null;
}
}
function uploadFile(input, submissionId) {
var file = input.files[0];
if (!file) return;
// Validasi
if (file.type !== 'application/pdf') {
showToast('Hanya file PDF yang diizinkan', 'error');
input.value = '';
return;
}
if (file.size > 10 * 1024 * 1024) {
showToast('File terlalu besar. Maks 10MB', 'error');
input.value = '';
return;
}
// Tampilkan progress
document.getElementById('uploadProgress').style.display = 'block';
document.getElementById('progressText').textContent = 'Mengupload ' + file.name + '...';
document.getElementById('progressBar').style.width = '30%';
var formData = new FormData();
formData.append('file', file);
formData.append('submission_id', submissionId);
fetch('api/upload_file.php', {
method: 'POST',
body: formData
})
.then(function(res) { return res.json(); })
.then(function(result) {
document.getElementById('progressBar').style.width = '100%';
if (result.success) {
document.getElementById('progressText').textContent = result.message;
document.getElementById('progressText').style.color = '#1A7A45';
// Update status di localStorage
updateSubmissionStatus(submissionId, 'submitted');
setTimeout(function() {
closeUploadModal();
loadRiwayat();
showToast('File berhasil dikirim!', 'success');
}, 1500);
} else {
document.getElementById('progressText').textContent = result.message;
document.getElementById('progressText').style.color = '#C62828';
document.getElementById('progressBar').style.width = '0%';
showToast(result.message, 'error');
}
})
.catch(function(err) {
document.getElementById('progressText').textContent = 'Gagal upload: ' + err.message;
document.getElementById('progressText').style.color = '#C62828';
document.getElementById('progressBar').style.width = '0%';
showToast('Gagal upload', 'error');
});
}
function updateSubmissionStatus(submissionId, newStatus) {
try {
var history = JSON.parse(localStorage.getItem('form_history') || '[]');
var formKey = '<?= $form_key ?>';
var userId = <?= $_SESSION['user_id'] ?>;
var index = history.findIndex(function(item) {
return item.form_key === formKey &&
item.user_id === userId &&
item.submission_id === submissionId;
});
if (index >= 0) {
history[index].status = newStatus;
history[index].updated_at = new Date().toISOString();
localStorage.setItem('form_history', JSON.stringify(history));
}
} catch (e) {
console.error('Update status error:', e);
}
}

</script>
<?php include 'bottom_nav.php'; ?>
</body>
</html>