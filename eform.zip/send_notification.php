<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireAdmin();

$message = '';
$messageType = '';

// Filter user berdasarkan role yang login
$current_user_id = $_SESSION['user_id'];
$current_role = $_SESSION['role'] ?? 'user';

if ($current_role === 'super_admin') {
    // Super Admin: lihat SEMUA user aktif KECUALI dirinya sendiri
    $stmt = $pdo->prepare("SELECT id, username, fullname, email, role FROM users WHERE is_active = 1 AND id != ? ORDER BY role, username");
    $stmt->execute([$current_user_id]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Admin: lihat user yang dibuatnya SAJA (tanpa dirinya sendiri)
    $stmt = $pdo->prepare("SELECT id, username, fullname, email, role FROM users WHERE created_by = ? AND is_active = 1 AND id != ? ORDER BY role, username");
    $stmt->execute([$current_user_id, $current_user_id]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// ============================================
// FUNGSI KIRIM KE ONESIGNAL (DENGAN DEBUG)
// ============================================
function kirimNotifikasiKeOneSignal($judul, $pesan, $link = null) {
    $appId = '01cb3e1a-38ba-4514-8643-8782e78463a1';
    $apiKey = 'os_v2_app_ahft4gryxjcrjbsdq6bopbdduexmp2vcyqbu6z42273kfakmxqunc5z72zzlrxhv5wwg2x5o27antbk6toxulzvxzt3st4gba6iihia';
    
    $data = [
        'app_id' => $appId,
        'headings' => ['en' => $judul],
        'contents' => ['en' => $pesan],
        'included_segments' => ['Subscribed Users']
    ];
    
    if ($link) {
        $data['data'] = ['link' => $link];
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://onesignal.com/api/v1/notifications');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Basic ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    // DEBUG: TULIS RESPON KE FILE LOG
    $log = "========== " . date('Y-m-d H:i:s') . " ==========\n";
    $log .= "HTTP Code: " . $httpCode . "\n";
    $log .= "Response: " . $response . "\n";
    if ($error) {
        $log .= "cURL Error: " . $error . "\n";
    }
    $log .= "Data Sent: " . json_encode($data) . "\n";
    $log .= "=====================================\n\n";
    
    file_put_contents(__DIR__ . '/onesignal_debug.log', $log, FILE_APPEND);
    
    return $httpCode == 200;
}
// ============================================

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_notification'])) {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $type = $_POST['type'] ?? 'info';
    $link = trim($_POST['link'] ?? '');
    $target = $_POST['target'] ?? 'all';
    $selected_users = $_POST['selected_users'] ?? [];

    if (empty($title) || empty($content)) {
        $message = '⚠️ Judul dan pesan harus diisi!';
        $messageType = 'error';
    } else {
        // ============================================
        // TENTUKAN TARGET USER
        // ============================================
        $targetUsers = [];

        if ($target === 'selected') {
            // Pilih manual — filter dari $users yang sudah dibersihkan
            $selected_ids = array_map('intval', $selected_users);
            foreach ($users as $u) {
                if (in_array((int)$u['id'], $selected_ids, true)) {
                    $targetUsers[] = $u;
                }
            }
        } elseif ($current_role === 'super_admin') {
            if ($target === 'all') {
                $targetUsers = $users;
            } elseif ($target === 'admin') {
                $targetUsers = array_filter($users, function($u) {
                    return in_array($u['role'], ['super_admin', 'admin']);
                });
            } elseif ($target === 'user') {
                $targetUsers = array_filter($users, function($u) {
                    return $u['role'] === 'user';
                });
            }
        } else {
            // Admin biasa: semua user yang dia buat
            $targetUsers = $users;
        }

        // ============================================
        // PENGAMAN FINAL: pastikan tidak ada diri sendiri
        // ============================================
        $targetUsers = array_filter($targetUsers, function($u) use ($current_user_id) {
            return (int)$u['id'] !== (int)$current_user_id;
        });
        $targetUsers = array_values($targetUsers);

        if (empty($targetUsers)) {
            $message = '⚠️ Tidak ada user yang dipilih!';
            $messageType = 'error';
        } else {
            $successCount = 0;

            // 1. SIMPAN KE DATABASE
            foreach ($targetUsers as $user) {
                $stmt = $pdo->prepare("INSERT INTO notifications (user_id, sender_id, title, message, type, link, is_read, created_at) VALUES (?, ?, ?, ?, ?, ?, 0, NOW())");
                $stmt->execute([
                    $user['id'],
                    $_SESSION['user_id'],
                    $title,
                    $content,
                    $type,
                    $link
                ]);
                $successCount++;
            }

            // 2. KIRIM KE ONESIGNAL
            $pushStatus = kirimNotifikasiKeOneSignal($title, $content, $link);

// 3. LOGGING
// logAction($_SESSION['user_id'], "Send notification: $title (Target: $target, Count: $successCount" . ($pushStatus ? ", OneSignal: OK" : ", OneSignal: GAGAL") . ")");
            
            $message = "✅ Notifikasi berhasil dikirim ke <strong>{$successCount}</strong> user!";
            if ($pushStatus) {
                $message .= " 📱 Notifikasi push juga terkirim ke perangkat Android.";
            } else {
                $message .= " ⚠️ Notifikasi push Android gagal terkirim (cek koneksi/konfigurasi).";
            }
            $messageType = 'success';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kirim Notifikasi - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .send-container { max-width: 650px; margin: 0 auto; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 4px; color: #1A1A2E; font-size: 13px; }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%; padding: 8px 12px; border: 1.5px solid #DDE3F0; border-radius: 8px; font-size: 14px; font-family: inherit;
        }
        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            border-color: #E53935; outline: none;
        }
        .form-group textarea { min-height: 100px; resize: vertical; }
        .alert { padding: 10px 14px; border-radius: 8px; margin-bottom: 14px; }
        .alert-success { background: #EEFAF4; color: #1A7A45; border: 1px solid #B6E8CF; }
        .alert-error { background: #FFE5E5; color: #C62828; border: 1px solid #FFB3B3; }
        .btn { display: inline-block; padding: 10px 24px; border-radius: 8px; font-weight: 700; cursor: pointer; border: none; font-size: 14px; transition: 0.2s; }
        .btn-primary { background: #E53935; color: #fff; }
        .btn-primary:hover { background: #c62828; }
        .btn-secondary { background: #6B7A99; color: #fff; }
        .btn-secondary:hover { background: #5a6a89; }
        .user-list { max-height: 200px; overflow-y: auto; border: 1px solid #DDE3F0; border-radius: 8px; padding: 8px 12px; background: #FAFBFD; }
        .user-list label { display: block; padding: 4px 0; font-size: 13px; cursor: pointer; }
        .user-list label:hover { background: #F0F2F8; }
        .user-list input[type="checkbox"] { margin-right: 8px; }
        .selected-info { font-size: 12px; color: #6B7A99; margin-top: 4px; }
        .role-badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
        .role-badge.super_admin { background: #FFD700; color: #1A1A2E; }
        .role-badge.admin { background: #2D5BE3; color: #fff; }
        .role-badge.user { background: #6B7A99; color: #fff; }
        .preview-box { background: #F8F9FC; border: 1px solid #DDE3F0; border-radius: 8px; padding: 12px 14px; font-size: 13px; color: #1A1A2E; }
        .preview-box .title { font-weight: 700; font-size: 14px; }
        .preview-box .time { color: #6B7A99; font-size: 11px; }
        .card { background: #fff; border-radius: 12px; border: 1px solid #DDE3F0; margin-bottom: 16px; }
        .card-header { padding: 14px 18px; border-bottom: 1px solid #DDE3F0; font-weight: 700; }
        .card-body { padding: 14px 18px; }
    </style>
</head>
<body>
<?php include "sidebar.php"; ?>
    <div class="app">

        <main class="main">
            <div class="send-container">
                <header class="topbar">
                    <div class="topbar-left"><h2>📤 Kirim Notifikasi</h2></div>
                    <div class="topbar-right">
                        <span class="user-badge">👤 <?= htmlspecialchars($_SESSION['fullname']) ?> <span class="role-badge"><?= $_SESSION['role'] ?></span></span>
                    </div>
                </header>

                <?php if ($message): ?>
                <div class="alert alert-<?= $messageType ?>"><?= $message ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header"><h3>📤 Kirim Notifikasi ke User</h3></div>
                    <div class="card-body">
                        <form method="POST" onsubmit="return confirm('Kirim notifikasi ini?')">
                            <div class="form-group">
                                <label>Target Penerima</label>
                            <select name="target" id="targetSelect" onchange="toggleUserList()" style="width:100%;padding:8px 12px;border:1.5px solid #DDE3F0;border-radius:8px;font-size:14px;">
                                <?php if (hasRole('super_admin')): ?>
                                <option value="all">📬 Semua User</option>
                                <option value="admin">👑 Admin & Super Admin</option>
                                <option value="user">👤 User Biasa</option>
                                <?php else: ?>
                                <option value="all">📬 Semua User Saya</option>
                                <?php endif; ?>
                                <option value="selected">📋 Pilih Manual</option>
                            </select>
                            </div>

                            <div class="form-group" id="userListContainer" style="display:none;">
                                <label>Pilih User:</label>
                                <div class="user-list">
                                    <?php if (empty($users)): ?>
                                        <div style="padding:10px;color:#6B7A99;font-size:12px;">Tidak ada user yang bisa dipilih.</div>
                                    <?php else: ?>
                                        <?php foreach ($users as $u): ?>
                                        <label>
                                            <input type="checkbox" name="selected_users[]" value="<?= $u['id'] ?>">
                                            <?= htmlspecialchars($u['fullname']) ?> (<?= htmlspecialchars($u['username']) ?>) - <?= strtoupper($u['role']) ?>
                                        </label>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                                <div class="selected-info">💡 Centang user yang ingin dikirimi notifikasi. (Diri sendiri tidak bisa dipilih)</div>
                            </div>

                            <div class="form-group">
                                <label>Jenis Notifikasi</label>
                                <select name="type" style="width:100%;padding:8px 12px;border:1.5px solid #DDE3F0;border-radius:8px;font-size:14px;">
                                    <option value="info">ℹ️ Informasi</option>
                                    <option value="success">✅ Sukses</option>
                                    <option value="warning">⚠️ Peringatan</option>
                                    <option value="submitted">📤 Submission</option>
                                    <option value="approved">✅ Disetujui</option>
                                    <option value="rejected">❌ Ditolak</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Judul Notifikasi <span style="color:#E53935;">*</span></label>
                                <input type="text" name="title" placeholder="Contoh: Surat Tugas Baru" required>
                            </div>

                            <div class="form-group">
                                <label>Pesan <span style="color:#E53935;">*</span></label>
                                <textarea name="content" placeholder="Tulis pesan notifikasi..." required></textarea>
                            </div>

                            <div class="form-group">
                                <label>Link (opsional, misal: form_st.php)</label>
                                <input type="text" name="link" placeholder="Contoh: form_st.php atau https://...">
                                <div style="font-size:11px;color:#6B7A99;margin-top:4px;">💡 User akan melihat tombol "Lihat Detail" jika diisi</div>
                            </div>

                            <button type="submit" name="send_notification" class="btn btn-primary">📤 Kirim Notifikasi</button>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h3>📋 Preview Notifikasi</h3></div>
                    <div class="card-body">
                        <div class="preview-box">
                            <div class="title">📌 Judul Notifikasi</div>
                            <div style="margin:4px 0;">Pesan notifikasi akan muncul di sini...</div>
                            <div class="time">🕐 Sekarang • Dari: <?= htmlspecialchars($_SESSION['fullname']) ?></div>
                            <div style="margin-top:6px;"><a href="#" style="color:#2D5BE3;text-decoration:none;">🔗 Lihat Detail →</a></div>
                        </div>
                        <div style="font-size:11px;color:#6B7A99;margin-top:6px;">💡 Preview akan sesuai dengan isian di atas</div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
    function toggleUserList() {
        var val = document.getElementById('targetSelect').value;
        var container = document.getElementById('userListContainer');
        container.style.display = val === 'selected' ? 'block' : 'none';
    }
    // Jalankan saat halaman load, supaya konsisten
    document.addEventListener('DOMContentLoaded', toggleUserList);
    </script>
    <script src="assets/js/main.js"></script>
    <footer style="text-align:center;padding:16px 0 8px;border-top:1px solid #DDE3F0;margin-top:20px;font-size:11px;color:#6B7A99;">
        E-Form System v1.8 &copy; 2026 PT. Nura Kreasi Digital
    </footer>
</body>
</html>