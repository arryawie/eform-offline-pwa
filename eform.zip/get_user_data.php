<?php
require_once 'config/database.php';
require_once 'config/auth.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;

if ($user_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid user ID']);
    exit;
}

// Ambil data user
$stmt = $pdo->prepare("SELECT id, username, fullname, email, role, is_active, created_by FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    http_response_code(404);
    echo json_encode(['error' => 'User not found']);
    exit;
}

// Ambil form access
$stmt = $pdo->prepare("SELECT form_id FROM user_form_access WHERE user_id = ?");
$stmt->execute([$user_id]);
$user['form_access'] = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Ambil daftar form yang tersedia (1 per tipe, sesuai user login)
$current_user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("
    SELECT * FROM forms 
    WHERE user_id IS NULL OR user_id = ? 
    GROUP BY form_key 
    ORDER BY form_name
");
$stmt->execute([$current_user_id]);
$user['available_forms'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($user);
?>