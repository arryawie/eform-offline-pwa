<?php
require_once 'config/database.php';
require_once 'config/auth.php';
$page_title = 'Lisensi';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .legal-container { max-width: 800px; margin: 40px auto; padding: 30px; background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .legal-container h1 { color: #1A1A2E; border-bottom: 2px solid #E53935; padding-bottom: 12px; }
        .legal-container h2 { color: #2D5BE3; margin-top: 24px; font-size: 16px; }
        .legal-container p, .legal-container li { color: #333; line-height: 1.8; font-size: 14px; }
        .legal-container ul { padding-left: 20px; }
        .last-updated { color: #6B7A99; font-size: 12px; margin-top: 30px; border-top: 1px solid #DDE3F0; padding-top: 16px; }
        .btn-back { display: inline-block; padding: 8px 20px; background: #E53935; color: #fff; border-radius: 6px; text-decoration: none; margin-bottom: 16px; }
        .btn-back:hover { background: #c62828; }
        .license-badge { display: inline-block; padding: 4px 16px; background: #EEFAF4; color: #1A7A45; border-radius: 20px; font-size: 13px; font-weight: 600; }
    </style>
</head>
<body>
    <?php include "sidebar.php"; ?>
    <div class="app">
        <main class="main">
            <div class="legal-container">
                <a href="dashboard.php" class="btn-back">← Kembali</a>
                <h1>📄 Lisensi Penggunaan</h1>
                <p class="last-updated">Terakhir diperbarui: <?= date('d F Y') ?></p>

                <h2>1. Jenis Lisensi</h2>
                <ul>
                    <li><strong>Lisensi Tahunan (Subscription)</strong> - Bayar per tahun, dapat VPS, support & update.</li>
                    <li><strong>Jual Lepas (One-Time License)</strong> - Bayar sekali, dapat source code, support 6 bulan.</li>
                </ul>

                <h2>2. Hak Pengguna</h2>
                <ul>
                    <li>Menggunakan sistem sesuai dengan paket yang dibeli.</li>
                    <li>Mendapat update & support selama masa lisensi.</li>
                </ul>

                <h2>3. Larangan</h2>
                <ul>
                    <li>Mendistribusikan ulang source code tanpa izin.</li>
                    <li>Menjual ulang sistem tanpa izin tertulis.</li>
                    <li>Menggunakan sistem untuk tujuan ilegal.</li>
                </ul>

                <h2>4. Pembaharuan Lisensi</h2>
                <ul>
                    <li>Lisensi tahunan wajib diperpanjang setiap tahun.</li>
                    <li>Jual lepas berlaku selamanya tanpa perpanjangan.</li>
                </ul>

                <h2>5. Pengakhiran</h2>
                <p>Lisensi akan dihentikan jika terjadi pelanggaran ketentuan yang berlaku.</p>

                <div style="margin-top:20px;padding:16px;background:#F8F9FC;border-radius:8px;border-left:4px solid #E53935;">
                    <p style="margin:0;font-size:13px;color:#6B7A99;">⚠️ Lisensi ini adalah perjanjian antara pengguna dan PT. Nura Kreasi Digital.</p>
                </div>

                <div class="last-updated">© <?= date('Y') ?> <?= APP_NAME ?> - PT. Nura Kreasi Digital</div>
            </div>
        </main>
    </div>
</body>
</html>
