<?php
// ============================================================
// ADMIN PANEL - VERIFIKASI SUBMISSION
// ============================================================

require_once 'config/database.php';
require_once 'config/auth.php';
requireAdmin();

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? 'user';

// ============================================================
// AMBIL USER YANG DIBUAT ADMIN INI (HANYA ROLE USER)
// ============================================================
$stmt = $pdo->prepare("
    SELECT id, fullname, username 
    FROM users 
    WHERE created_by = ? AND role = 'user'
");
$stmt->execute([$user_id]);
$managedUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
$userIds = array_column($managedUsers, 'id');

// DEBUG:
echo '<!-- DEBUG1 user_id=' . $user_id . ' -->';
echo '<!-- DEBUG2 managedUsers=' . json_encode($managedUsers) . ' -->';
echo '<!-- DEBUG3 userIds=' . json_encode($userIds) . ' -->';

if (empty($userIds)) {
    $userIds = [0];
}

$placeholders = implode(',', array_fill(0, count($userIds), '?'));

// ============================================================
// AMBIL SUBMISSION DENGAN STATUS submitted/APPROVED/REJECTED
// ============================================================
$stmt = $pdo->prepare("
    SELECT
        s.id,
        s.user_id,
        s.status,
        s.updated_at,
        s.pdf_path,
        s.admin_note,
        s.submitted_at,
        s.approved_at,
        s.rejected_at,
        u.fullname,
        u.username,
        f.form_name,
        f.icon
    FROM form_submissions s
    JOIN users u ON s.user_id = u.id
    JOIN forms f ON s.form_id = f.id
    WHERE s.user_id IN ($placeholders)
      AND s.status IN ('submitted', 'approved', 'rejected')
    ORDER BY s.updated_at DESC
    LIMIT 50
");
$stmt->execute($userIds);
$submissions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ============================================================
// DEBUG SEMENTARA
// ============================================================
echo '<!-- ============================ -->';
echo '<!-- SQL QUERY: ' . $stmt->queryString . ' -->';
echo '<!-- userIds: ' . json_encode($userIds) . ' -->';
echo '<!-- placeholders: ' . $placeholders . ' -->';
echo '<!-- COUNT: ' . count($submissions) . ' -->';
if ($stmt->errorInfo()[2]) {
    echo '<!-- SQL ERROR: ' . $stmt->errorInfo()[2] . ' -->';
}
echo '<!-- ============================ -->';   

// DEBUG:
echo '<!-- DEBUG4 placeholders=' . $placeholders . ' -->';
echo '<!-- DEBUG5 userIds=' . json_encode($userIds) . ' -->';
echo '<!-- DEBUG6 submissions_count=' . count($submissions) . ' -->';
echo '<!-- DEBUG7 submissions=' . json_encode($submissions) . ' -->';

// ============================================================
// STATISTIK
// ============================================================
$totalUsers = count($managedUsers);

// Hitung user unik yang sudah download
$downloadedUsers = 0;
if (!empty($userIds) && $userIds[0] != 0) {
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT user_id) as total 
        FROM form_submissions 
        WHERE user_id IN ($placeholders) AND status IN ('downloaded', 'submitted', 'approved')
    ");
    $stmt->execute($userIds);
    $downloadedUsers = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
}

// Hitung yang menunggu verifikasi (submitted)
$pendingCount = 0;
if (!empty($userIds) && $userIds[0] != 0) {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total 
        FROM form_submissions 
        WHERE user_id IN ($placeholders) AND status = 'submitted'
    ");
    $stmt->execute($userIds);
    $pendingCount = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
}

$pendingUsers = $totalUsers - $downloadedUsers;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Verifikasi Submission</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* ===== LAYOUT ===== */
        * { box-sizing: border-box; }
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; margin:0; }
        .app { display: flex; min-height: 100vh; }
        .main { flex: 1; padding: 20px; background: #f0f2f5; }
        .container { max-width: 1100px; margin: 0 auto; }
        
        /* ===== TOPBAR ===== */
        .topbar { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; background: #fff; padding: 15px 24px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .topbar h2 { margin: 0; font-size: 18px; color: #1A1A2E; }
        .user-badge { background: rgba(0,0,0,0.06); padding: 4px 14px; border-radius: 20px; font-size: 13px; color: #1A1A2E; }
        .role-badge { background: #E53935; color: #fff; padding: 2px 10px; border-radius: 12px; font-size: 10px; font-weight: 600; margin-left: 6px; }
        
        /* ===== STATS ===== */
        .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 20px; }
        .stat-card { background: #fff; border-radius: 12px; padding: 16px 20px; border: 1px solid #DDE3F0; text-align: center; box-shadow: 0 2px 6px rgba(0,0,0,0.03); }
        .stat-card .num { font-size: 28px; font-weight: 800; }
        .stat-card .label { font-size: 12px; color: #6B7A99; margin-top: 4px; font-weight: 600; text-transform: uppercase; }
        .stat-card.total .num { color: #2D5BE3; }
        .stat-card.downloaded .num { color: #1A7A45; }
        .stat-card.pending .num { color: #F5A623; }
        .stat-card.submitted .num { color: #C62828; }
        
        /* ===== CARD ===== */
        .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); overflow: hidden; }
        .card-header { padding: 14px 20px; background: #f8f9fc; border-bottom: 1px solid #eee; font-weight: 700; color: #1A1A2E; font-size: 14px; }
        .card-body { padding: 16px 20px; }
        
        /* ===== SUBMISSION CARD ===== */
        .submission-card { background: #fff; border: 1px solid #DDE3F0; border-radius: 10px; padding: 16px 18px; margin-bottom: 12px; transition: 0.2s; }
        .submission-card:hover { border-color: #C0C8E0; box-shadow: 0 4px 12px rgba(0,0,0,0.06); }
        
        /* ===== STATUS BADGE ===== */
        .status-badge { display: inline-block; padding: 3px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; }
        .status-badge.submitted { background: #FFFBEE; color: #B07A00; }
        .status-badge.approved { background: #EEFAF4; color: #1A7A45; }
        .status-badge.rejected { background: #FFE5E5; color: #C62828; }
        
        /* ===== BUTTON ===== */
        .btn { padding: 6px 16px; border: none; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 12px; transition: 0.2s; text-decoration: none; display: inline-block; }
        .btn-primary { background: #2D5BE3; color: #fff; }
        .btn-primary:hover { background: #1A3F8A; }
        .btn-success { background: #2E7D32; color: #fff; }
        .btn-success:hover { background: #1B5E20; }
        .btn-danger { background: #C62828; color: #fff; }
        .btn-danger:hover { background: #8E0000; }
        .btn-sm { padding: 4px 12px; font-size: 11px; }
        
        /* ===== ACTION BUTTONS ===== */
        .action-buttons { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 8px; }
        
        /* ===== ADMIN NOTE ===== */
        .admin-note { background: #FFE5E5; padding: 10px 14px; border-radius: 8px; margin: 8px 0; font-size: 13px; color: #C62828; border-left: 4px solid #C62828; }
        
        /* ===== EMPTY STATE ===== */
        .empty-state { text-align: center; padding: 50px 20px; color: #6B7A99; }
        .empty-state .icon { font-size: 56px; margin-bottom: 12px; }
        .empty-state p { margin: 0; font-size: 15px; }
        .empty-state small { color: #aaa; font-size: 12px; }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .stats { grid-template-columns: repeat(2, 1fr); }
            .sidebar { display: none; }
            .sidebar.open { display: block; position: fixed; top: 0; left: 0; height: 100%; z-index: 1000; width: 260px; }
            .hamburger { display: block; background: none; border: none; font-size: 24px; cursor: pointer; }
        }
        
        /* ===== SIDEBAR ===== */
        .sidebar { width: 240px; background: #1A1A2E; color: #fff; padding: 20px; flex-shrink: 0; }
        .sidebar-brand { font-size: 20px; font-weight: 700; margin-bottom: 30px; }
        .sidebar-nav a { display: block; padding: 10px 12px; color: rgba(255,255,255,0.7); text-decoration: none; border-radius: 8px; margin-bottom: 4px; transition: 0.2s; }
        .sidebar-nav a:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .sidebar-nav .logout { color: #E53935; margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 16px; }
        .hamburger { display: none; }
    </style>
</head>
<body>
<div class="app">
    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">📋 E-Form</div>
        <nav class="sidebar-nav">
            <a href="dashboard.php">📊 Dashboard</a>
            <?php if (hasRole('super_admin') || hasRole('admin')): ?>
            <a href="admin_users.php">👥 Manajemen User</a>
            <a href="forms.php">📝 Manajemen Form</a>
            <?php endif; ?>
            <a href="notifications.php">🔔 Notifikasi</a>
            <a href="profile.php">⚙️ Profile</a>
            <a href="logout.php" class="logout">🚪 Logout</a>
        </nav>
    </aside>
    
    <!-- MAIN -->
    <main class="main">
        <button class="hamburger" onclick="document.getElementById('sidebar').classList.toggle('open')" style="margin-bottom:12px;">☰</button>
        
        <div class="container">
            <!-- TOPBAR -->
            <div class="topbar">
                <h2>📋 Verifikasi Submission User</h2>
                <span class="user-badge">
                    👤 <?= htmlspecialchars($_SESSION['fullname']) ?>
                    <span class="role-badge"><?= $_SESSION['role'] ?></span>
                </span>
            </div>
            
            <!-- STATS -->
            <div class="stats">
                <div class="stat-card total">
                    <div class="num"><?= $totalUsers ?></div>
                    <div class="label">👥 Total User</div>
                </div>
                <div class="stat-card downloaded">
                    <div class="num"><?= $downloadedUsers ?></div>
                    <div class="label">✅ Progress</div>
                </div>
                <div class="stat-card submitted">
                    <div class="num"><?= $pendingCount ?></div>
                    <div class="label">📤 Menunggu Verifikasi</div>
                </div>
                <div class="stat-card pending">
                    <div class="num"><?= $pendingUsers ?></div>
                    <div class="label">⏳ Belum Download</div>
                </div>
            </div>
            
            <!-- SUBMISSION LIST -->
            <div class="card">
                <div class="card-header">
                    📋 Daftar Submission User
                    <span style="font-size:12px;font-weight:400;color:#6B7A99;margin-left:10px;">
                        (<?= count($submissions) ?> submission)
                    </span>
                </div>
                <div class="card-body">
                    <?php if (empty($submissions)): ?>
                    <div class="empty-state">
                        <div class="icon">📭</div>
                        <p>Belum ada submission yang dikirim</p>
                        <small>User akan muncul setelah mereka mengirim file PDF</small>
                    </div>
                    <?php else: ?>
                    
                    <?php foreach ($submissions as $s): 
                        $statusLabel = [
                            'submitted' => '📤 submitted',
                            'approved' => '✅ Disetujui',
                            'rejected' => '❌ Ditolak'
                        ][$s['status']] ?? $s['status'];
                    ?>
                    <div class="submission-card" data-user-id="<?= $s['user_id'] ?>">
                        <!-- Header: Nama User + Status -->
                        <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;align-items:flex-start;">
                            <div>
                                <strong style="font-size:14px;">
                                    <?= htmlspecialchars($s['fullname'] ?? $s['username']) ?>
                                </strong>
                                <span style="color:#6B7A99;font-size:13px;margin-left:8px;">
                                    <?= $s['icon'] ?> <?= htmlspecialchars($s['form_name']) ?>
                                </span>
                            </div>
                            <span class="status-badge <?= $s['status'] ?>"><?= $statusLabel ?></span>
                        </div>
                        
                        <!-- Info Tanggal -->
                        <div style="font-size:12px;color:#6B7A99;margin:6px 0;">
                            📅 Update: <?= date('d/m/Y H:i', strtotime($s['updated_at'])) ?>
                            <?php if ($s['submitted_at']): ?>
                            | 📤 Kirim: <?= date('d/m/Y H:i', strtotime($s['submitted_at'])) ?>
                            <?php endif; ?>
                            <?php if ($s['approved_at']): ?>
                            | ✅ Terima: <?= date('d/m/Y H:i', strtotime($s['approved_at'])) ?>
                            <?php endif; ?>
                            <?php if ($s['rejected_at']): ?>
                            | ❌ Tolak: <?= date('d/m/Y H:i', strtotime($s['rejected_at'])) ?>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Admin Note (kalau ditolak) -->
                        <?php if ($s['status'] === 'rejected' && $s['admin_note']): ?>
                        <div class="admin-note">
                            <strong>📝 Catatan Perbaikan:</strong><br>
                            <?= nl2br(htmlspecialchars($s['admin_note'])) ?>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Aksi -->
                        <div class="action-buttons">
                            <?php if ($s['status'] === 'submitted'): ?>
                                <?php if ($s['pdf_path']): ?>
                                <a href="<?= htmlspecialchars($s['pdf_path']) ?>" target="_blank" class="btn btn-primary btn-sm">
                                    📄 Lihat PDF
                                </a>
                                <?php endif; ?>
                                <button class="btn btn-success btn-sm" onclick="approveForm(<?= $s['id'] ?>)">
                                    ✅ Terima
                                </button>
                                <button class="btn btn-danger btn-sm" onclick="rejectForm(<?= $s['id'] ?>)">
                                    ❌ Tolak
                                </button>
                                
                            <?php elseif ($s['status'] === 'approved'): ?>
                                <span style="color:#1A7A45;font-weight:600;font-size:12px;">
                                    ✅ Telah Disetujui
                                </span>
                                
                            <?php elseif ($s['status'] === 'rejected'): ?>
                                <span style="color:#C62828;font-weight:600;font-size:12px;">
                                    ❌ Ditolak
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
</div>

<script>
// ============================================================
// TOGGLE SIDEBAR
// ============================================================
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

// ============================================================
// APPROVE FORM
// ============================================================
function approveForm(id) {
    if (!confirm('✅ Setujui submission ini?')) return;
    
    // Disable button sementara
    var btn = event.target;
    btn.disabled = true;
    btn.textContent = '⏳ Memproses...';
    
    fetch('api/approve_form.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ submission_id: id })
    })
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if (data.success) {
            alert('✅ ' + data.message);
            location.reload();
        } else {
            alert('❌ ' + data.message);
            btn.disabled = false;
            btn.textContent = '✅ Terima';
        }
    })
    .catch(function(err) {
        alert('❌ Terjadi kesalahan: ' + err.message);
        btn.disabled = false;
        btn.textContent = '✅ Terima';
    });
}

// ============================================================
// REJECT FORM
// ============================================================
function rejectForm(id) {
    var note = prompt('📝 Masukkan catatan perbaikan (wajib diisi):');
    
    // User klik cancel
    if (note === null) return;
    
    // User tidak isi catatan
    if (note.trim() === '') {
        alert('⚠️ Catatan perbaikan wajib diisi!');
        return;
    }
    
    // Konfirmasi
    if (!confirm('❌ Tolak submission ini?\n\nCatatan: ' + note)) return;
    
    // Disable button sementara
    var btn = event.target;
    btn.disabled = true;
    btn.textContent = '⏳ Memproses...';
    
    fetch('api/reject_form.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            submission_id: id, 
            admin_note: note.trim() 
        })
    })
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if (data.success) {
            alert('✅ ' + data.message);
            location.reload();
        } else {
            alert('❌ ' + data.message);
            btn.disabled = false;
            btn.textContent = '❌ Tolak';
        }
    })
    .catch(function(err) {
        alert('❌ Terjadi kesalahan: ' + err.message);
        btn.disabled = false;
        btn.textContent = '❌ Tolak';
    });
}
</script>
</body>
</html>