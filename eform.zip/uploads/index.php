<?php header('Location: /'); ?>
