<?php
require_once 'config/database.php';
require_once 'config/auth.php';

if (!hasRole('super_admin') && !hasRole('admin')) {
    header('Location: dashboard');
    exit;
}

$message = '';
$messageType = '';

if (isset($_GET['delete']) && hasRole('super_admin')) {
    $id = (int)$_GET['delete'];
    if ($id != $_SESSION['user_id']) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role != 'super_admin'");
        $stmt->execute([$id]);
        logAction($_SESSION['user_id'], "Delete user ID: $id");
        $message = 'User berhasil dihapus!';
        $messageType = 'success';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $username = trim($_POST['username'] ?? '');
    $fullname = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? 'user';
    $password = $_POST['password'] ?? '';
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $form_access = $_POST['form_access'] ?? [];
    
    // Hanya Super Admin yang bisa membuat Super Admin atau Admin
    if (!hasRole('super_admin')) {
        if ($role === 'super_admin' || $role === 'admin') {
            $role = 'user';
        }
    }
     // Ambil instansi dari form input (bisa diubah Super Admin)
    $instansiAdmin = trim($_POST['instansi'] ?? '');
    if (empty($instansiAdmin)) {
        // Jika kosong, ambil dari user yang login (fallback)
        $stmtInstansi = $pdo->prepare("SELECT instansi FROM users WHERE id = ?");
        $stmtInstansi->execute([$_SESSION['user_id']]);
        $currentUser = $stmtInstansi->fetch(PDO::FETCH_ASSOC);
        $instansiAdmin = $currentUser['instansi'] ?? '';
    }
    // Ambil divisi dari form input
    $divisi = trim($_POST['divisi'] ?? '');
    
    if ($id > 0) {
        // UPDATE - tambah divisi
        $sql = "UPDATE users SET fullname = ?, email = ?, role = ?, is_active = ?, instansi = ?, divisi = ? WHERE id = ?";
        $params = [$fullname, $email, $role, $is_active, $instansiAdmin, $divisi, $id];
        
        if (!empty($password)) {
            $sql = "UPDATE users SET fullname = ?, email = ?, password = ?, role = ?, is_active = ?, instansi = ?, divisi = ? WHERE id = ?";
            $params = [$fullname, $email, password_hash($password, PASSWORD_DEFAULT), $role, $is_active, $instansiAdmin, $divisi, $id];
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        // Jika user yang diedit adalah admin, update instansi user yang dibuatnya
        if ($role === 'admin') {
            $stmt = $pdo->prepare("UPDATE users SET instansi = ? WHERE created_by = ?");
            $stmt->execute([$instansiAdmin, $id]);
        }
        
        logAction($_SESSION['user_id'], "Update user ID: $id");
        $message = 'User berhasil diupdate!';
        $messageType = 'success';
    } else {
        // INSERT - tambah divisi
        $created_by = $_SESSION["user_id"];
        $stmt = $pdo->prepare("INSERT INTO users (username, password, fullname, email, role, is_active, created_by, instansi, divisi) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT), $fullname, $email, $role, $is_active, $created_by, $instansiAdmin, $divisi]);
        $id = $pdo->lastInsertId();
        logAction($_SESSION['user_id'], "Add user: $username");
        $message = 'User berhasil ditambahkan!';
        $messageType = 'success';
    }
    
    // Simpan akses form
    if ($id > 0) {
        $stmt = $pdo->prepare("DELETE FROM user_form_access WHERE user_id = ?");
        $stmt->execute([$id]);
        foreach ($form_access as $form_id) {
            $stmt = $pdo->prepare("INSERT INTO user_form_access (user_id, form_id) VALUES (?, ?)");
            $stmt->execute([$id, $form_id]);
        }
        
        // Jika user adalah Admin, buatkan form kop otomatis (user_id = id admin)
        // Jika user adalah Admin, buatkan form kop otomatis (user_id = id admin)
        if ($role === 'admin') {
            $formKeys = ['form_a', 'form_sppd', 'form_st', 'form_f'];
            $formNames = ['Form A - Laporan Pengawasan', 'Form SPPD', 'Form Surat Tugas', 'Form F - Laporan Pencegahan'];
            for ($i = 0; $i < count($formKeys); $i++) {
                $stmt = $pdo->prepare("INSERT IGNORE INTO forms (form_key, form_name, user_id, is_active) VALUES (?, ?, ?, 1)");
                $stmt->execute([$formKeys[$i], $formNames[$i], $id]);
            }
        }
    }
}

// Tampilkan user sesuai role
$current_user_id = $_SESSION['user_id'];
$current_role = $_SESSION['role'] ?? 'user';

if ($current_role === 'super_admin') {
    // Super Admin lihat SEMUA user
    $stmt = $pdo->prepare("SELECT * FROM users ORDER BY role, username");
    $stmt->execute();
} else {
    // Admin lihat user yang dibuatnya (created_by = current_user_id) + dirinya sendiri
    $stmt = $pdo->prepare("SELECT * FROM users WHERE created_by = ? OR id = ? ORDER BY role, username");
    $stmt->execute([$current_user_id, $current_user_id]);
}
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ambil form untuk akses form
$stmt = $pdo->prepare("SELECT * FROM forms WHERE user_id IS NULL OR user_id = ? GROUP BY form_key ORDER BY form_name");
$stmt->execute([$current_user_id]);
$forms = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen User - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .user-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .user-table th { text-align: left; padding: 8px 10px; background: #F8F9FC; color: #6B7A99; font-weight: 700; font-size: 11px; text-transform: uppercase; border-bottom: 2px solid #DDE3F0; }
        .user-table td { padding: 8px 10px; border-bottom: 1px solid #EEF0F6; vertical-align: middle; }
        .role-badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
        .role-badge.super_admin { background: #FFD700; color: #1A1A2E; }
        .role-badge.admin { background: #2D5BE3; color: #fff; }
        .role-badge.user { background: #6B7A99; color: #fff; }
        .btn-sm { padding: 4px 12px; font-size: 11px; border-radius: 4px; border: none; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-warning { background: #F5A623; color: #fff; }
        .btn-warning:hover { background: #d4911a; }
        .btn-danger { background: #C62828; color: #fff; }
        .btn-danger:hover { background: #8E0000; }
        .btn-primary { background: #E53935; color: #fff; }
        .btn-primary:hover { background: #c62828; }
        .btn-secondary { background: #6B7A99; color: #fff; }
        .btn-secondary:hover { background: #5a6a89; }
        .form-group { margin-bottom: 12px; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 3px; color: #1A1A2E; font-size: 13px; }
        .form-group input, .form-group select { width: 100%; padding: 8px 12px; border: 1.5px solid #DDE3F0; border-radius: 6px; font-size: 14px; font-family: inherit; }
        .form-group input:focus, .form-group select:focus { border-color: #E53935; outline: none; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .form-check { display: flex; gap: 10px; flex-wrap: wrap; }
        .form-check label { display: flex; align-items: center; gap: 4px; font-size: 12px; font-weight: 400; cursor: pointer; }
        .form-check input[type="checkbox"] { width: 16px; height: 16px; cursor: pointer; }
        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.45); z-index: 9998; align-items: center; justify-content: center; }
        .modal-overlay.show { display: flex; }
        .modal-box { background: #fff; border-radius: 14px; padding: 24px; width: 100%; max-width: 550px; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
        .modal-box h3 { font-size: 16px; margin-bottom: 6px; color: #1A1A2E; }
        .modal-box .close-modal { float: right; background: none; border: none; font-size: 20px; cursor: pointer; color: #6B7A99; }
        .modal-box .close-modal:hover { color: #1A1A2E; }
        .alert { padding: 10px 14px; border-radius: 8px; margin-bottom: 14px; }
        .alert-success { background: #EEFAF4; color: #1A7A45; border: 1px solid #B6E8CF; }
        .btn-row { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px; }
        .req { color: #E53935; }
        .card-header-flex { display: flex; justify-content: space-between; align-items: center; padding: 14px 20px; border-bottom: 1px solid #DDE3F0; }
        .card-header-flex h3 { font-size: 15px; font-weight: 700; color: #1A1A2E; margin: 0; }
    </style>
</head>
<body>
<?php include "sidebar.php"; ?>
    <div class="app">

        <main class="main">
            <header class="topbar">
                <div class="topbar-left"><h2>👥 Manajemen User</h2></div>
                    <button class="hamburger" onclick="toggleSidebar()">☰</button>
                <div class="topbar-right">
                    <span class="user-badge">👤 <?= htmlspecialchars($_SESSION['fullname']) ?> <span class="role-badge <?= $_SESSION['role'] ?>"><?= strtoupper($_SESSION['role']) ?></span></span>
                </div>
            </header>

            <?php if ($message): ?>
            <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header-flex">
                    <h3>📋 Daftar User</h3>
                    <button class="btn btn-primary btn-sm" onclick="openModal()">+ Tambah User</button>
                </div>
                <div class="card-body">
                    <table class="user-table">
                        <thead>
                            <tr><th>Username</th><th>Nama</th><th>Email</th><th>Instansi</th><th>Divisi / Jabatan</th><th>Role</th><th>Status</th><th>Aksi</th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($users as $u): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($u['username']) ?></strong></td>
                            <td><?= htmlspecialchars($u['fullname']) ?></td>
                            <td><?= htmlspecialchars($u['email']) ?></td>
                            <td><?= htmlspecialchars($u['instansi'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($u['divisi'] ?? '-') ?></td>     <!-- BARU -->
                            <td><span class="role-badge <?= $u['role'] ?>"><?= strtoupper(str_replace('_', ' ', $u['role'])) ?></span></td>
                            <td><?= $u['is_active'] ? '✅ Aktif' : '⛔ Nonaktif' ?></td>
                            <td>
                                <button class="btn btn-sm btn-warning" onclick="editUser(<?= $u['id'] ?>)">✏️ Edit</button>
                                <?php if (hasRole('super_admin') && $u['id'] != $_SESSION['user_id'] && $u['role'] != 'super_admin'): ?>
                                <a href="?delete=<?= $u['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus user ini?')">🗑 Hapus</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
    <!-- FOOTER -->
    <footer style="text-align:center;padding:20px 0 10px;border-top:1px solid #DDE3F0;margin-top:20px;font-size:11px;color:#6B7A99;">
        E-Form System v1.8 &copy; 2026 PT. Nura Kreasi Digital
    </footer>
        </main>
    </div>

    <div class="modal-overlay" id="userModal">
        <div class="modal-box">
            <button class="close-modal" onclick="closeModal()">✕</button>
            <h3 id="modalTitle">Tambah User</h3>
            <form method="POST" id="userForm">
                <input type="hidden" name="id" id="userId" value="0">
                
                <div class="form-group">
                    <label>Username <span class="req">*</span></label>
                    <input type="text" name="username" id="username" placeholder="Username" required>
                </div>
                <div class="grid-2">
                    <div class="form-group">
                        <label>Password <span class="req" id="passReq">*</span></label>
                        <div style="display:flex;gap:6px;">
                            <input type="text" name="password" id="password" placeholder="Password" style="flex:1;font-family:monospace;">
                            <button type="button" class="btn btn-sm btn-secondary" onclick="generatePassword()" title="Generate Password" style="white-space:nowrap;">🎲 Generate</button>
                        </div>
                        <small style="color:#6B7A99;display:block;margin-top:4px;">
                            Klik <strong>🎲 Generate</strong> untuk buat password otomatis (10 karakter)
                        </small>
                    </div>
                    <div class="form-group">
                        <label>Role <span class="req">*</span></label>
                    <select name="role" id="role">
                        <?php if (hasRole('super_admin')): ?>
                        <option value="admin">Admin</option>
                        <option value="user" selected>User</option>
                        <?php else: ?>
                        <option value="user" selected>User</option>
                        <?php endif; ?>
                    </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Nama Lengkap <span class="req">*</span></label>
                    <input type="text" name="fullname" id="fullname" placeholder="Nama lengkap" required>
                </div>
                <div class="form-group">
                    <label>Email <span class="req">*</span></label>
                    <input type="email" name="email" id="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <label>Instansi</label>
                    <input type="text" name="instansi" id="instansi" placeholder="Nama Instansi / Kantor" <?= hasRole('super_admin') ? '' : 'readonly style="background:#f5f5f5;cursor:not-allowed;"' ?>>
                    <small style="color:#6B7A99;"><?= hasRole('super_admin') ? 'Super Admin dapat mengubah instansi' : 'Instansi otomatis mengikuti admin yang membuat' ?></small>
                </div>
                <div class="form-group">
                    <label>Divisi / Jabatan</label>
                    <input type="text" name="divisi" id="divisi" placeholder="Contoh: Divisi SDM, Staff Teknis, Ketua">
                    <small style="color:#6B7A99;">Isi divisi atau jabatan user (opsional)</small>
                </div>
                                <div class="form-group">
                    <label>Akses Form</label>
                    <div class="form-check" id="formAccessContainer">
                        <?php foreach ($forms as $f): ?>
                        <label>
                            <input type="checkbox" name="form_access[]" value="<?= $f['id'] ?>">
                            <?= $f['icon'] ?> <?= htmlspecialchars($f['form_name']) ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label style="display:flex;align-items:center;gap:8px;">
                        <input type="checkbox" name="is_active" value="1" checked> Aktif
                    </label>
                </div>
                <div class="btn-row">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Batal</button>
                    <button type="submit" class="btn btn-primary">💾 Simpan</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function openModal() {
        document.getElementById('modalTitle').textContent = 'Tambah User';
        document.getElementById('userId').value = 0;
        document.getElementById('username').value = '';
        document.getElementById('password').value = '';
        document.getElementById('password').type = 'password';  // ← TAMBAH
        document.getElementById('password').required = true;
        document.getElementById('passReq').textContent = '*';
        document.getElementById('passReq').textContent = '*';
        document.getElementById('fullname').value = '';
        document.getElementById('email').value = '';
        document.getElementById('role').value = 'user';
        document.getElementById('divisi').value = '';  // ← TAMBAH

        
        // Instansi otomatis dari session PHP
        <?php if (hasRole('super_admin')): ?>
        // Super Admin: instansi kosong, isi manual
        document.getElementById('instansi').value = '';
        document.getElementById('instansi').readOnly = false;
        <?php else: ?>
        // Admin: instansi otomatis dari session
        var instansi = '<?= htmlspecialchars($_SESSION['instansi'] ?? '') ?>';
        document.getElementById('instansi').value = instansi;
        document.getElementById('instansi').readOnly = true;
        <?php endif; ?>
        <?php if (!hasRole('super_admin')): ?>
        document.getElementById('instansi').readOnly = true;
        <?php endif; ?>
        document.querySelectorAll('#formAccessContainer input[type="checkbox"]').forEach(function(cb) { cb.checked = false; });
        document.querySelector('input[name="is_active"]').checked = true;
        document.getElementById('userModal').classList.add('show');
    }

    function editUser(id) {
        console.log('Edit user ID:', id);
        
        fetch('get_user_data.php?user_id=' + id)
            .then(function(response) {
                if (!response.ok) {
                    throw new Error('HTTP error ' + response.status);
                }
                return response.json();
            })
            .then(function(data) {
                console.log('Data received:', data);
                
                if (data && data.id) {
                    document.getElementById('modalTitle').textContent = 'Edit User';
                    document.getElementById('userId').value = data.id;
                    document.getElementById('username').value = data.username || '';
                    document.getElementById('fullname').value = data.fullname || '';
                    document.getElementById('email').value = data.email || '';
                    document.getElementById('role').value = data.role || 'user';
                    document.getElementById('divisi').value = data.divisi || '';  // ← TAMBAH
                    document.getElementById('password').value = '';
                    document.getElementById('password').type = 'password';  // ← TAMBAH
                    document.getElementById('password').required = false;
                    document.getElementById('passReq').textContent = '(kosongkan jika tidak diubah)';
                    document.querySelector('input[name="is_active"]').checked = data.is_active == 1;
                    
                    // Instansi readonly
                    <?php if (hasRole('super_admin')): ?>
                    // Super Admin: instansi kosong, isi manual
                    document.getElementById('instansi').value = '';
                    document.getElementById('instansi').readOnly = false;
                    <?php else: ?>
                    // Admin: instansi otomatis dari session
                    <?php if (hasRole('super_admin')): ?>
                    // Super Admin: ambil dari data user, bisa diedit
                    document.getElementById('instansi').value = data.instansi || '';
                    document.getElementById('instansi').readOnly = false;
                    <?php else: ?>
                    // Admin: instansi otomatis dari session (readonly)
                    var instansi = '<?= htmlspecialchars($_SESSION['instansi'] ?? '') ?>';
                    document.getElementById('instansi').value = instansi;
                    document.getElementById('instansi').readOnly = true;
                    <?php endif; ?>
                    document.getElementById('instansi').readOnly = true;
                    <?php endif; ?>
                    <?php if (!hasRole('super_admin')): ?>
                    document.getElementById('instansi').readOnly = true;
                    <?php endif; ?>
                    
                    // Reset form access
                    document.querySelectorAll('#formAccessContainer input[type="checkbox"]').forEach(function(cb) {
                        cb.checked = false;
                    });
                    
                    // Set form access
                    if (data.form_access && data.form_access.length > 0) {
                        data.form_access.forEach(function(formId) {
                            document.querySelectorAll('#formAccessContainer input[type="checkbox"]').forEach(function(cb) {
                                if (parseInt(cb.value) === formId) {
                                    cb.checked = true;
                                }
                            });
                        });
                    }
                    
                    document.getElementById('userModal').classList.add('show');
                } else {
                    alert('Gagal memuat data user: Data tidak valid');
                }
            })
            .catch(function(error) {
                console.error('Error:', error);
                alert('Gagal memuat data user: ' + error.message + '. Coba refresh halaman.');
            });
    }

    function closeModal() {
        document.getElementById('userModal').classList.remove('show');
    }

    document.querySelectorAll('.modal-overlay').forEach(function(el) {
        el.addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });
    });
    
// ============================================================
// GENERATE PASSWORD OTOMATIS
// ============================================================
function generatePassword() {
    // Karakter yang dipakai (alfabet + numerik)
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var length = 10;
    var password = '';
    
    // Generate random password
    var array = new Uint32Array(length);
    window.crypto.getRandomValues(array);
    
    for (var i = 0; i < length; i++) {
        password += chars[array[i] % chars.length];
    }
    
    // Isi ke input
    var passInput = document.getElementById('password');
    passInput.value = password;
    passInput.type = 'text';  // Supaya bisa lihat
    
    // Highlight input
    passInput.style.background = '#EEFAF4';
    setTimeout(function() {
        passInput.style.background = '';
    }, 1000);
    
    // Notifikasi
    showToast('🎲 Password berhasil di-generate!', 'success');
    
    // Auto copy ke clipboard
    try {
        passInput.select();
        document.execCommand('copy');
        showToast('📋 Password sudah dicopy ke clipboard!', 'info');
    } catch (e) {
        // Fallback kalau tidak support copy
        console.log('Copy gagal, tapi password sudah terisi');
    }
}

// ============================================================
// TOAST NOTIFICATION
// ============================================================
function showToast(msg, type) {
    var old = document.querySelector('.toast-message');
    if (old) old.remove();
    
    var toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        padding: 12px 24px;
        border-radius: 10px;
        font-weight: 600;
        z-index: 9999;
        box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        max-width: 90%;
        transition: opacity 0.3s;
        font-size: 14px;
        background: ${type === 'success' ? '#2E7D32' : type === 'error' ? '#C62828' : '#2D5BE3'};
        color: #fff;
    `;
    toast.textContent = msg;
    document.body.appendChild(toast);
    
    setTimeout(function() {
        toast.style.opacity = '0';
        setTimeout(function() { toast.remove(); }, 300);
    }, 3000);
}

// ============================================================
// RESET PASSWORD FIELD SAAT OPEN MODAL
// ============================================================
// Cari fungsi openModal() → tambahkan reset type
// SEBELUM: document.getElementById('password').value = '';
// SESUDAH: 
// document.getElementById('password').value = '';
// document.getElementById('password').type = 'password';  // ← TAMBAH
    </script>
<script src="assets/js/main.js"></script>
</body>
</html>