// ============================================
// ONESIGNAL WEB PUSH - REAL-TIME UI UPDATE
// ============================================

let oneSignalReady = false;
let oneSignalInstance = null;

// ============================================
// INIT ONESIGNAL
// ============================================
window.OneSignalDeferred = window.OneSignalDeferred || [];
OneSignalDeferred.push(async function(OneSignal) {
    oneSignalReady = true;
    oneSignalInstance = OneSignal;
    
    console.log('✅ OneSignal siap');
    
    // Cek status awal
    await refreshButtonState(OneSignal);
    
    // ============================================
    // DENGARKAN PERUBAHAN SUBSCRIPTION (REAL-TIME)
    // ============================================
    OneSignal.User.PushSubscription.addEventListener('change', async (event) => {
        console.log('🔄 Subscription change:', event);
        await refreshButtonState(OneSignal);
    });
    
    // Dengarkan perubahan permission juga
    OneSignal.Notifications.addEventListener('permissionChange', async (permission) => {
        console.log('🔄 Permission change:', permission);
        await refreshButtonState(OneSignal);
    });
});

// ============================================
// FUNGSI: Cek status & update tombol
// ============================================
async function refreshButtonState(OneSignal) {
    try {
        const permission = await OneSignal.Notifications.permission;
        const optedIn = await OneSignal.User.PushSubscription.optedIn;
        const id = await OneSignal.User.PushSubscription.id;
        
        console.log('📊 Status:', { permission, optedIn, id });
        
        updateNotifButton(permission, optedIn, id);
    } catch (err) {
        console.error('Refresh state error:', err);
    }
}

// ============================================
// FUNGSI: User klik tombol
// ============================================
async function subscribeToBrowserNotifications() {
    if (!oneSignalReady || !oneSignalInstance) {
        alert('Sistem notifikasi belum siap. Coba refresh halaman.');
        return;
    }
    
    const OneSignal = oneSignalInstance;
    const btn = document.getElementById('btnEnableNotif');
    
    // Disable tombol sementara
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '⏳ Memproses...';
    }
    
    try {
        // 1. Minta izin
        await OneSignal.Notifications.requestPermission();
        
        // 2. Tunggu state server settle (delay kecil)
        await new Promise(r => setTimeout(r, 800));
        
        // 3. Cek hasil
        const permission = await OneSignal.Notifications.permission;
        
        if (permission) {
            // 4. Opt-in
            await OneSignal.User.PushSubscription.optIn();
            
            // 5. Tunggu state benar-benar ter-update
            await new Promise(r => setTimeout(r, 800));
            
            // 6. Update UI real-time
            await refreshButtonState(OneSignal);
            
            // 7. Notif sukses
            showToast('✅ Notifikasi browser berhasil diaktifkan!');
        } else {
            showToast('❌ Izin notifikasi ditolak.');
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '🔔 Aktifkan Notif Browser';
            }
        }
    } catch (err) {
        console.error('OneSignal error:', err);
        showToast('⚠️ Gagal: ' + err.message);
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '🔔 Aktifkan Notif Browser';
        }
    }
}

// ============================================
// FUNGSI: Update tampilan tombol
// ============================================
function updateNotifButton(permission, optedIn, id) {
    const btn = document.getElementById('btnEnableNotif');
    const status = document.getElementById('notifStatus');
    if (!btn) return;
    
    const isActive = permission && optedIn && id;
    
    if (isActive) {
        btn.style.display = 'none';
        if (status) {
            status.style.display = 'inline-flex';
            status.innerHTML = '✅ Notifikasi Browser Aktif';
        }
    } else {
        btn.style.display = 'inline-flex';
        btn.disabled = false;
        btn.innerHTML = '🔔 Aktifkan Notif Browser';
        if (status) status.style.display = 'none';
    }
}

// ============================================
// TOAST NOTIFIKASI
// ============================================
function showToast(msg) {
    let toast = document.getElementById('onesignal-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'onesignal-toast';
        toast.style.cssText = `
            position: fixed; bottom: 90px; left: 50%; transform: translateX(-50%);
            background: #1A1A2E; color: #fff; padding: 12px 20px; border-radius: 8px;
            font-size: 13px; z-index: 9999; box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            opacity: 0; transition: opacity 0.3s; max-width: 90%;
        `;
        document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = '1';
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => { toast.style.opacity = '0'; }, 3000);
}