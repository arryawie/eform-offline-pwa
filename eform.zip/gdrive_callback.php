<?php
// ============================================================
// GOOGLE DRIVE CALLBACK
// ============================================================
require_once 'config/database.php';
require_once 'config/auth.php';
requireAdmin();

if ($_SESSION['role'] !== 'super_admin') {
    die('Akses Ditolak');
}

$user_id = $_SESSION['user_id'];

// Cek code
if (!isset($_GET['code'])) {
    header('Location: gdrive_connect.php?error=' . urlencode('Authorization code tidak diterima'));
    exit;
}

// Load vendor
require_once 'vendor/autoload.php';

try {
    $credentialsPath = '/www/credentials/gdrive_credentials.json';
    // ============================================================
    // 1. SETUP CLIENT
    // ============================================================
    $client = new Google\Client();
    $client->setAuthConfig($credentialsPath);
    $client->addScope(Google\Service\Drive::DRIVE_FILE);
    $client->setAccessType('offline');
    $client->setRedirectUri('https://eform.nurakreasidigital.my.id/gdrive_callback.php');
    
    // ============================================================
    // 2. TUKAR CODE JADI TOKEN
    // ============================================================
    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
    
    if (isset($token['error'])) {
        throw new Exception('Token error: ' . ($token['error_description'] ?? $token['error']));
    }
    
    if (!isset($token['access_token'])) {
        throw new Exception('Access token tidak diterima dari Google');
    }
    
    $refreshToken = $token['refresh_token'] ?? null;
    
    if (!$refreshToken) {
        throw new Exception('Refresh token kosong. Hapus akses di https://myaccount.google.com/permissions lalu coba lagi.');
    }
    
    // ============================================================
    // 3. SET ACCESS TOKEN KE CLIENT (PENTING!)
    // ============================================================
    $client->setAccessToken($token);
    
    // ============================================================
    // 4. AMBIL EMAIL USER
    // ============================================================
    $gdriveEmail = '';
    try {
        $oauth2 = new Google\Service\Oauth2($client);
        $userInfo = $oauth2->userinfo->get();
        $gdriveEmail = $userInfo->email ?? '';
    } catch (Exception $e) {
        // Kalau gagal ambil email, lanjut aja
        $gdriveEmail = 'unknown';
    }
    
    // ============================================================
    // 5. BUAT FOLDER DI GOOGLE DRIVE
    // ============================================================
    $driveService = new Google\Service\Drive($client);
    
    $folderName = 'E-Form Backup';
    $query = "name='" . $folderName . "' and mimeType='application/vnd.google-apps.folder' and trashed=false";
    
    $results = $driveService->files->listFiles([
        'q' => $query,
        'fields' => 'files(id, name, webViewLink)',
        'spaces' => 'drive'
    ]);
    
    if (count($results->files) > 0) {
        $folderId = $results->files[0]->id;
        $folderLink = $results->files[0]->webViewLink;
    } else {
        $folderMetadata = new Google\Service\Drive\DriveFile([
            'name' => $folderName,
            'mimeType' => 'application/vnd.google-apps.folder'
        ]);
        
        $folder = $driveService->files->create($folderMetadata, [
            'fields' => 'id, webViewLink'
        ]);
        
        $folderId = $folder->id;
        $folderLink = $folder->webViewLink;
    }
    
    // ============================================================
    // 6. SIMPAN KE DATABASE
    // ============================================================
    $stmt = $pdo->prepare("
        UPDATE users 
        SET 
            gdrive_refresh_token = ?,
            gdrive_folder_id = ?,
            gdrive_enabled = 1,
            gdrive_connected_at = NOW(),
            gdrive_email = ?,
            gdrive_folder_link = ?,
            gdrive_folder_name = ?
        WHERE id = ?
    ");
    $stmt->execute([
        $refreshToken,
        $folderId,
        $gdriveEmail,
        $folderLink,
        $folderName,
        $user_id
    ]);
    
    header('Location: gdrive_connect.php?connected=1');
    exit;
    
} catch (Exception $e) {
    header('Location: gdrive_connect.php?error=' . urlencode($e->getMessage()));
    exit;
}
?>