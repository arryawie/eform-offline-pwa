<?php
require_once 'config/database.php';
require_once 'config/auth.php';
$page_title = 'Kebijakan Privasi';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .legal-container { max-width: 800px; margin: 40px auto; padding: 30px; background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .legal-container h1 { color: #1A1A2E; border-bottom: 2px solid #E53935; padding-bottom: 12px; }
        .legal-container h2 { color: #2D5BE3; margin-top: 24px; font-size: 16px; }
        .legal-container p, .legal-container li { color: #333; line-height: 1.8; font-size: 14px; }
        .legal-container ul { padding-left: 20px; }
        .last-updated { color: #6B7A99; font-size: 12px; margin-top: 30px; border-top: 1px solid #DDE3F0; padding-top: 16px; }
        .btn-back { display: inline-block; padding: 8px 20px; background: #E53935; color: #fff; border-radius: 6px; text-decoration: none; margin-bottom: 16px; }
        .btn-back:hover { background: #c62828; }
    </style>
</head>
<body>
    <?php include "sidebar.php"; ?>
    <div class="app">
        <main class="main">
            <div class="legal-container">
                <a href="dashboard.php" class="btn-back">← Kembali</a>
                <h1>🔒 Kebijakan Privasi</h1>
                <p class="last-updated">Terakhir diperbarui: <?= date('d F Y') ?></p>

                <h2>1. Informasi yang Dikumpulkan</h2>
                <ul>
                    <li>Data pribadi: Nama, email, username, jabatan.</li>
                    <li>Data aktivitas: Riwayat login, submission, notifikasi.</li>
                </ul>

                <h2>2. Penggunaan Data</h2>
                <ul>
                    <li>Untuk operasional sistem.</li>
                    <li>Untuk notifikasi dan komunikasi.</li>
                    <li>Untuk pelaporan dan audit.</li>
                </ul>

                <h2>3. Perlindungan Data</h2>
                <ul>
                    <li>Data disimpan dalam database terenkripsi.</li>
                    <li>Akses data terbatas berdasarkan role pengguna.</li>
                </ul>

                <h2>4. Hak Pengguna</h2>
                <ul>
                    <li>Mengakses dan mengubah data pribadi.</li>
                    <li>Menghapus akun (dengan persetujuan admin).</li>
                </ul>

                <h2>5. Kontak</h2>
                <p>Jika ada pertanyaan tentang privasi, hubungi <a href="mailto:<?= MAIL_ADMIN_EMAIL ?? 'admin@nurakreasi.co.id' ?>"><?= MAIL_ADMIN_EMAIL ?? 'admin@nurakreasi.co.id' ?></a></p>

                <div class="last-updated">© <?= date('Y') ?> <?= APP_NAME ?> - PT. Nura Kreasi Digital</div>
            </div>
        </main>
    </div>
</body>
</html>
