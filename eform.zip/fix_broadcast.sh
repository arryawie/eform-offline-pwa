#!/bin/bash

# 1. Filter user berdasarkan role (sama seperti notifikasi)
sed -i '/$users = $pdo->query("SELECT id, username, fullname, email, role FROM users WHERE is_active = 1 ORDER BY role, username")->fetchAll(PDO::FETCH_ASSOC);/c\
// Filter user berdasarkan role yang login\
$current_user_id = $_SESSION["user_id"];\
$current_role = $_SESSION["role"] ?? "user";\
\
if ($current_role === "super_admin") {\
    $users = $pdo->query("SELECT id, username, fullname, email, role FROM users WHERE is_active = 1 ORDER BY role, username")->fetchAll(PDO::FETCH_ASSOC);\
} else {\
    $stmt = $pdo->prepare("SELECT id, username, fullname, email, role FROM users WHERE (created_by = ? OR id = ?) AND is_active = 1 ORDER BY role, username");\
    $stmt->execute([$current_user_id, $current_user_id]);\
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);\
}' broadcast.php

# 2. Filter target penerima
sed -i '/if ($target === "all") {/,/}/c\
        if ($current_role === "super_admin") {\
            if ($target === "all") {\
                $targetUsers = $users;\
            } elseif ($target === "admin") {\
                $targetUsers = array_filter($users, function($u) {\
                    return in_array($u["role"], ["super_admin", "admin"]);\
                });\
            } elseif ($target === "user") {\
                $targetUsers = array_filter($users, function($u) {\
                    return $u["role"] === "user";\
                });\
            }\
        } else {\
            $targetUsers = $users;\
        }' broadcast.php

# 3. Update dropdown target (sama seperti notifikasi)
sed -i '/<select name="target" id="targetSelect"/,/<\/select>/c\
                                <select name="target" id="targetSelect" onchange="toggleUserList()" style="width:100%;padding:8px 12px;border:1.5px solid #DDE3F0;border-radius:8px;font-size:14px;">\
                                    <?php if (hasRole("super_admin")): ?>\
                                    <option value="all">📬 Semua User</option>\
                                    <option value="admin">👑 Admin & Super Admin</option>\
                                    <option value="user">👤 User Biasa</option>\
                                    <?php endif; ?>\
                                    <option value="all">📬 Semua User (User Saya)</option>\
                                    <option value="selected">📋 Pilih Manual</option>\
                                </select>' broadcast.php

echo "✅ broadcast.php sudah diperbaiki!"
