<?php
// ============================================================
// GOOGLE DRIVE OAUTH - REDIRECT KE GOOGLE LOGIN
// ============================================================
require_once 'config/database.php';
require_once 'config/auth.php';
requireAdmin();

if ($_SESSION['role'] !== 'super_admin') {
    die('Akses Ditolak');
}

require_once 'vendor/autoload.php';

// ============================================================
// KONFIGURASI GOOGLE CLIENT
// ============================================================
$credentialsPath = '/www/credentials/gdrive_credentials.json';

if (!file_exists($credentialsPath)) {
    header('Location: gdrive_connect.php?error=' . urlencode('File credentials tidak ditemukan. Hubungi developer.'));
    exit;
}

$client = new Google\Client();
$client->setAuthConfig($credentialsPath);
$client->addScope(Google\Service\Drive::DRIVE_FILE);
$client->setAccessType('offline');
$client->setPrompt('consent');

// Redirect URI (sesuaikan domain Anda)
$redirectUri = 'https://' . $_SERVER['HTTP_HOST'] . '/gdrive_callback.php';
$client->setRedirectUri($redirectUri);

// Generate auth URL
$authUrl = $client->createAuthUrl();

// Redirect ke Google
header('Location: ' . $authUrl);
exit;
?>