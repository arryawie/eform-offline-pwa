<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

// ============================================
// TANDAI 1 NOTIFIKASI SUDAH DIBACA
// ============================================
if (isset($_GET['read']) && isset($_GET['id'])) {
    $id = (int)$_GET['read'];
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
    $stmt->execute([$id, $_SESSION['user_id']]);
    header('Location: notifications.php');
    exit;
}

// ============================================
// TANDAI SEMUA SUDAH DIBACA
// ============================================
if (isset($_GET['read_all'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    logAction($_SESSION['user_id'], "Mark all notifications as read");
    header('Location: notifications.php');
    exit;
}

// ============================================
// HAPUS SEMUA NOTIFIKASI MILIK SENDIRI
// ============================================
if (isset($_GET['clear_all'])) {
    $stmt = $pdo->prepare("DELETE FROM notifications WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    logAction($_SESSION['user_id'], "Clear all notifications");
    header('Location: notifications.php?cleared=1');
    exit;
}

// ============================================
// HAPUS 1 NOTIFIKASI MILIK SENDIRI
// ============================================
if (isset($_GET['delete']) && isset($_GET['id'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?");
    $stmt->execute([$id, $_SESSION['user_id']]);
    logAction($_SESSION['user_id'], "Delete notification ID: $id");
    header('Location: notifications.php');
    exit;
}

// ============================================
// AMBIL SEMUA NOTIFIKASI USER
// ============================================
$notifications = $pdo->prepare("
    SELECT n.*, u.fullname as sender_name 
    FROM notifications n 
    LEFT JOIN users u ON n.sender_id = u.id 
    WHERE n.user_id = ? 
    ORDER BY n.created_at DESC 
    LIMIT 50
");
$notifications->execute([$_SESSION['user_id']]);
$notifList = $notifications->fetchAll(PDO::FETCH_ASSOC);

// Hitung belum dibaca
$unreadCount = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
$unreadCount->execute([$_SESSION['user_id']]);
$unreadTotal = $unreadCount->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifikasi - <?= APP_NAME ?></title>
    
    <!-- ============================================
         ONESIGNAL WEB PUSH SDK — WAJIB DI <head>
         ============================================ -->
    <script src="https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js" defer></script>
    <script>
      window.OneSignalDeferred = window.OneSignalDeferred || [];
      OneSignalDeferred.push(async function(OneSignal) {
        await OneSignal.init({
          appId: "01cb3e1a-38ba-4514-8643-8782e78463a1",
          allowLocalhostAsSecureOrigin: true,
          notifyButton: { enable: false }
        });
      });
    </script>
    <!-- ============================================ -->
    
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .notif-container { max-width: 700px; margin: 0 auto; }

        /* ===== HEADER BARU: 3 BARIS ===== */
        .notif-topbar {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 20px;
            padding-bottom: 14px;
            border-bottom: 1px solid #DDE3F0;
        }

        /* Baris 1: Judul + badge baru */
        .notif-topbar .row-title {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .notif-topbar .row-title h2 {
            font-size: 20px;
            color: #1A1A2E;
            margin: 0;
        }
        .notif-topbar .badge-count {
            background: #E53935;
            color: #fff;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }

        /* Baris 2: User badge */
        .notif-topbar .row-user {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: #1A1A2E;
        }

        /* Baris 3: Tombol aksi */
        .notif-topbar .row-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        /* ===== ITEM NOTIFIKASI ===== */
        .notif-item {
            background: #fff;
            border: 1px solid #DDE3F0;
            border-radius: 10px;
            padding: 14px 18px;
            margin-bottom: 10px;
            transition: 0.2s;
            display: flex;
            gap: 12px;
            align-items: flex-start;
        }
        .notif-item:hover { border-color: #C0C8E0; }
        .notif-item.unread {
            background: #EEF4FF;
            border-left: 4px solid #2D5BE3;
        }
        .notif-item .icon { font-size: 24px; flex-shrink: 0; }
        .notif-item .content { flex: 1; min-width: 0; }
        .notif-item .content .title { font-weight: 700; font-size: 14px; color: #1A1A2E; }
        .notif-item .content .message { font-size: 13px; color: #333; margin: 4px 0; word-wrap: break-word; }
        .notif-item .content .time { font-size: 11px; color: #6B7A99; }
        .notif-item .content .link { display: inline-block; margin-top: 6px; font-size: 12px; color: #2D5BE3; text-decoration: none; }
        .notif-item .content .link:hover { text-decoration: underline; }

        /* Aksi di dalam notif */
        .notif-item .notif-actions {
            display: flex;
            flex-direction: column;
            gap: 4px;
            align-items: center;
            flex-shrink: 0;
        }
        .notif-item .read-btn,
        .notif-item .delete-btn {
            font-size: 14px;
            text-decoration: none;
            padding: 4px 8px;
            border-radius: 6px;
            transition: 0.2s;
            opacity: 0.6;
        }
        .notif-item .read-btn:hover { background: #EEFAF4; opacity: 1; }
        .notif-item .delete-btn:hover { background: #FFE5E5; opacity: 1; }

        /* ===== TOMBOL ===== */
        .btn-sm {
            padding: 6px 14px;
            font-size: 12px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-weight: 700;
            transition: 0.2s;
        }
        .btn-primary { background: #2D5BE3; color: #fff; }
        .btn-primary:hover { background: #1A46C4; }
        .btn-secondary { background: #6B7A99; color: #fff; }
        .btn-secondary:hover { background: #5a6a89; }
        .btn-danger { background: #E53935; color: #fff; }
        .btn-danger:hover { background: #c62828; }

        /* Status aktif */
        #notifStatus {
            font-size: 11px;
            font-weight: 600;
            padding: 6px 12px;
            border-radius: 8px;
        }

        /* ===== EMPTY STATE ===== */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #6B7A99;
        }
        .empty-state .icon { font-size: 48px; margin-bottom: 10px; }

        /* ===== ALERT ===== */
        .alert-cleared {
            background: #EEFAF4;
            color: #1A7A45;
            border: 1px solid #B6E8CF;
            padding: 10px 14px;
            border-radius: 8px;
            margin-bottom: 14px;
            font-size: 13px;
        }

        /* ===== MOBILE ===== */
        @media (max-width: 768px) {
            .notif-topbar .row-title h2 { font-size: 18px; }
            .notif-topbar .row-actions { width: 100%; }
            .notif-topbar .row-actions .btn-sm { flex: 1; justify-content: center; }
            .notif-item { padding: 12px 14px; gap: 10px; }
            .notif-item .icon { font-size: 20px; }
            .notif-item .content .title { font-size: 13px; }
            .notif-item .content .message { font-size: 12px; }
            .notif-item .delete-btn,
            .notif-item .read-btn { opacity: 1; }
        }
    </style>
</head>
<body>
<?php include "sidebar.php"; ?>
    <div class="app">

        <main class="main">
            <div class="notif-container">

                <!-- ============================================
                     HEADER — URUTAN: NOTIF → USER → AKSI
                     ============================================ -->
                <div class="notif-topbar">
                    <!-- Baris 1: Judul + badge -->
                    <div class="row-title">
                        <h2>🔔 Notifikasi</h2>
                        <?php if ($unreadTotal > 0): ?>
                        <span class="badge-count"><?= $unreadTotal ?> baru</span>
                        <?php endif; ?>
                    </div>

                    <!-- Baris 2: User badge -->
                    <div class="row-user">
                        <span class="user-badge">👤 <?= htmlspecialchars($_SESSION['fullname']) ?> <span class="role-badge"><?= $_SESSION['role'] ?></span></span>
                    </div>

                    <!-- Baris 3: Tombol aksi -->
                    <div class="row-actions">
                        <?php if ($unreadTotal > 0): ?>
                        <a href="?read_all=1" class="btn-sm btn-secondary" onclick="return confirm('Tandai semua notifikasi sudah dibaca?')">✅ Tandai semua</a>
                        <?php endif; ?>
                        <?php if (!empty($notifList)): ?>
                        <a href="?clear_all=1" class="btn-sm btn-danger" onclick="return confirm('⚠️ Hapus SEMUA notifikasi Anda?\n\nTindakan ini tidak bisa dibatalkan.\nNotifikasi user lain tidak akan terhapus.')">🗑️ Bersihkan</a>
                        <?php endif; ?>
                        
                        <!-- TOMBOL AKTIFKAN NOTIF BROWSER -->
                        <button type="button" id="btnEnableNotif" class="btn-sm btn-primary" onclick="subscribeToBrowserNotifications()">
                            🔔 Aktifkan Notif Browser
                        </button>
                        <span id="notifStatus" style="display:none; background:#EEFAF4; color:#1A7A45; border:1px solid #B6E8CF; cursor:default;"></span>
                    </div>
                </div>

                <!-- ============================================
                     ALERT SETELAH CLEAR
                     ============================================ -->
                <?php if (isset($_GET['cleared'])): ?>
                <div class="alert-cleared">✅ Semua notifikasi Anda berhasil dibersihkan.</div>
                <?php endif; ?>

                <!-- ============================================
                     LIST NOTIFIKASI
                     ============================================ -->
                <?php if (empty($notifList)): ?>
                <div class="empty-state">
                    <div class="icon">🔔</div>
                    <p>Belum ada notifikasi</p>
                    <span style="font-size:12px;">Notifikasi dari admin akan muncul di sini</span>
                </div>
                <?php else: ?>
                <?php foreach ($notifList as $n): 
                    $isUnread = $n['is_read'] == 0;
                    $typeIcon = [
                        'info' => 'ℹ️',
                        'success' => '✅',
                        'warning' => '⚠️',
                        'submitted' => '📤',
                        'approved' => '✅',
                        'rejected' => '❌'
                    ][$n['type']] ?? '📢';
                ?>
                <div class="notif-item <?= $isUnread ? 'unread' : '' ?>">
                    <div class="icon"><?= $typeIcon ?></div>
                    <div class="content">
                        <div class="title"><?= htmlspecialchars($n['title']) ?></div>
                        <div class="message"><?= nl2br(htmlspecialchars($n['message'])) ?></div>
                        <?php if (!empty($n['link'])): ?>
                        <a href="<?= htmlspecialchars($n['link']) ?>" class="link">🔗 Lihat Detail →</a>
                        <?php endif; ?>
                        <div class="time">
                            🕐 <?= date('d/m/Y H:i', strtotime($n['created_at'])) ?>
                            <?php if ($n['sender_name']): ?>
                            • Dari: <?= htmlspecialchars($n['sender_name']) ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="notif-actions">
                        <?php if ($isUnread): ?>
                        <a href="?read=<?= $n['id'] ?>" class="read-btn" title="Tandai dibaca">✅</a>
                        <?php endif; ?>
                        <a href="?delete=<?= $n['id'] ?>" class="delete-btn" title="Hapus" onclick="return confirm('Hapus notifikasi ini?')">🗑️</a>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>

            </div>
        </main>
    </div>

    <?php include 'bottom_nav.php'; ?>

    <footer style="text-align:center;padding:16px 0 8px;border-top:1px solid #DDE3F0;margin-top:20px;font-size:11px;color:#6B7A99;">
        E-Form System v1.8 &copy; 2026 PT. Nura Kreasi Digital
    </footer>

    <!-- Scripts -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/onesignal-init.js"></script>
    
<script>
// ============================================
// AUTO-REFRESH NOTIFIKASI (POLLING)
// ============================================
(function() {
    // Nilai unread saat halaman dimuat (dari PHP)
    let currentUnread = <?= (int)$unreadTotal ?>;
    
    // Interval polling (30 detik)
    const POLL_INTERVAL = 30000;
    
    // Cek apakah tab sedang aktif
    function isTabActive() {
        return !document.hidden;
    }
    
    // Fungsi cek notif baru
    async function checkNewNotifications() {
        // Skip kalau tab tidak aktif (hemat resource)
        if (!isTabActive()) return;
        
        try {
            const res = await fetch('api_check_unread.php?t=' + Date.now(), {
                cache: 'no-store'
            });
            
            if (!res.ok) return;
            
            const data = await res.json();
            const serverUnread = parseInt(data.unread) || 0;
            
            // Kalau jumlah unread di server > yang kita tahu → ada notif baru
            if (serverUnread > currentUnread) {
                console.log('📬 Notif baru terdeteksi!', currentUnread, '→', serverUnread);
                
                // Tampilkan toast
                showNotifToast('📬 Anda punya ' + serverUnread + ' notifikasi baru!');
                
                // Reload setelah 1 detik (biar user lihat toast dulu)
                setTimeout(() => {
                    location.reload();
                }, 1000);
            } else if (serverUnread !== currentUnread) {
                // Unread berkurang (misal dari tab lain), update internal
                currentUnread = serverUnread;
            }
        } catch (err) {
            // Silent fail — jangan ganggu user kalau network error
            console.debug('Polling error:', err);
        }
    }
    
    // Toast sederhana
    function showNotifToast(msg) {
        const toast = document.createElement('div');
        toast.style.cssText = `
            position: fixed; top: 20px; left: 50%; transform: translateX(-50%);
            background: #2D5BE3; color: #fff; padding: 12px 22px; border-radius: 10px;
            font-size: 13px; font-weight: 600; z-index: 99999;
            box-shadow: 0 6px 20px rgba(45,91,227,0.4);
            animation: slideDown 0.3s ease;
        `;
        toast.textContent = msg;
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transition = 'opacity 0.3s';
            setTimeout(() => toast.remove(), 300);
        }, 2000);
    }
    
    // Jalankan polling
    setInterval(checkNewNotifications, POLL_INTERVAL);
    
    // Cek saat tab kembali aktif (user balik dari tab lain)
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            checkNewNotifications();
        }
    });
    
    console.log('🔄 Auto-refresh notifikasi aktif (interval ' + (POLL_INTERVAL/1000) + ' detik)');
})();
</script>

<style>
@keyframes slideDown {
    from { opacity: 0; transform: translate(-50%, -20px); }
    to   { opacity: 1; transform: translate(-50%, 0); }
}
</style>
</body>
</html>