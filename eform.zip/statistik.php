<?php
// ============================================================
// STATISTIK - SUPER ADMIN
// ============================================================
require_once 'config/database.php';
require_once 'config/auth.php';
requireAdmin();

if ($_SESSION['role'] !== 'super_admin') {
    die('<h1>⛔ Akses Ditolak</h1><p>Hanya Super Admin</p>');
}

// ============================================================
// STATISTIK GLOBAL
// ============================================================
// Total user (exclude admin & super_admin)
$stmt = $pdo->query("
    SELECT COUNT(*) FROM users 
    WHERE role = 'user' 
      AND created_by IS NOT NULL
");
$totalUser = $stmt->fetchColumn();

// Total submission
$stmt = $pdo->query("SELECT COUNT(*) FROM form_submissions");
$totalSubmission = $stmt->fetchColumn();

// ============================================================
// STATISTIK PER INSTANSI
// ============================================================
$stmt = $pdo->query("
    SELECT 
        u.instansi,
        COUNT(DISTINCT u.id) as total_user,
        COUNT(DISTINCT CASE WHEN f.form_key = 'form_a' AND s.status IN ('submitted', 'approved') THEN u.id END) as user_kirim_form_a,
        COUNT(DISTINCT CASE WHEN f.form_key = 'form_sppd' AND s.status IN ('submitted', 'approved') THEN u.id END) as user_kirim_form_sppd
    FROM users u
    LEFT JOIN form_submissions s ON s.user_id = u.id
    LEFT JOIN forms f ON s.form_id = f.id
    WHERE u.role = 'user'
      AND u.created_by IS NOT NULL
      AND u.instansi IS NOT NULL
      AND u.instansi != ''
    GROUP BY u.instansi
    ORDER BY u.instansi ASC
");
$perInstansi = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalInstansi = count($perInstansi);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Statistik - Super Admin</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .container { max-width: 1100px; margin: 0 auto; padding: 20px; }
        
        .stats-top {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-bottom: 24px;
        }
        .stat-card {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }
        .stat-card .num { font-size: 32px; font-weight: 800; }
        .stat-card .label { font-size: 12px; color: #6B7A99; text-transform: uppercase; margin-top: 4px; }
        .stat-card.blue .num { color: #2D5BE3; }
        .stat-card.green .num { color: #1A7A45; }
        .stat-card.orange .num { color: #F5A623; }
        
        .card {
            background: #fff;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }
        .card h2 { margin: 0 0 16px; font-size: 16px; }
        
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th {
            background: #F8F9FC;
            padding: 12px;
            text-align: left;
            font-size: 11px;
            text-transform: uppercase;
            color: #6B7A99;
            border-bottom: 2px solid #DDE3F0;
            font-weight: 700;
        }
        td { padding: 12px; border-bottom: 1px solid #EEF0F6; }
        tr:hover { background: #FAFBFD; }
        
        .instansi-name { font-weight: 700; color: #1A1A2E; }
        
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
        }
        .status-badge.ok { background: #EEFAF4; color: #1A7A45; }
        .status-badge.partial { background: #FFFBEE; color: #B07A00; }
        .status-badge.none { background: #FFE5E5; color: #C62828; }
        
        .form-count .complete { color: #1A7A45; font-weight: 700; }
        .form-count .incomplete { color: #C62828; font-weight: 700; }
        
        .empty { text-align: center; padding: 40px; color: #6B7A99; }
        
        @media (max-width: 768px) {
            .stats-top { grid-template-columns: 1fr; }
            table { font-size: 12px; }
            th, td { padding: 8px; }
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="app">
    <main class="main">
        <div class="container">
            <h1>📈 Statistik</h1>
            <p style="color: #6B7A99; margin-bottom: 20px;">Ringkasan aktivitas per instansi</p>
            
            <!-- STATISTIK GLOBAL -->
            <div class="stats-top">
                <div class="stat-card blue">
                    <div class="num"><?= $totalInstansi ?></div>
                    <div class="label">🏢 Total Instansi</div>
                </div>
                <div class="stat-card green">
                    <div class="num"><?= $totalUser ?></div>
                    <div class="label">👥 Total User</div>
                </div>
                <div class="stat-card orange">
                    <div class="num"><?= $totalSubmission ?></div>
                    <div class="label">📋 Total Submission</div>
                </div>
            </div>
            
            <!-- TABEL PER INSTANSI -->
            <div class="card">
                <h2>🏢 Statistik Per Instansi</h2>
                
                <?php if (empty($perInstansi)): ?>
                <div class="empty">
                    <p>Belum ada data instansi</p>
                </div>
                <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Instansi</th>
                            <th style="text-align:center;">Form A</th>
                            <th style="text-align:center;">Form SPPD</th>
                            <th style="text-align:center;">Status</th>
                            <th style="text-align:center;">User</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($perInstansi as $row): 
                            $totalU = $row['total_user'];
                            $formA = $row['user_kirim_form_a'];
                            $formSppd = $row['user_kirim_form_sppd'];
                            
                            if ($totalU == 0) {
                                $status = 'none'; $statusLabel = '❌ Kosong';
                            } elseif ($formA == $totalU && $formSppd == $totalU) {
                                $status = 'ok'; $statusLabel = '✅ Lengkap';
                            } elseif ($formA == 0 && $formSppd == 0) {
                                $status = 'none'; $statusLabel = '❌ Belum Kirim';
                            } else {
                                $status = 'partial'; $statusLabel = '⏳ Sebagian';
                            }
                        ?>
                        <tr>
                            <td><span class="instansi-name"><?= htmlspecialchars($row['instansi']) ?></span></td>
                            <td style="text-align:center;" class="form-count">
                                <span class="<?= $formA == $totalU && $totalU > 0 ? 'complete' : 'incomplete' ?>">
                                    <?= $formA ?>/<?= $totalU ?>
                                </span>
                            </td>
                            <td style="text-align:center;" class="form-count">
                                <span class="<?= $formSppd == $totalU && $totalU > 0 ? 'complete' : 'incomplete' ?>">
                                    <?= $formSppd ?>/<?= $totalU ?>
                                </span>
                            </td>
                            <td style="text-align:center;">
                                <span class="status-badge <?= $status ?>"><?= $statusLabel ?></span>
                            </td>
                            <td style="text-align:center;"><strong><?= $totalU ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>
</body>
</html>