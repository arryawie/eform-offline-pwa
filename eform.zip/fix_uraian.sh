#!/bin/bash

# Cari dan hapus semua placeholder isian di bagian Uraian
sed -i '/q1_penjelasan/,/placeholder=/ s/placeholder="Penjelasan"/placeholder=""/g' form_a.php
sed -i '/q2_penjelasan/,/placeholder=/ s/placeholder="Penjelasan"/placeholder=""/g' form_a.php
sed -i '/q3_penjelasan/,/placeholder=/ s/placeholder="Penjelasan"/placeholder=""/g' form_a.php
sed -i '/q4_tanggal/,/placeholder=/ s/placeholder="Tanggal penyerahan"/placeholder=""/g' form_a.php
sed -i '/q4_pukul/,/placeholder=/ s/placeholder="Pukul"/placeholder=""/g' form_a.php
sed -i '/catatan_kejadian/,/placeholder=/ s/placeholder="Catatan kejadian khusus (jika ada)"/placeholder=""/g' form_a.php

echo "✅ Semua placeholder di bagian Uraian sudah dikosongkan!"
