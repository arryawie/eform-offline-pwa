<?php
// ============================================================
// LIST FILE YANG BELUM DI-SYNC KE GOOGLE DRIVE
// ============================================================
require_once '../config/database.php';
require_once '../config/auth.php';
requireAdmin();

header('Content-Type: application/json');

if ($_SESSION['role'] !== 'super_admin') {
    echo json_encode(['success' => false, 'message' => 'Hanya Super Admin']);
    exit;
}

// Cek apakah kolom gdrive_file_id ada
try {
    $stmt = $pdo->query("
        SELECT id, pdf_path, user_id
        FROM form_submissions 
        WHERE pdf_path IS NOT NULL 
          AND (gdrive_file_id IS NULL OR gdrive_file_id = '')
        ORDER BY id ASC
    ");
    $files = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $result = [];
    foreach ($files as $f) {
        // Cek file fisik ada atau tidak
        $fullPath = '../' . $f['pdf_path'];
        if (file_exists($fullPath)) {
            $result[] = [
                'submission_id' => $f['id'],
                'pdf_path' => $f['pdf_path'],
                'filename' => basename($f['pdf_path'])
            ];
        }
    }
    
    echo json_encode([
        'success' => true,
        'total' => count($result),
        'files' => $result
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>