<?php
// ============================================================
// API GET USER STATUS - AMBIL STATUS USER
// ============================================================
// Letakkan di: api/get_user_status.php
// ============================================================

require_once '../config/database.php';
require_once '../config/auth.php';

header('Content-Type: application/json');

// Cek login
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$form_key = $_GET['form_key'] ?? '';
$user_id = $_SESSION['user_id'];

if (!$form_key) {
    echo json_encode(['success' => false, 'message' => 'Form key required']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT s.id, s.status, s.updated_at, f.form_name
        FROM form_submissions s
        JOIN forms f ON s.form_id = f.id
        WHERE s.user_id = ? AND f.form_key = ?
        ORDER BY s.id DESC LIMIT 1
    ");
    $stmt->execute([$user_id, $form_key]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        echo json_encode([
            'success' => true,
            'submission_id' => $result['id'],
            'status' => $result['status'],
            'updated_at' => $result['updated_at']
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'status' => null,
            'message' => 'Belum ada submission'
        ]);
    }
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>