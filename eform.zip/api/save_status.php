<?php
// ============================================================
// API SAVE STATUS - SUPPORT SEMUA STATUS
// ============================================================
require_once '../config/database.php';
require_once '../config/auth.php';
header('Content-Type: application/json');
if (!isLoggedIn()) {
http_response_code(401);
echo json_encode(['success' => false, 'message' => 'Unauthorized']);
exit;
}
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
echo json_encode(['success' => false, 'message' => 'Invalid input']);
exit;
}
$form_key = $input['form_key'] ?? '';
$status = $input['status'] ?? 'draft';
$submission_id = isset($input['submission_id']) ? (int)$input['submission_id'] : 0;
$user_id = $_SESSION['user_id'];
if (!$form_key) {
echo json_encode(['success' => false, 'message' => 'Form key required']);
exit;
}
$stmt = $pdo->prepare("SELECT id FROM forms WHERE form_key = ?");
$stmt->execute([$form_key]);
$form = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$form) {
echo json_encode(['success' => false, 'message' => 'Form not found']);
exit;
}
// SUPPORT SEMUA STATUS: draft, downloaded, terkirim, approved, rejected
$allowed_status = ['draft', 'downloaded', 'terkirim', 'approved', 'rejected'];
if (!in_array($status, $allowed_status)) {
echo json_encode(['success' => false, 'message' => 'Invalid status']);
exit;
}
try {
if ($submission_id > 0) {
$stmt = $pdo->prepare("
SELECT id FROM form_submissions
WHERE id = ? AND user_id = ? AND form_id = ?
");
$stmt->execute([$submission_id, $user_id, $form['id']]);
$exists = $stmt->fetch(PDO::FETCH_ASSOC);
if ($exists) {
$stmt = $pdo->prepare("
UPDATE form_submissions
SET status = ?, updated_at = NOW()
WHERE id = ?
");
$stmt->execute([$status, $submission_id]);
echo json_encode([
'success' => true,
'submission_id' => $submission_id,
'status' => $status,
'message' => 'Status berhasil diupdate'
]);
exit;
}
}
// Insert baru
$stmt = $pdo->prepare("
INSERT INTO form_submissions
(user_id, form_id, status, created_at, updated_at)
VALUES (?, ?, ?, NOW(), NOW())
");
$stmt->execute([$user_id, $form['id'], $status]);
$new_submission_id = $pdo->lastInsertId();
echo json_encode([
'success' => true,
'submission_id' => $new_submission_id,
'status' => $status,
'message' => 'Submission baru berhasil dibuat'
]);
} catch (PDOException $e) {
echo json_encode([
'success' => false,
'message' => 'Database error: ' . $e->getMessage()
]);
}
?>