<?php
header('Content-Type: application/json');
require_once '/www/wwwroot/eform/config/database.php';
require_once '/www/wwwroot/eform/phpmailer/src/Exception.php';
require_once '/www/wwwroot/eform/phpmailer/src/PHPMailer.php';
require_once '/www/wwwroot/eform/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $userInput = isset($input['input']) ? trim($input['input']) : '';

    if (empty($userInput)) {
        echo json_encode(['success' => false, 'message' => 'Username atau email tidak boleh kosong.']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$userInput, $userInput]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User tidak ditemukan.']);
        exit;
    }

    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'nurakreasidigital@gmail.com';
    $mail->Password = 'wuzm vmek kmcq sgkt';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    $mail->setFrom('nurakreasidigital@gmail.com', 'E-Form System');
    $mail->addAddress('nurakreasidigital@gmail.com', 'Admin E-Form');
    $mail->isHTML(true);
    $mail->Subject = '🔑 Permintaan Reset Password';
    $mail->Body = "
    <h3>Permintaan Reset Password</h3>
    <p>User berikut meminta reset password:</p>
    <ul>
        <li><strong>Nama:</strong> {$user['fullname']}</li>
        <li><strong>Username:</strong> {$user['username']}</li>
        <li><strong>Email:</strong> {$user['email']}</li>
        <li><strong>IP:</strong> {$_SERVER['REMOTE_ADDR']}</li>
        <li><strong>Waktu:</strong> " . date('d/m/Y H:i:s') . "</li>
    </ul>
    <p>Silakan reset password user melalui <strong>Manajemen User</strong>.</p>
    ";

if ($mail->send()) {
    // Kirim notifikasi ke Super Admin + Admin pembuat user
    $title = 'Permintaan Reset Password';
    $message = 'User ' . $user['fullname'] . ' (' . $user['username'] . ') meminta reset password. Silakan hubungi user untuk verifikasi.';
    $link = 'admin_users.php';

    $stmt = $pdo->prepare("SELECT id FROM users WHERE role = 'super_admin' OR id = ?");
    $stmt->execute([$user['created_by']]);
    $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($admins as $admin) {
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, sender_id, title, message, type, link, is_read, created_at) VALUES (?, ?, ?, ?, 'info', ?, 0, NOW())");
        $stmt->execute([$admin['id'], $user['id'], $title, $message, $link]);
    }

    echo json_encode(['success' => true, 'message' => 'Permintaan reset password telah dikirim ke admin.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal mengirim email.']);
}

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
