<?php
// ============================================================
// API APPROVE FORM - ADMIN TERIMA SUBMISSION
// ============================================================
// Letakkan di: api/approve_form.php
// ============================================================
require_once '../config/database.php';
require_once '../config/auth.php';
requireAdmin();
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
echo json_encode(['success' => false, 'message' => 'Invalid input']);
exit;
}
$submission_id = isset($input['submission_id']) ? (int)$input['submission_id'] : 0;
$admin_id = $_SESSION['user_id'];
if ($submission_id === 0) {
echo json_encode(['success' => false, 'message' => 'Submission ID required']);
exit;
}
// Cek submission
$stmt = $pdo->prepare("
SELECT s.id, s.user_id, s.status, u.created_by
FROM form_submissions s
JOIN users u ON s.user_id = u.id
WHERE s.id = ?
");
$stmt->execute([$submission_id]);
$submission = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$submission) {
echo json_encode(['success' => false, 'message' => 'Submission not found']);
exit;
}
// Cek akses admin: hanya bisa akses user yang dibuatnya
if ($submission['created_by'] != $admin_id && $_SESSION['role'] !== 'super_admin') {
echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
exit;
}
// Cek status harus 'submitted'
if ($submission['status'] !== 'submitted') {
echo json_encode(['success' => false, 'message' => 'Status must be submitted']);
exit;
}
// Update status
$stmt = $pdo->prepare("
UPDATE form_submissions
SET status = 'approved', approved_at = NOW(), updated_at = NOW()
WHERE id = ?
");
$stmt->execute([$submission_id]);
echo json_encode([
'success' => true,
'message' => 'Form berhasil disetujui!',
'submission_id' => $submission_id,
'status' => 'approved'
]);

require_once 'notif.php';

$stmt = $pdo->prepare("SELECT user_id FROM form_submissions WHERE id = ?");
$stmt->execute([$submission_id]);
$sub = $stmt->fetch(PDO::FETCH_ASSOC);
$user_id = $sub['user_id'];

notifAdminApprove($user_id, $admin_id, $submission_id, 'Form SPPD');
?>