<?php
// ============================================================
// API NOTIF - KIRIM NOTIFIKASI KE USER/ADMIN
// ============================================================

require_once '../config/database.php';

function sendNotification($user_id, $title, $message, $type = 'info', $link = '', $sender_id = null) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO notifications 
                (user_id, sender_id, title, message, type, link, created_at, is_read) 
            VALUES (?, ?, ?, ?, ?, ?, NOW(), 0)
        ");
        $stmt->execute([$user_id, $sender_id, $title, $message, $type, $link]);
        return true;
    } catch (PDOException $e) {
        error_log('Notifikasi gagal: ' . $e->getMessage());
        return false;
    }
}

function notifToUser($user_id, $admin_id, $title, $message, $type = 'info', $link = '') {
    return sendNotification($user_id, $title, $message, $type, $link, $admin_id);
}

function notifToAdmin($admin_id, $user_id, $title, $message, $type = 'info', $link = '') {
    return sendNotification($admin_id, $title, $message, $type, $link, $user_id);
}

// ============================================================
// EVENT NOTIFIKASI
// ============================================================

// 1. User upload file → notif ke user & admin
function notifUserUpload($user_id, $admin_id, $submission_id, $form_name) {
    $title = '📤 File Berhasil Dikirim';
    $message = "File $form_name berhasil Anda kirim ke admin. Tunggu verifikasi.";
    $link = "form_sppd.php?edit=$submission_id";
    notifToUser($user_id, $admin_id, $title, $message, 'submitted', $link);
    
    $titleAdmin = '📥 User Kirim File';
    $messageAdmin = "User telah mengirim file $form_name. Silakan verifikasi.";
    $linkAdmin = "admin.php#submission_$submission_id";
    notifToAdmin($admin_id, $user_id, $titleAdmin, $messageAdmin, 'submitted', $linkAdmin);
}

// 2. Admin approve → notif ke user
function notifAdminApprove($user_id, $admin_id, $submission_id, $form_name) {
    $title = '✅ Form Disetujui';
    $message = "Form $form_name telah disetujui oleh admin.";
    $link = "form_sppd.php?edit=$submission_id";
    notifToUser($user_id, $admin_id, $title, $message, 'approved', $link);
}

// 3. Admin reject → notif ke user
function notifAdminReject($user_id, $admin_id, $submission_id, $form_name, $note) {
    $title = '❌ Form Ditolak';
    $message = "Form $form_name ditolak. Catatan: $note";
    $link = "form_sppd.php?edit=$submission_id";
    notifToUser($user_id, $admin_id, $title, $message, 'rejected', $link);
}

// 4. User download PDF → notif ke admin
function notifUserDownload($user_id, $admin_id, $form_name) {
    $title = '⬇️ PDF Didownload';
    $message = "$form_name telah di-download oleh user.";
    notifToAdmin($admin_id, $user_id, $title, $message, 'info', 'admin.php');
}

// 5. User lupa password → notif ke admin
function notifUserResetPassword($user_id, $admin_id) {
    $title = '🔑 Reset Password';
    $message = "User meminta reset password.";
    $link = "admin_users.php";
    notifToAdmin($admin_id, $user_id, $title, $message, 'warning', $link);
}
?>