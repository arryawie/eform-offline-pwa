<?php
// ============================================================
// API UPLOAD FILE - USER KIRIM PDF KE ADMIN (SECURED)
// ============================================================
require_once '../config/database.php';
require_once '../config/auth.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$submission_id = isset($_POST['submission_id']) ? (int)$_POST['submission_id'] : 0;

if ($submission_id === 0) {
    echo json_encode(['success' => false, 'message' => 'Submission ID required']);
    exit;
}

// ============================================================
// CEK SUBMISSION MILIK USER
// ============================================================
$stmt = $pdo->prepare("SELECT id, status, user_id FROM form_submissions WHERE id = ? AND user_id = ?");
$stmt->execute([$submission_id, $user_id]);
$submission = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$submission) {
    echo json_encode(['success' => false, 'message' => 'Submission not found']);
    exit;
}

if ($submission['status'] !== 'downloaded') {
    echo json_encode(['success' => false, 'message' => 'Status must be DOWNLOADED to submit']);
    exit;
}

// ============================================================
// VALIDASI FILE - LAYER 1: CEK ERROR
// ============================================================
if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    $errorMsg = 'File upload failed';
    if (isset($_FILES['file']['error'])) {
        switch ($_FILES['file']['error']) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                $errorMsg = 'File terlalu besar';
                break;
            case UPLOAD_ERR_PARTIAL:
                $errorMsg = 'Upload tidak selesai';
                break;
            case UPLOAD_ERR_NO_FILE:
                $errorMsg = 'Tidak ada file';
                break;
        }
    }
    echo json_encode(['success' => false, 'message' => $errorMsg]);
    exit;
}

$file = $_FILES['file'];
$tmpPath = $file['tmp_name'];

// ============================================================
// VALIDASI FILE - LAYER 2: CEK UKURAN
// ============================================================
$maxSize = 10 * 1024 * 1024; // 10MB
if ($file['size'] > $maxSize) {
    echo json_encode(['success' => false, 'message' => 'File terlalu besar. Max 10MB']);
    exit;
}
if ($file['size'] < 100) {
    echo json_encode(['success' => false, 'message' => 'File terlalu kecil / corrupt']);
    exit;
}

// ============================================================
// VALIDASI FILE - LAYER 3: CEK EKSTENSI
// ============================================================
$file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if ($file_ext !== 'pdf') {
    echo json_encode(['success' => false, 'message' => 'Hanya file PDF yang diizinkan']);
    exit;
}

// ============================================================
// VALIDASI FILE - LAYER 4: CEK MIME TYPE ASLI
// ============================================================
if (function_exists('finfo_open')) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $tmpPath);
    finfo_close($finfo);
    
    $allowedMimes = ['application/pdf'];
    if (!in_array($mimeType, $allowedMimes)) {
        echo json_encode(['success' => false, 'message' => 'File bukan PDF asli (MIME: ' . $mimeType . ')']);
        exit;
    }
} elseif (function_exists('mime_content_type')) {
    $mimeType = mime_content_type($tmpPath);
    if ($mimeType !== 'application/pdf') {
        echo json_encode(['success' => false, 'message' => 'File bukan PDF asli']);
        exit;
    }
}

// ============================================================
// VALIDASI FILE - LAYER 5: CEK MAGIC BYTES (FILE SIGNATURE)
// ============================================================
$handle = fopen($tmpPath, 'rb');
if (!$handle) {
    echo json_encode(['success' => false, 'message' => 'Gagal membaca file']);
    exit;
}
$magicBytes = fread($handle, 5);
fclose($handle);

// PDF selalu diawali dengan "%PDF-"
if (substr($magicBytes, 0, 5) !== '%PDF-') {
    echo json_encode(['success' => false, 'message' => 'File bukan PDF valid (signature salah)']);
    exit;
}

// ============================================================
// VALIDASI FILE - LAYER 6: CEK KONTEN BERBAHAYA
// ============================================================
// PDF tidak boleh mengandung PHP tag (untuk cegah PDF berisi kode PHP)
$content = file_get_contents($tmpPath);
$dangerousPatterns = [
    '/<\?php/i',
    '/<\?=/',
    '/<script\s+language\s*=\s*["\']?php/i',
    '/eval\s*\(/i',
    '/base64_decode\s*\(/i',
    '/system\s*\(/i',
    '/exec\s*\(/i',
    '/shell_exec\s*\(/i',
    '/passthru\s*\(/i'
];

foreach ($dangerousPatterns as $pattern) {
    if (preg_match($pattern, $content)) {
        echo json_encode(['success' => false, 'message' => 'File mengandung kode berbahaya']);
        exit;
    }
}

// ============================================================
// SIAPKAN FOLDER DINAMIS BERDASARKAN INSTANSI USER
// ============================================================

// 1. Ambil form_key dari submission
$stmt = $pdo->prepare("
    SELECT s.id, s.form_id, f.form_key, s.user_id
    FROM form_submissions s
    JOIN forms f ON s.form_id = f.id
    WHERE s.id = ?
");
$stmt->execute([$submission_id]);
$submission = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$submission) {
    echo json_encode(['success' => false, 'message' => 'Submission not found']);
    exit;
}

$formKey = $submission['form_key'];
$submissionUserId = $submission['user_id'];

// 2. Ambil fullname + instansi langsung dari user yang upload
$stmt = $pdo->prepare("SELECT fullname, instansi FROM users WHERE id = ?");
$stmt->execute([$submissionUserId]);
$userInfo = $stmt->fetch(PDO::FETCH_ASSOC);
$userName = $userInfo['fullname'] ?? 'user' . $submissionUserId;
$instansi = $userInfo['instansi'] ?? 'Umum';

// 3. Bersihkan nama instansi
$instansiFolder = preg_replace('/[^A-Za-z0-9]+/', '_', $instansi);
$instansiFolder = trim($instansiFolder, '_');
if (empty($instansiFolder)) $instansiFolder = 'Umum';

// 4. Nama file: username_tanggal_jam.pdf
$tanggal = date('Y-m-d');
$jam = date('His');
$filename = $userName . '_' . $tanggal . '_' . $jam . '.pdf';


// 5. Bangun path: uploads/pdfs/{instansi}/{form_key}/
$upload_dir = '../uploads/pdfs/' . $instansiFolder . '/' . $formKey . '/';
$relative_path = 'uploads/pdfs/' . $instansiFolder . '/' . $formKey . '/' . $filename;

// 6. Buat folder recursive
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// 7. Full path
$filepath = $upload_dir . $filename;

// 8. Handle duplikat (kalau nama file sudah ada)
if (file_exists($filepath)) {
    $filename = $userName . '_' . $tanggal . '_' . $jam . '_' . rand(100, 999) . '.pdf';
    $relative_path = 'uploads/pdfs/' . $instansiFolder . '/' . $formKey . '/' . $filename;
    $filepath = $upload_dir . $filename;
}

// 9.Pindahkan file
if (!move_uploaded_file($file['tmp_name'], $filepath)) {
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan file']);
    exit;
}

// 10. Set permission
chmod($filepath, 0644);

// 11. Buat .htaccess
$htaccessPath = $upload_dir . '.htaccess';
if (!file_exists($htaccessPath)) {
    $htaccessContent = "# Blokir eksekusi PHP\n";
    $htaccessContent .= "<FilesMatch \"\\.(php|php3|php4|php5|php7|phtml|pl|py|jsp|asp|sh|cgi)$\">\n";
    $htaccessContent .= "    Order allow,deny\n";
    $htaccessContent .= "    Deny from all\n";
    $htaccessContent .= "</FilesMatch>\n";
    $htaccessContent .= "Options -ExecCGI -Indexes\n";
    
    file_put_contents($htaccessPath, $htaccessContent);
}


// ============================================================
// UPDATE DATABASE
// ============================================================
$stmt = $pdo->prepare("
    UPDATE form_submissions 
    SET 
        pdf_path = ?,
        status = 'submitted',
        submitted_at = NOW(),
        updated_at = NOW()
    WHERE id = ?
");
$stmt->execute([$relative_path, $submission_id]);

// ============================================================
// KIRIM NOTIFIKASI
// ============================================================
require_once 'notif.php';

// Cari admin yang membuat user ini
$stmt = $pdo->prepare("SELECT created_by FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_id = $admin['created_by'] ?? 1;

// Kirim notifikasi
notifUserUpload($user_id, $admin_id, $submission_id, 'Form SPPD');

// ============================================================
// LOG AKTIVITAS
// ============================================================
try {
    $stmt = $pdo->prepare("
        INSERT INTO activity_logs (user_id, action, details, ip_address, created_at) 
        VALUES (?, ?, ?, ?, NOW())
    ");
    $stmt->execute([
        $user_id,
        'upload_file',
        "Submission ID: $submission_id, File: $filename, Size: {$file['size']} bytes",
        $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ]);
} catch (PDOException $e) {
    // Log gagal tidak masalah
}

// ============================================================
// RESPONSE
// ============================================================
echo json_encode([
    'success' => true,
    'message' => 'File berhasil dikirim!',
    'submission_id' => $submission_id,
    'status' => 'submitted',
    'pdf_path' => $relative_path,
    'file_size' => $file['size']
]);
?>