<?php
require_once '../config/database.php';
require_once '../config/auth.php';
requireLogin();

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$submission_id = isset($input['submission_id']) ? (int)$input['submission_id'] : 0;

if (!$submission_id) {
    echo json_encode(['success' => false, 'message' => 'ID submission tidak valid']);
    exit;
}

// Cek submission milik user
$stmt = $pdo->prepare("SELECT s.*, f.form_key, f.form_name, u.created_by 
                        FROM form_submissions s 
                        JOIN forms f ON s.form_id = f.id 
                        JOIN users u ON s.user_id = u.id 
                        WHERE s.id = ? AND s.user_id = ?");
$stmt->execute([$submission_id, $_SESSION['user_id']]);
$submission = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$submission) {
    echo json_encode(['success' => false, 'message' => 'Submission tidak ditemukan']);
    exit;
}

if (in_array($submission['status'], ['submitted', 'approved'])) {
    echo json_encode(['success' => false, 'message' => 'Form sudah dikirim/disetujui']);
    exit;
}

// Update status
$stmt = $pdo->prepare("UPDATE form_submissions SET status = 'submitted', submitted_at = NOW() WHERE id = ?");
$stmt->execute([$submission_id]);

// Notifikasi ke admin pembuat user
$admin_id = $submission['created_by'];
$user_name = $_SESSION['fullname'] ?? 'User';
$form_name = $submission['form_name'];
$form_key = $submission['form_key'];

if ($admin_id) {
    $title = '📤 Submission Baru dari ' . $user_name;
    $message = $user_name . ' mengirim form ' . $form_name . ' - ID #' . $submission_id;
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, sender_id, title, message, type, link, is_read, created_at) VALUES (?, ?, ?, ?, 'submitted', 'admin.php', 0, NOW())");
    $stmt->execute([$admin_id, $_SESSION['user_id'], $title, $message]);
}

// Notifikasi ke user
$title2 = '✅ Form Berhasil Dikirim!';
$message2 = 'Form ' . $form_name . ' - ID #' . $submission_id . ' telah dikirim. Menunggu verifikasi Admin.';
$stmt = $pdo->prepare("INSERT INTO notifications (user_id, sender_id, title, message, type, link, is_read, created_at) VALUES (?, ?, ?, ?, 'info', 'dashboard.php', 0, NOW())");
$stmt->execute([$_SESSION['user_id'], $_SESSION['user_id'], $title2, $message2]);

echo json_encode([
    'success' => true,
    'message' => 'Form berhasil dikirim!',
    'status' => 'submitted'
]);
