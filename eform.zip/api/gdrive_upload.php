<?php
// ============================================================
// UPLOAD FILE KE GOOGLE DRIVE
// ============================================================
require_once '../config/database.php';
require_once '../config/auth.php';
requireAdmin();

header('Content-Type: application/json');

if ($_SESSION['role'] !== 'super_admin') {
    echo json_encode(['success' => false, 'message' => 'Hanya Super Admin']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$submission_id = $input['submission_id'] ?? 0;
$pdf_path = $input['pdf_path'] ?? '';

if (!$submission_id || !$pdf_path) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$fullPath = '../' . $pdf_path;

if (!file_exists($fullPath)) {
    echo json_encode(['success' => false, 'message' => 'File tidak ditemukan di server']);
    exit;
}

// ============================================================
// KONEKSI GOOGLE DRIVE
// ============================================================

// Ambil refresh token dari super admin
$stmt = $pdo->prepare("SELECT gdrive_refresh_token, gdrive_folder_id FROM users WHERE role = 'super_admin' AND gdrive_enabled = 1 LIMIT 1");
$stmt->execute();
$gdriveUser = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$gdriveUser || empty($gdriveUser['gdrive_refresh_token'])) {
    echo json_encode(['success' => false, 'message' => 'Google Drive belum terhubung']);
    exit;
}

// Setup Google Client
require_once '../vendor/autoload.php';

$client = new Google\Client();
$client->setAuthConfig('/www/credentials/gdrive_credentials.json');
$client->addScope(Google\Service\Drive::DRIVE_FILE);
$client->setAccessType('offline');
$client->fetchAccessTokenWithRefreshToken($gdriveUser['gdrive_refresh_token']);

$driveService = new Google\Service\Drive($client);

// ============================================================
// BUAT STRUKTUR FOLDER DI GOOGLE DRIVE
// ============================================================

// Parse path: uploads/pdfs/{instansi}/{form_key}/filename.pdf
$pathParts = explode('/', $pdf_path);
// [0]=uploads [1]=pdfs [2]=instansi [3]=form_key [4]=filename.pdf

$instansi = $pathParts[2] ?? 'Umum';
$formKey = $pathParts[3] ?? 'form';
$filename = basename($pdf_path);

$rootFolderId = $gdriveUser['gdrive_folder_id'];

// Fungsi buat/cari folder
function getOrCreateFolder($driveService, $name, $parentId) {
    $query = "name='" . $name . "' and mimeType='application/vnd.google-apps.folder' and '" . $parentId . "' in parents and trashed=false";
    $results = $driveService->files->listFiles([
        'q' => $query,
        'fields' => 'files(id, name)',
        'spaces' => 'drive'
    ]);
    
    if (count($results->files) > 0) {
        return $results->files[0]->id;
    }
    
    // Buat folder baru
    $folderMetadata = new Google\Service\Drive\DriveFile([
        'name' => $name,
        'mimeType' => 'application/vnd.google-apps.folder',
        'parents' => [$parentId]
    ]);
    
    $folder = $driveService->files->create($folderMetadata, [
        'fields' => 'id'
    ]);
    
    return $folder->id;
}

// Buat folder instansi
$instansiFolderId = getOrCreateFolder($driveService, $instansi, $rootFolderId);

// Buat folder form_key
$formFolderId = getOrCreateFolder($driveService, $formKey, $instansiFolderId);

// ============================================================
// UPLOAD FILE
// ============================================================

try {
    $fileMetadata = new Google\Service\Drive\DriveFile([
        'name' => $filename,
        'parents' => [$formFolderId]
    ]);
    
    $content = file_get_contents($fullPath);
    
    $file = $driveService->files->create($fileMetadata, [
        'data' => $content,
        'mimeType' => 'application/pdf',
        'uploadType' => 'multipart',
        'fields' => 'id, webViewLink'
    ]);
    
    // Update database
    $stmt = $pdo->prepare("
        UPDATE form_submissions 
        SET gdrive_file_id = ?, gdrive_url = ?, gdrive_uploaded_at = NOW() 
        WHERE id = ?
    ");
    $stmt->execute([$file->id, $file->webViewLink, $submission_id]);
    
    echo json_encode([
        'success' => true,
        'message' => 'File berhasil diupload',
        'gdrive_file_id' => $file->id,
        'gdrive_url' => $file->webViewLink
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Gagal upload: ' . $e->getMessage()
    ]);
}
?>