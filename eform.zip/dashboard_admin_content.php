<?php
// ============================================================
// DASHBOARD ADMIN - STATISTIK & DETAIL
// ============================================================
// File ini di-include dari dashboard.php
// Jangan require database & auth lagi

// ============================================================
// STATISTIK: TOTAL USER YANG DIBUAT ADMIN INI
// ============================================================
$stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE created_by = ? AND role = 'user'");
$stmt->execute([$user_id]);
$totalUser = $stmt->fetchColumn();

// ============================================================
// STATISTIK: JUMLAH SUBMISSION PER FORM
// ============================================================
$stmt = $pdo->prepare("
    SELECT 
        f.form_key,
        f.form_name,
        f.icon,
        COUNT(DISTINCT s.id) as total
    FROM form_submissions s
    JOIN forms f ON s.form_id = f.id
    JOIN users u ON s.user_id = u.id
    WHERE u.created_by = ?
    GROUP BY f.form_key, f.form_name, f.icon
");
$stmt->execute([$user_id]);
$perForm = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ============================================================
// STATISTIK: STATUS SUBMISSION
// ============================================================
$stmt = $pdo->prepare("
    SELECT 
        s.status,
        COUNT(*) as total
    FROM form_submissions s
    JOIN users u ON s.user_id = u.id
    WHERE u.created_by = ?
    GROUP BY s.status
");
$stmt->execute([$user_id]);
$statusData = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$statusApproved = $statusData['approved'] ?? 0;
$statusPending = $statusData['submitted'] ?? 0;
$statusRejected = $statusData['rejected'] ?? 0;
$statusDraft = ($statusData['draft'] ?? 0) + ($statusData['downloaded'] ?? 0);

// ============================================================
// DETAIL SUBMISSION
// ============================================================
$stmt = $pdo->prepare("
    SELECT s.*, f.form_name, f.icon, f.form_key,
           u.fullname AS user_fullname, u.username AS user_username,
           u.divisi AS user_divisi
    FROM form_submissions s 
    JOIN forms f ON s.form_id = f.id 
    JOIN users u ON s.user_id = u.id
    WHERE u.created_by = ?
    ORDER BY s.created_at DESC 
    LIMIT 50
");
$stmt->execute([$user_id]);
$submissionList = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
            margin-bottom: 20px;
        }
        .stat-box {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }
        .stat-box .icon { font-size: 32px; margin-bottom: 8px; }
        .stat-box .num { font-size: 32px; font-weight: 800; color: #1A1A2E; }
        .stat-box .label { font-size: 12px; color: #6B7A99; text-transform: uppercase; margin-top: 4px; }
        
        .status-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }
        .status-box {
            background: #fff;
            border-radius: 12px;
            padding: 16px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            border-left: 4px solid #ccc;
        }
        .status-box.approved { border-left-color: #1A7A45; }
        .status-box.pending { border-left-color: #F5A623; }
        .status-box.rejected { border-left-color: #C62828; }
        .status-box .num { font-size: 24px; font-weight: 800; }
        .status-box .label { font-size: 11px; color: #6B7A99; text-transform: uppercase; }
        
        .submission-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .submission-table th {
            text-align: left;
            padding: 12px;
            background: #F8F9FC;
            color: #6B7A99;
            font-weight: 700;
            font-size: 11px;
            text-transform: uppercase;
            border-bottom: 2px solid #DDE3F0;
        }
        .submission-table td {
            padding: 12px;
            border-bottom: 1px solid #EEF0F6;
            vertical-align: middle;
        }
        .submission-table tr:hover { background: #FAFBFD; }
        
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }
        .status-badge.draft { background: #EEF0F6; color: #6B7A99; }
        .status-badge.downloaded { background: #EEFAF4; color: #1A7A45; }
        .status-badge.submitted { background: #FFFBEE; color: #B07A00; }
        .status-badge.approved { background: #EEFAF4; color: #1A7A45; }
        .status-badge.rejected { background: #FFE5E5; color: #C62828; }
        
        .card {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            margin-bottom: 20px;
        }
        .card-header { font-weight: 700; font-size: 14px; margin-bottom: 12px; padding-bottom: 12px; border-bottom: 1px solid #eee; }
        
        @media (max-width: 768px) {
            .status-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<?php include "sidebar.php"; ?>
<div class="app">
    <main class="main">
        <header class="topbar">
            <div class="topbar-left">
                <button type="button" class="hamburger" onclick="toggleSidebar()" aria-label="Buka menu">☰</button>
                <h2>Dashboard Admin</h2>
            </div>
            <div class="topbar-right">
                <span class="user-badge">👤 <?= htmlspecialchars($_SESSION['fullname']) ?> <span class="role-badge"><?= $_SESSION['role'] ?></span></span>
            </div>
        </header>

        <!-- STATISTIK UTAMA -->
        <div class="stats-grid">
            <div class="stat-box">
                <div class="icon">👥</div>
                <div class="num"><?= $totalUser ?></div>
                <div class="label">Total User</div>
            </div>
            
            <?php foreach ($perForm as $pf): ?>
            <div class="stat-box">
                <div class="icon"><?= $pf['icon'] ?></div>
                <div class="num"><?= $pf['total'] ?></div>
                <div class="label"><?= htmlspecialchars($pf['form_name']) ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- STATUS SUBMISSION -->
        <div class="status-row">
            <div class="status-box approved">
                <div class="num"><?= $statusApproved ?></div>
                <div class="label">✅ Approved</div>
            </div>
            <div class="status-box pending">
                <div class="num"><?= $statusPending ?></div>
                <div class="label">⏳ Pending</div>
            </div>
            <div class="status-box rejected">
                <div class="num"><?= $statusRejected ?></div>
                <div class="label">❌ Rejected</div>
            </div>
        </div>

        <!-- DETAIL SUBMISSION -->
        <div class="card">
            <div class="card-header">📋 Detail Submission</div>
            
            <?php if (empty($submissionList)): ?>
                <p style="text-align:center;color:#6B7A99;padding:20px;">Belum ada submission dari user Anda</p>
            <?php else: ?>
            <table class="submission-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>User</th>
                        <th>Divisi</th>  <!-- BARU -->
                        <th>Form</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php $no = 1; foreach ($submissionList as $s): 
                    $statusClass = $s['status'] ?? 'draft';
                    $statusLabel = ['draft'=>'📝 Draf','downloaded'=>'⬇ Downloaded','submitted'=>'📤 Terkirim','approved'=>'✅ Approved','rejected'=>'❌ Rejected'][$statusClass] ?? $statusClass;
                ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><strong><?= htmlspecialchars($s['user_fullname'] ?? $s['user_username'] ?? '-') ?></strong></td>
                    <td><?= htmlspecialchars($s['user_divisi'] ?? '-') ?></td>              <!-- INI YANG KURANG -->
                    <td><?= $s['icon'] ?> <?= htmlspecialchars($s['form_name']) ?></td>
                    <td><?= date('d/m/Y H:i', strtotime($s['created_at'])) ?></td>
                    <td><span class="status-badge <?= $statusClass ?>"><?= $statusLabel ?></span></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </main>
</div>
<script src="assets/js/main.js"></script>
<footer style="text-align:center;padding:16px 0 8px;border-top:1px solid #DDE3F0;margin-top:20px;font-size:11px;color:#6B7A99;">
    E-Form System v1.8 &copy; 2026 PT. Nura Kreasi Digital
</footer>
</body>
</html>