#!/bin/bash

# Cari posisi dan ganti bagian IV dengan tabel
sed -i '/<!-- IV. URAIAN HASIL PENGAWASAN -->/,/<!-- V. DUGAAAN PELANGGARAN -->/c\
                <!-- IV. URAIAN HASIL PENGAWASAN -->\
                <div class="card">\
                    <div class="card-header">IV. 📝 Uraian Hasil Pengawasan</div>\
                    <div class="card-body">\
                        <div class="form-group">\
                            <label>1. Apakah KPPS mengumumkan hasil penghitungan suara di TPS?</label>\
                            <div class="grid-2" style="margin-bottom:4px;">\
                                <select id="q1_jawab">\
                                    <option value="">-- Pilih --</option>\
                                    <option value="Ya">Ya</option>\
                                    <option value="Tidak">Tidak</option>\
                                </select>\
                                <input type="text" id="q1_tanggal" placeholder="" style="display:none;">\
                            </div>\
                            <textarea id="q1_penjelasan" rows="2" placeholder=""></textarea>\
                        </div>\
                        <div class="form-group">\
                            <label>2. Apakah KPPS menyampaikan Salinan Formulir?</label>\
                            <select id="q2_jawab">\
                                <option value="">-- Pilih --</option>\
                                <option value="Ya">Ya</option>\
                                <option value="Tidak">Tidak</option>\
                            </select>\
                            <textarea id="q2_penjelasan" rows="3" placeholder=""></textarea>\
                        </div>\
                        <div class="form-group">\
                            <label>3. Apakah KPPS menyegel, menjaga, dan mengamankan keutuhan kotak suara?</label>\
                            <select id="q3_jawab">\
                                <option value="">-- Pilih --</option>\
                                <option value="Ya">Ya</option>\
                                <option value="Tidak">Tidak</option>\
                            </select>\
                            <textarea id="q3_penjelasan" rows="2" placeholder=""></textarea>\
                        </div>\
                        <div class="form-group">\
                            <label>4. Apakah KPPS menyerahkan kotak suara dan C Hasil Salinan ke PPS?</label>\
                            <select id="q4_jawab">\
                                <option value="">-- Pilih --</option>\
                                <option value="Ya">Ya</option>\
                                <option value="Tidak">Tidak</option>\
                            </select>\
                            <div class="grid-2" style="margin-top:4px;">\
                                <input type="text" id="q4_tanggal" placeholder="">\
                                <input type="text" id="q4_pukul" placeholder="">\
                            </div>\
                        </div>\
                        <div class="form-group">\
                            <label>5. Catatan Kejadian Khusus</label>\
                            <textarea id="catatan_kejadian" rows="4" placeholder=""></textarea>\
                        </div>\
                    </div>\
                </div>' form_a.php

# Update PDF builder
sed -i '/\/\/ IV. URAIAN/,/\/\/ V. DUGAAAN PELANGGARAN/c\
    // IV. URAIAN\
    html += '\''<div class="pdf-section">IV. Uraian Singkat Hasil Pengawasan</div>'\'';\
    html += '\''<table class="pdf-tbl">'\'';\
    html += '\''<tr><td style="font-weight:700;text-align:center;width:30px;">No</td><td style="font-weight:700;text-align:center;">Pertanyaan</td><td style="font-weight:700;text-align:center;width:80px;">Jawab</td><td style="font-weight:700;text-align:center;">Penjelasan</td></tr>'\'';\
    html += '\''<tr><td style="text-align:center;">1</td><td>Apakah KPPS mengumumkan hasil penghitungan suara di TPS?</td><td style="text-align:center;">'\''+yesno(v('\''q1_jawab'\''))+'\''</td><td>'\''+nl(v('\''q1_penjelasan'\''))+'\''</td></tr>'\'';\
    html += '\''<tr><td style="text-align:center;">2</td><td>Apakah KPPS menyampaikan Salinan Formulir?</td><td style="text-align:center;">'\''+yesno(v('\''q2_jawab'\''))+'\''</td><td>'\''+nl(v('\''q2_penjelasan'\''))+'\''</td></tr>'\'';\
    html += '\''<tr><td style="text-align:center;">3</td><td>Apakah KPPS menyegel, menjaga, dan mengamankan keutuhan kotak suara?</td><td style="text-align:center;">'\''+yesno(v('\''q3_jawab'\''))+'\''</td><td>'\''+nl(v('\''q3_penjelasan'\''))+'\''</td></tr>'\'';\
    html += '\''<tr><td style="text-align:center;">4</td><td>Apakah KPPS penyerahan kotak suara dan C Hasil Salinan ke PPS ?</td><td style="text-align:center;">'\''+yesno(v('\''q4_jawab'\''))+'\''</td><td>Tanggal '\''+esc(v('\''q4_tanggal'\''))+'\'' Pukul '\''+esc(v('\''q4_pukul'\''))+'\''</td></tr>'\'';\
    html += '\''<tr><td style="text-align:center;">5</td><td>Catatan Kejadian Khusus</td><td colspan="2">'\''+nl(v('\''catatan_kejadian'\''))+'\''</td></tr>'\'';\
    html += '\''</table>'\'';' form_a.php

echo "✅ Bagian IV dikembalikan ke bentuk TABEL (seperti contoh PDF)!"
echo "📌 Dokumentasi tetap ada di bawah TTD"
