<?php
// ============================================================
// FORM ST - Surat Tugas
// ============================================================
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

$form_key = 'form_st';
$form_title = 'Surat Tugas';

if (!canAccessForm($form_key)) {
    die("<h1>⛔ Akses Ditolak</h1><p>Anda tidak memiliki akses ke form ini.</p><a href='dashboard.php'>← Kembali</a>");
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? 'user';

// Cek apakah user Super Admin atau Admin
if (in_array($role, ['super_admin', 'admin'])) {
    // Ambil form milik user tersebut
    $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id = ?");
    $stmt->execute([$form_key, $user_id]);
    $form = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$form) {
        // Buat form default untuk user
        $stmt = $pdo->prepare("INSERT INTO forms (form_key, form_name, user_id, is_active) VALUES (?, ?, ?, 1)");
        $stmt->execute([$form_key, $form_title, $user_id]);
        
        $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id = ?");
        $stmt->execute([$form_key, $user_id]);
        $form = $stmt->fetch(PDO::FETCH_ASSOC);
    }
} else {
    // User: ambil dari admin yang membuatnya (created_by)
    $stmt = $pdo->prepare("SELECT created_by FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($userData && $userData['created_by']) {
        $adminId = $userData['created_by'];
        $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id = ?");
        $stmt->execute([$form_key, $adminId]);
        $form = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    if (!$form) {
        // Fallback: ambil form default (user_id NULL)
        $stmt = $pdo->prepare("SELECT * FROM forms WHERE form_key = ? AND user_id IS NULL");
        $stmt->execute([$form_key]);
        $form = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

$kop_logo = $form['kop_logo'] ?? '';
$kop_instansi = $form['kop_instansi'] ?? 'BADAN PENGAWAS PEMILIHAN UMUM';
$kop_alamat = $form['kop_alamat'] ?? '';
$kop_telp = $form['kop_telp'] ?? '';
$kop_email = $form['kop_email'] ?? '';

if (!$form || $form['is_active'] != 1) {
    die("<h1>⚠️ Form sedang tidak aktif</h1>");
}

$kop_logo = $form['kop_logo'] ?? '';
$kop_instansi = $form['kop_instansi'] ?? 'PANWASLU KECAMATAN PATIMUAN';
$kop_alamat = $form['kop_alamat'] ?? '';
$kop_telp = $form['kop_telp'] ?? '';
$kop_email = $form['kop_email'] ?? '';
$kop_website = $form['kop_website'] ?? '';
$kop_kabupaten = $form['kop_kabupaten'] ?? 'KABUPATEN CILACAP';

$submissions = $pdo->prepare("
    SELECT s.*, f.form_name, f.icon 
    FROM form_submissions s 
    JOIN forms f ON s.form_id = f.id 
    WHERE s.user_id = ? AND f.form_key = ? 
    ORDER BY s.created_at DESC 
    LIMIT 20
");
$submissions->execute([$_SESSION['user_id'], $form_key]);
$submissionList = $submissions->fetchAll(PDO::FETCH_ASSOC);

// Ambil submission_id terbaru
$submission_id = 0;
if (!empty($submissionList)) {
    $submission_id = $submissionList[0]['id'];
}

// ===== FIELD ST =====
$fields = [
    ['id' => 'nomor_surat', 'label' => 'Nomor Surat', 'type' => 'text', 'placeholder' => 'SPD-230900234/K.JT.07/19/09/2023'],
    ['id' => 'ttd_kota', 'label' => 'Dikeluarkan di', 'type' => 'text', 'placeholder' => 'Patimuan'],
    ['id' => 'ttd_tgl', 'label' => 'Pada Tanggal', 'type' => 'date'],
    ['id' => 'ttd_instansi', 'label' => 'Nama Instansi', 'type' => 'text', 'placeholder' => 'PANWASLU KECAMATAN PATIMUAN'],
    ['id' => 'ttd_jabatan', 'label' => 'Jabatan Penandatangan', 'type' => 'text', 'placeholder' => 'KETUA'],
    ['id' => 'ttd_nama', 'label' => 'Nama Penandatangan', 'type' => 'text', 'placeholder' => 'NGADIMAN'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $form_title ?> - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <style>
        * { box-sizing: border-box; }
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; margin:0; }
        .form-container { max-width: 900px; margin: 0 auto; padding: 20px; }
        .topbar { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; background: #fff; padding: 15px 20px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .topbar h2 { margin: 0; font-size: 18px; color: #1A1A2E; }
        .tab-bar { display: flex; gap: 4px; background: #fff; border-radius: 12px; padding: 4px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); flex-wrap:wrap; }
        .tab-btn { padding: 10px 24px; border: none; border-radius: 8px; background: transparent; font-weight: 600; cursor: pointer; color: #6B7A99; transition: 0.2s; font-size: 14px; }
        .tab-btn.active { background: #E53935; color: #fff; }
        .tab-btn:hover:not(.active) { background: #f0f0f0; }
        .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); margin-bottom: 16px; overflow: hidden; }
        .card-header { padding: 12px 20px; background: #f8f9fc; border-bottom: 1px solid #eee; font-weight: 700; color: #1A1A2E; font-size: 14px; }
        .card-body { padding: 16px 20px; }
        .form-group { margin-bottom: 12px; }
        .form-group label { display: block; font-weight: 600; font-size: 13px; color: #2c3e50; margin-bottom: 4px; }
        .form-group label .req { color: #E53935; }
        .form-group input, .form-group textarea, .form-group select { width: 100%; padding: 8px 12px; border: 1.5px solid #DDE3F0; border-radius: 8px; font-size: 14px; font-family: inherit; transition: 0.2s; background: #fff; }
        .form-group input:focus, .form-group textarea:focus { border-color: #E53935; outline: none; box-shadow: 0 0 0 3px rgba(229,57,53,0.1); }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .btn { padding: 8px 20px; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 13px; transition: 0.2s; text-decoration: none; display: inline-block; }
        .btn-primary { background: #E53935; color: #fff; }
        .btn-primary:hover { background: #c62828; }
        .btn-secondary { background: #6B7A99; color: #fff; }
        .btn-secondary:hover { background: #5a6a89; }
        .btn-success { background: #2E7D32; color: #fff; }
        .btn-success:hover { background: #1B5E20; }
        .btn-outline { background: transparent; color: #E53935; border: 1.5px solid #E53935; }
        .btn-outline:hover { background: #FFF5F5; }
        .btn-sm { padding: 4px 12px; font-size: 12px; }
        .btn-row { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 16px; }
        .btn-row .btn { flex: 1; min-width: 100px; text-align: center; }
        .alert { padding: 10px 16px; border-radius: 8px; margin-bottom: 12px; font-size: 13px; }
        .alert-info { background: #EEF4FF; color: #2D5BE3; border: 1px solid #C3D4F9; }
        .photo-zone { border: 2px dashed #DDE3F0; border-radius: 8px; padding: 16px; text-align: center; cursor: pointer; transition: 0.2s; background: #FAFBFD; }
        .photo-zone:hover { border-color: #E53935; background: #FFF5F5; }
        .photo-zone input { display: none; }
        .photo-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 10px; margin-top: 10px; }
        .photo-item { position: relative; border-radius: 8px; overflow: hidden; aspect-ratio: 4/3; border: 1.5px solid #DDE3F0; background: #f0f0f0; }
        .photo-item img { width: 100%; height: 100%; object-fit: cover; }
        .photo-item .caption-input { position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0,0,0,0.6); padding: 4px 7px; border: none; color: #fff; font-size: 10px; font-family: inherit; width: 100%; outline: none; }
        .photo-item .remove-btn { position: absolute; top: 4px; right: 4px; width: 22px; height: 22px; background: rgba(229,57,53,0.85); border: none; border-radius: 50%; color: #fff; font-size: 12px; cursor: pointer; }
        .status-badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
        .status-badge.draft { background: #EEF0F6; color: #6B7A99; }
        .status-badge.previewed { background: #EEF4FF; color: #2D5BE3; }
        .status-badge.downloaded { background: #EEFAF4; color: #1A7A45; }
        .status-badge.submitted { background: #FFFBEE; color: #B07A00; }
        .status-badge.approved { background: #EEFAF4; color: #1A7A45; }
        .status-badge.rejected { background: #FFE5E5; color: #C62828; }
        .submission-table { width: 100%; border-collapse: collapse; font-size: 12px; }
        .submission-table th { text-align: left; padding: 6px 8px; background: #F8F9FC; color: #6B7A99; font-weight: 700; font-size: 11px; text-transform: uppercase; border-bottom: 2px solid #DDE3F0; }
        .submission-table td { padding: 6px 8px; border-bottom: 1px solid #EEF0F6; vertical-align: middle; }
        .submission-table tr:hover { background: #FAFBFD; }
        .btn-edit { background: #2D5BE3; color: #fff; border: none; padding: 2px 10px; border-radius: 4px; font-size: 11px; cursor: pointer; }
        .btn-edit:hover { background: #1A3F8A; }
        .btn-preview { background: #F5A623; color: #fff; border: none; padding: 2px 10px; border-radius: 4px; font-size: 11px; cursor: pointer; }
        .btn-preview:hover { background: #d4911a; }
        .btn-delete { background: #dc3545; color: #fff; border: none; padding: 2px 10px; border-radius: 4px; font-size: 11px; cursor: pointer; }
        .btn-delete:hover { background: #b02a37; }
        .btn-add { background: #28a745; color: #fff; border: none; padding: 6px 16px; border-radius: 4px; font-size: 12px; cursor: pointer; margin-top: 8px; }
        .btn-add:hover { background: #1e7e34; }
        .btn-remove { background: #dc3545; color: #fff; border: none; padding: 2px 8px; border-radius: 4px; font-size: 11px; cursor: pointer; margin-left: 8px; }
        .btn-remove:hover { background: #b02a37; }
        .dynamic-row { display: flex; gap: 8px; align-items: center; margin-bottom: 6px; flex-wrap: wrap; }
        .dynamic-row input { flex: 1; min-width: 150px; }
        .dynamic-row .row-number { font-weight: 700; color: #E53935; min-width: 24px; }
        #previewArea { background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); overflow: hidden; }
        .preview-toolbar { background: #f8f9fc; padding: 12px 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; }
        .preview-content { padding: 20px; max-height: 700px; overflow-y: auto; }
        .pdf-page { background: #fff; padding: 30px 35px; max-width: 680px; margin: 0 auto 16px; font-family: 'Times New Roman', serif; font-size: 10.5pt; line-height: 1.6; border: 1px solid #ddd; border-radius: 4px; }
        .pdf-page .kop { text-align: center; margin-bottom: 12px; border-bottom: 2px solid #1A1A2E; padding-bottom: 10px; }
        .pdf-page .kop img { max-height: 60px; width: auto; }
        .pdf-page .kop .instansi { font-size: 13pt; font-weight: 700; color: #1A1A2E; }
        .pdf-page .kop .alamat { font-size: 8.5pt; color: #666; }
        .pdf-title { font-size: 12pt; font-weight: 700; text-align: center; text-transform: uppercase; }
        .pdf-section { font-weight: 700; font-size: 11pt; margin: 8px 0 4px; }
        .pdf-tbl { width: 100%; border-collapse: collapse; font-size: 9pt; margin: 4px 0; table-layout: fixed; }
        .pdf-tbl th { border: 1px solid #444; padding: 4px 6px; background: #e8e8e8; font-weight: 700; text-align: center; }
        .pdf-tbl td { border: 1px solid #444; padding: 4px 6px; vertical-align: top; word-wrap: break-word; overflow-wrap: break-word; }
        .pdf-tbl td.data-row { height: 26mm; vertical-align: top; }
        .pdf-tbl .label-col { width: 160px; font-weight: 600; }
        .pdf-ttd { text-align: right; margin-top: 20px; }
        .pdf-ttd .nama { font-weight: 700; text-decoration: underline; display: block; margin-top: 40px; }
        .pdf-ttd .jabatan { font-weight: 600; display: block; }
        .pdf-foto-title { text-align: center; font-weight: 700; font-size: 11pt; margin: 12px 0 8px; }
        .pdf-foto-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .pdf-foto-item img { width: 100%; border: 1px solid #ccc; border-radius: 4px; }
        .pdf-foto-item p { text-align: center; font-size: 8.5pt; margin-top: 3px; font-style: italic; color: #555; }
        .app { display: flex; min-height: 100vh; }
        .sidebar { width: 240px; background: #1A1A2E; color: #fff; padding: 20px; flex-shrink: 0; }
        .sidebar-brand { font-size: 20px; font-weight: 700; margin-bottom: 30px; }
        .sidebar-nav a { display: block; padding: 10px 12px; color: rgba(255,255,255,0.7); text-decoration: none; border-radius: 8px; margin-bottom: 4px; transition: 0.2s; }
        .sidebar-nav a:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .sidebar-nav .logout { color: #E53935; margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 16px; }
        .main { flex: 1; padding: 20px; background: #f0f2f5; }
        .hamburger { display: none; background: none; border: none; font-size: 24px; cursor: pointer; }
        .user-badge { background: rgba(0,0,0,0.08); padding: 4px 12px; border-radius: 20px; font-size: 13px; }
        .toggle-row { display:flex; align-items:center; gap:10px; margin-bottom:12px; }
        .toggle-switch { position:relative; width:44px; height:24px; flex-shrink:0; }
        .toggle-switch input { opacity:0; width:0; height:0; }
        .toggle-slider { position:absolute; cursor:pointer; top:0; left:0; right:0; bottom:0; background:#DDE3F0; transition:.2s; border-radius:24px; }
        .toggle-slider:before { position:absolute; content:""; height:18px; width:18px; left:3px; bottom:3px; background:#fff; transition:.2s; border-radius:50%; }
        .toggle-switch input:checked + .toggle-slider { background:#E53935; }
        .toggle-switch input:checked + .toggle-slider:before { transform:translateX(20px); }
        @media (max-width: 768px) { .sidebar { display: none; } .sidebar.open { display: block; position: fixed; top: 0; left: 0; height: 100%; z-index: 1000; width: 260px; } .hamburger { display: block; } .main { padding: 10px; } .grid-2 { grid-template-columns: 1fr; } .btn-row { flex-direction: column; } .pdf-page { padding: 15px; } .dynamic-row { flex-direction: column; align-items: stretch; } }
    </style>
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">📋 E-Form</div>
        <nav class="sidebar-nav">
            <a href="dashboard.php">📊 Dashboard</a>
            <?php if (hasRole('super_admin') || hasRole('admin')): ?>
            <a href="admin_users.php">👥 Manajemen User</a>
            <a href="forms.php">📝 Manajemen Form</a>
            <?php endif; ?>
            <a href="profile.php">⚙️ Profile</a>
            <a href="logout.php" class="logout">🚪 Logout</a>
        </nav>
    </aside>
    <main class="main">
        <div class="form-container">
            <div class="topbar">
                <div style="display:flex;align-items:center;gap:10px;">
                    <button class="hamburger" onclick="toggleSidebar()">☰</button>
                    <h2>📋 <?= $form_title ?></h2>
                </div>
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <span class="user-badge">👤 <?= htmlspecialchars($_SESSION['fullname']) ?></span>
                    <a href="dashboard.php" class="btn btn-secondary btn-sm" style="padding:4px 12px;font-size:12px;">← Kembali</a>
                </div>
            </div>

            <div class="tab-bar">
                <button class="tab-btn active" onclick="switchTab('form')">📝 Form</button>
                <button class="tab-btn" onclick="switchTab('preview')">👁 Preview</button>
                <button class="tab-btn" onclick="switchTab('riwayat')">📋 Riwayat</button>
            </div>

            <!-- TAB FORM -->
            <div id="tabForm">
                <div class="alert alert-info">ℹ️ Isi data lengkap. Klik <strong>Preview</strong> untuk melihat hasil dokumen.</div>
                <div id="formContainer">

                <!-- NOMOR SURAT -->
                <div class="card">
                    <div class="card-header">📌 Nomor Surat</div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Nomor Surat <span class="req">*</span></label>
                            <input type="text" id="nomor_surat" placeholder="SPD-230900234/K.JT.07/19/09/2023">
                        </div>
                    </div>
                </div>

            <!-- DASAR HUKUM - 9 BARIS HARDCODE + TAMBAH -->
            <div class="card">
                <div class="card-header">📜 Dasar Hukum</div>
                <div class="card-body">
                    <div id="dasar_hukum_container">
                        <!-- 9 BARIS HARDCODE DENGAN ISI LENGKAP -->
                        <div class="dynamic-row">
                            <span class="row-number">1.</span>
                            <input type="text" class="dasar_hukum_input" value="Peraturan Pemerintah Pengganti Undang-Undang Republik Indonesia Nomor 1 Tahun 2022 tentang Perubahan atas Undang-Undang Nomor 7 Tahun 2017 tentang Pemilihan Umum.">
                            <button class="btn-remove" onclick="removeRow(this, 'dasar_hukum_container')" style="display:none;">✕</button>
                        </div>
                        <div class="dynamic-row">
                            <span class="row-number">2.</span>
                            <input type="text" class="dasar_hukum_input" value="Peraturan Presiden Nomor 68 Tahun 2018 tentang Kedudukan, Tugas, Fungsi, Wewenang, Organisasi dan Tata Kerja Sekretariat Jenderal Badan Pengawas Pemilihan Umum, Sekretariat Badan Pengawas Pemilihan Umum Provinsi, dan Sekretariat Badan Pengawas Pemilihan Umum Kabupaten/Kota.">
                            <button class="btn-remove" onclick="removeRow(this, 'dasar_hukum_container')">✕</button>
                        </div>
                        <div class="dynamic-row">
                            <span class="row-number">3.</span>
                            <input type="text" class="dasar_hukum_input" value="Peraturan Menteri Keuangan Republik Indonesia Nomor 113/PMK.05/2012 tentang Perjalanan Dinas Dalam Negeri Bagi Pejabat Negara, Pegawai Negeri dan Pegawai Tidak Tetap.">
                            <button class="btn-remove" onclick="removeRow(this, 'dasar_hukum_container')">✕</button>
                        </div>
                        <div class="dynamic-row">
                            <span class="row-number">4.</span>
                            <input type="text" class="dasar_hukum_input" value="Peraturan Menteri Keuangan Republik Indonesia Nomor 83/PMK.02/2022 tentang Standar Biaya Masukan Tahun Anggaran 2023.">
                            <button class="btn-remove" onclick="removeRow(this, 'dasar_hukum_container')">✕</button>
                        </div>
                        <div class="dynamic-row">
                            <span class="row-number">5.</span>
                            <input type="text" class="dasar_hukum_input" value="Peraturan Menteri Keuangan Republik Indonesia Nomor 210/PMK.05/2022 tentang Tata Cara Pembayaran dalam Rangka Pelaksanaan Anggaran Pendapatan dan Belanja Negara.">
                            <button class="btn-remove" onclick="removeRow(this, 'dasar_hukum_container')">✕</button>
                        </div>
                        <div class="dynamic-row">
                            <span class="row-number">6.</span>
                            <input type="text" class="dasar_hukum_input" value="Peraturan Badan Pengawas Pemilihan Umum Republik Indonesia Nomor 1 Tahun 2021 tentang Organisasi dan Tata Kerja Sekretariat Jenderal Badan Pengawas Pemilihan Umum, Sekretariat Badan Pengawas Pemilihan Umum Provinsi, Sekretariat Badan Pengawas Pemilihan Umum Kabupaten/Kota dan Sekretariat Panitia Pengawas Pemilihan Umum Kecamatan.">
                            <button class="btn-remove" onclick="removeRow(this, 'dasar_hukum_container')">✕</button>
                        </div>
                        <div class="dynamic-row">
                            <span class="row-number">7.</span>
                            <input type="text" class="dasar_hukum_input" value="Keputusan Ketua Badan Pengawas Pemilihan Umum Nomor 237/HK.01/K1/07/2023 tentang Pedoman Pelaksanaan Perjalanan Dinas Di Badan Pengawas Pemilihan Umum, Badan Pengawas Pemilihan Umum Provinsi, Badan Pengawas Pemilihan Umum Kabupaten/Kota Serta Pengawas Pemilu Ad Hoc.">
                            <button class="btn-remove" onclick="removeRow(this, 'dasar_hukum_container')">✕</button>
                        </div>
                        <div class="dynamic-row">
                            <span class="row-number">8.</span>
                            <input type="text" class="dasar_hukum_input" value="Surat Pengesahan Daftar Isian Pelaksanaan Anggaran Tahun Anggaran 2023 Nomor : DIPA-115.01.2.686328/2023 Revisi ke-4 tanggal 15 September 2023.">
                            <button class="btn-remove" onclick="removeRow(this, 'dasar_hukum_container')">✕</button>
                        </div>
                        <div class="dynamic-row">
                            <span class="row-number">9.</span>
                            <input type="text" class="dasar_hukum_input" value="Undangan Bawaslu Kabupaten Cilacap Nomor 307/HK.05.02/JT-07/09/2023 tanggal September 2023 terkait Kegiatan Rapat Koordinasi Kerawanan dan Potensi Pelanggaran Sosialisasi dan Kampanye Pemilu 2024.">
                            <button class="btn-remove" onclick="removeRow(this, 'dasar_hukum_container')">✕</button>
                        </div>
                    </div>
                    <button class="btn-add" onclick="addDasarHukum()">+ Tambah Dasar Hukum</button>
                </div>
            </div>

                <!-- KEPADA - DINAMIS -->
                <div class="card">
                    <div class="card-header">👤 Kepada</div>
                    <div class="card-body">
                        <div id="kepada_container">
                            <div class="dynamic-row" style="flex-wrap:wrap;">
                                <span class="row-number">1.</span>
                                <input type="text" class="kepada_nama" placeholder="Nama Pelaksana" style="flex:1;min-width:150px;">
                                <input type="text" class="kepada_jabatan" placeholder="Jabatan (mis. Staf Teknis Panwaslucam Patimuan)" style="flex:1;min-width:150px;">
                                <button class="btn-remove" onclick="removeRow(this, 'kepada_container')" style="display:none;">✕</button>
                            </div>
                        </div>
                        <button class="btn-add" onclick="addKepada()">+ Tambah Pelaksana</button>
                    </div>
                </div>

                <!-- UNTUK - 3 BARIS HARDCODE + TAMBAH -->
                <div class="card">
                    <div class="card-header">🎯 Untuk</div>
                    <div class="card-body">
                        <div id="untuk_container">
                            <div class="dynamic-row">
                                <span class="row-number">1.</span>
                                <input type="text" class="untuk_input" value="Dinas dalam rangka Rakor Kerawanan dan Potensi Pelanggaran Sosialisasi dan Kampanye Pemilu 2024 tanggal 02 Oktober 2023 di Kantor Bawaslu Kab. Cilacap">
                                <button class="btn-remove" onclick="removeRow(this, 'untuk_container')" style="display:none;">✕</button>
                            </div>
                            <div class="dynamic-row">
                                <span class="row-number">2.</span>
                                <input type="text" class="untuk_input" value="Melaporkan diri kepada Pejabat setempat guna pelaksanaan tugas tersebut;">
                                <button class="btn-remove" onclick="removeRow(this, 'untuk_container')">✕</button>
                            </div>
                            <div class="dynamic-row">
                                <span class="row-number">3.</span>
                                <input type="text" class="untuk_input" value="Dilaksanakan dengan penuh tanggung jawab.">
                                <button class="btn-remove" onclick="removeRow(this, 'untuk_container')">✕</button>
                            </div>
                        </div>
                        <button class="btn-add" onclick="addUntuk()">+ Tambah Untuk</button>
                    </div>
                </div>

                <!-- TTD -->
                <div class="card">
                    <div class="card-header">✍️ Penandatangan</div>
                    <div class="card-body">
                        <div class="grid-2">
                            <div class="form-group">
                                <label>Dikeluarkan di <span class="req">*</span></label>
                                <input type="text" id="ttd_kota" placeholder="Patimuan">
                            </div>
                            <div class="form-group">
                                <label>Pada Tanggal <span class="req">*</span></label>
                                <input type="date" id="ttd_tgl">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Nama Instansi <span class="req">*</span></label>
                            <input type="text" id="ttd_instansi" placeholder="<?= htmlspecialchars($kop_instansi) ?>" value="<?= htmlspecialchars($kop_instansi) ?>">
                        </div>
                        <div class="form-group">
                            <label>Jabatan Penandatangan <span class="req">*</span></label>
                            <input type="text" id="ttd_jabatan" placeholder="KETUA">
                        </div>
                        <div class="form-group">
                            <label>Nama Penandatangan <span class="req">*</span></label>
                            <input type="text" id="ttd_nama" placeholder="NGADIMAN">
                        </div>
                    </div>
                </div>

                <!-- LAMPIRAN (OPSIONAL) -->
                <div class="card">
                    <div class="card-header">📎 Halaman Lampiran (Opsional)</div>
                    <div class="card-body">
                        <div class="toggle-row">
                            <label class="toggle-switch">
                                <input type="checkbox" id="lampiran_enabled" onchange="toggleLampiran()">
                                <span class="toggle-slider"></span>
                            </label>
                            <span style="font-weight:600;font-size:13px;">Aktifkan Halaman Lampiran</span>
                        </div>
                        <div id="lampiran_fields" style="display:none;">
                            <div class="grid-2">
                                <div class="form-group">
                                    <label>Nomor Surat</label>
                                    <input type="text" id="lampiran_nomor_surat" placeholder="Sama dengan nomor surat tugas">
                                </div>
                                <div class="form-group">
                                    <label>Tanggal Lampiran</label>
                                    <input type="date" id="lampiran_tanggal">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Daftar Nama</label>
                                <div id="lampiran_data_container">
                                    <div class="dynamic-row" style="flex-wrap:wrap;">
                                        <span class="row-number">1.</span>
                                        <input type="text" class="lampiran_nama" placeholder="Nama" style="flex:1;min-width:130px;">
                                        <input type="text" class="lampiran_jabatan" placeholder="Jabatan" style="flex:1;min-width:130px;">
                                        <input type="text" class="lampiran_alamat" placeholder="Alamat" style="flex:1;min-width:150px;">
                                        <button class="btn-remove" onclick="removeRow(this, 'lampiran_data_container')" style="display:none;">✕</button>
                                    </div>
                                </div>
                                <button class="btn-add" onclick="addLampiranData()">+ Tambah Baris Lampiran</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- BUKTI KEHADIRAN (HALAMAN 2) -->
                <div class="card">
                    <div class="card-header">📋 Form Bukti Kehadiran (8 Jam)</div>
                    <div class="card-body">
                        <div class="alert alert-info" style="margin-bottom:12px;">
                            ⚠️ Pelaksana SPD otomatis dari data "Kepada". <br>
                            Nama Pejabat, Jabatan, Tanda Tangan dikosongkan.
                        </div>
                        <div id="kehadiran_container">
                            <div class="dynamic-row" style="flex-wrap:wrap;background:#f8f9fc;padding:6px;border-radius:4px;margin-bottom:4px;">
                                <span style="font-weight:700;min-width:30px;">No</span>
                                <span style="font-weight:700;flex:2;min-width:120px;">Pelaksana SPD</span>
                                <span style="font-weight:700;flex:1;min-width:80px;">Hari</span>
                                <span style="font-weight:700;flex:1;min-width:100px;">Tanggal</span>
                            </div>
                        </div>
                        <button class="btn-add" onclick="addKehadiran()">+ Tambah Baris Kehadiran</button>
                    </div>
                </div>

                <!-- BUTTONS -->
                <div class="btn-row">
                    <button class="btn btn-outline" onclick="resetForm()">🗑 Reset</button>
                    <button class="btn btn-secondary" onclick="saveDraft()">💾 Simpan Draf</button>
                    <button class="btn btn-primary" onclick="previewAndDownload()">👁 Preview</button>
                    <button class="btn btn-success" onclick="downloadPDF()">⬇ Download PDF</button>
                    
                    <?php if ($submission_id > 0): ?>
                        <?php 
                            $stmt = $pdo->prepare("SELECT status FROM form_submissions WHERE id = ?");
                            $stmt->execute([$submission_id]);
                            $submissionStatus = $stmt->fetchColumn();
                        ?>
                        <?php if (in_array($submissionStatus, ['draft', 'rejected', null])): ?>
                            <!-- <button class="btn btn-primary" onclick="submitForm()">📤 Kirim</button> -->
                        <?php elseif ($submissionStatus === 'submitted'): ?>
                            <button class="btn btn-warning" disabled style="opacity:0.7;">⏳ Menunggu Verifikasi</button>
                        <?php elseif ($submissionStatus === 'approved'): ?>
                            <button class="btn btn-success" disabled>✅ Disetujui</button>
                        <?php elseif ($submissionStatus === 'rejected'): ?>
                            <button class="btn btn-danger" disabled>❌ Ditolak</button>
                            <?php 
                                $stmt = $pdo->prepare("SELECT admin_note FROM form_submissions WHERE id = ?");
                                $stmt->execute([$submission_id]);
                                $note = $stmt->fetchColumn();
                            ?>
                            <?php if ($note): ?>
                                <small style="color:#C62828;display:block;margin-top:4px;">Catatan: <?= htmlspecialchars($note) ?></small>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                </div><!-- end formContainer -->
            </div><!-- end tabForm -->

            <!-- TAB PREVIEW -->
            <div id="tabPreview" style="display:none;">
                <div id="previewArea">
                    <div class="preview-toolbar">
                        <span>👁 Preview Dokumen</span>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            <button class="btn btn-outline btn-sm" onclick="switchTab('form')">← Edit</button>
                            <button class="btn btn-primary btn-sm" onclick="downloadPDF()">⬇ Download PDF</button>
                        </div>
                    </div>
                    <div class="preview-content">
                        <div id="previewDoc">
                            <p style="text-align:center;color:#9AA6C0;padding:40px 0;">Isi form lalu klik <strong>Preview</strong></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB RIWAYAT -->
            <div id="tabRiwayat" style="display:none;">
                <div class="card">
                    <div class="card-header">📋 Riwayat Submission</div>
                    <div class="card-body" id="riwayatContent">
                        <?php if (empty($submissionList)): ?>
                            <p style="text-align:center;color:#6B7A99;padding:20px;">Belum ada submission</p>
                        <?php else: ?>
                        <table class="submission-table">
                            <thead><tr><th>#</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead>
                            <tbody>
                            <?php $no=1; foreach ($submissionList as $s):
                                $statusLabel = ['draft'=>'📝 Draf','previewed'=>'👁 Preview','downloaded'=>'⬇ Downloaded','submitted'=>'📤 Terkirim','approved'=>'✅ Diterima','rejected'=>'❌ Ditolak'][$s['status']] ?? $s['status'];
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($s['created_at'])) ?></td>
                                <td><span class="status-badge <?= $s['status'] ?>"><?= $statusLabel ?></span></td>
                                <td>
                                    <button class="btn-edit" onclick="editSubmission(<?= $s['id'] ?>)">✏️ Edit</button>
                                    <button class="btn-preview" onclick="previewSubmission(<?= $s['id'] ?>)">👁 Preview</button>
                                    <button class="btn-delete" onclick="deleteSubmission(<?= $s['id'] ?>)">🗑 Hapus</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div><!-- form-container -->
    </main>
</div>

<script>
// ================================================================
// STATE
// ================================================================
var STORAGE_KEY = 'form_st_draft';
var photos = [];
var submissionId = null;

// ================================================================
// SIDEBAR TOGGLE
// ================================================================
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

// ================================================================
// HELPER - format tanggal Indonesia DD/MM/YYYY (bukan ISO)
// ================================================================
function fmtTanggalID(isoStr) {
    if (!isoStr) return '';
    var parts = isoStr.split('-');
    if (parts.length !== 3) return isoStr;
    return parts[2] + '/' + parts[1] + '/' + parts[0];
}

// ================================================================
// LAMPIRAN TOGGLE
// ================================================================
function toggleLampiran() {
    var checked = document.getElementById('lampiran_enabled').checked;
    document.getElementById('lampiran_fields').style.display = checked ? 'block' : 'none';
}

// ================================================================
// DINAMIS - DASAR HUKUM
// ================================================================
function addDasarHukum() {
    var container = document.getElementById('dasar_hukum_container');
    var rows = container.querySelectorAll('.dynamic-row');
    var num = rows.length + 1;
    var row = document.createElement('div');
    row.className = 'dynamic-row';
    row.innerHTML = `
        <span class="row-number">${num}.</span>
        <input type="text" class="dasar_hukum_input" placeholder="Peraturan ...">
        <button class="btn-remove" onclick="removeRow(this, 'dasar_hukum_container')">✕</button>
    `;
    container.appendChild(row);
    var firstRemove = container.querySelector('.dynamic-row:first-child .btn-remove');
    if (firstRemove) firstRemove.style.display = rows.length > 0 ? 'inline-block' : 'none';
}

function addKepada() {
    var container = document.getElementById('kepada_container');
    var rows = container.querySelectorAll('.dynamic-row');
    var num = rows.length + 1;
    var row = document.createElement('div');
    row.className = 'dynamic-row';
    row.style.flexWrap = 'wrap';
    row.innerHTML = `
        <span class="row-number">${num}.</span>
        <input type="text" class="kepada_nama" placeholder="Nama Pelaksana" style="flex:1;min-width:150px;">
        <input type="text" class="kepada_jabatan" placeholder="Jabatan" style="flex:1;min-width:150px;">
        <button class="btn-remove" onclick="removeRow(this, 'kepada_container')">✕</button>
    `;
    container.appendChild(row);
    var firstRemove = container.querySelector('.dynamic-row:first-child .btn-remove');
    if (firstRemove) firstRemove.style.display = rows.length > 0 ? 'inline-block' : 'none';
}

function addUntuk() {
    var container = document.getElementById('untuk_container');
    var rows = container.querySelectorAll('.dynamic-row');
    var num = rows.length + 1;
    var row = document.createElement('div');
    row.className = 'dynamic-row';
    row.innerHTML = `
        <span class="row-number">${num}.</span>
        <input type="text" class="untuk_input" placeholder="Dinas dalam rangka ...">
        <button class="btn-remove" onclick="removeRow(this, 'untuk_container')">✕</button>
    `;
    container.appendChild(row);
    var firstRemove = container.querySelector('.dynamic-row:first-child .btn-remove');
    if (firstRemove) firstRemove.style.display = rows.length > 0 ? 'inline-block' : 'none';
}

function addLampiranData() {
    var container = document.getElementById('lampiran_data_container');
    var rows = container.querySelectorAll('.dynamic-row');
    var num = rows.length + 1;
    var row = document.createElement('div');
    row.className = 'dynamic-row';
    row.style.flexWrap = 'wrap';
    row.innerHTML = `
        <span class="row-number">${num}.</span>
        <input type="text" class="lampiran_nama" placeholder="Nama" style="flex:1;min-width:130px;">
        <input type="text" class="lampiran_jabatan" placeholder="Jabatan" style="flex:1;min-width:130px;">
        <input type="text" class="lampiran_alamat" placeholder="Alamat" style="flex:1;min-width:150px;">
        <button class="btn-remove" onclick="removeRow(this, 'lampiran_data_container')">✕</button>
    `;
    container.appendChild(row);
    var firstRemove = container.querySelector('.dynamic-row:first-child .btn-remove');
    if (firstRemove) firstRemove.style.display = rows.length > 0 ? 'inline-block' : 'none';
}

function addKehadiran() {
    var container = document.getElementById('kehadiran_container');
    var dataRows = container.querySelectorAll('.dynamic-row:not(.kehadiran-header)');
    var num = dataRows.length + 1;

    var kepadaNama = document.querySelectorAll('.kepada_nama');
    var kepadaJabatan = document.querySelectorAll('.kepada_jabatan');
    var pelaksanaText = '';
    if (kepadaNama.length > 0) {
        var names = [];
        for (var i = 0; i < kepadaNama.length; i++) {
            var nama = kepadaNama[i].value.trim() || '...';
            var jabatan = kepadaJabatan[i] ? kepadaJabatan[i].value.trim() : '';
            names.push(nama + (jabatan ? ' (' + jabatan + ')' : ''));
        }
        pelaksanaText = names.join(', ');
    }

    var row = document.createElement('div');
    row.className = 'dynamic-row';
    row.style.flexWrap = 'wrap';
    row.style.background = '#fafbfd';
    row.style.padding = '6px';
    row.style.borderRadius = '4px';
    row.style.marginBottom = '4px';
    row.innerHTML = `
        <span style="font-weight:600;min-width:30px;">${num}.</span>
        <span style="flex:2;min-width:120px;font-size:12px;color:#333;">${pelaksanaText || '...'}</span>
        <input type="text" class="kehadiran_hari" placeholder="Hari" style="flex:1;min-width:80px;">
        <input type="date" class="kehadiran_tanggal" style="flex:1;min-width:100px;">
        <button class="btn-remove" onclick="removeRow(this, 'kehadiran_container')">✕</button>
    `;
    container.appendChild(row);
}

function removeRow(btn, containerId) {
    var container = document.getElementById(containerId);
    var rows = container.querySelectorAll('.dynamic-row');
    if (rows.length <= 1) {
        showToast('Minimal 1 baris!', 'warning');
        return;
    }
    var row = btn.parentElement;
    row.remove();
    var remaining = container.querySelectorAll('.dynamic-row');
    for (var i = 0; i < remaining.length; i++) {
        var numSpan = remaining[i].querySelector('.row-number');
        if (numSpan) numSpan.textContent = (i + 1) + '.';
    }
    if (remaining.length === 1) {
        var firstRemove = remaining[0].querySelector('.btn-remove');
        if (firstRemove) firstRemove.style.display = 'none';
    }
}

// ================================================================
// PHOTOS
// ================================================================
function addPhotos(e) {
    var files = Array.from(e.target.files);
    files.forEach(function(file) {
        var reader = new FileReader();
        reader.onload = function(ev) {
            photos.push({ src: ev.target.result, caption: '' });
            renderPhotos();
            saveDraft();
        };
        reader.readAsDataURL(file);
    });
    e.target.value = '';
}

function renderPhotos() {
    var grid = document.getElementById('photoGrid');
    if (!grid) return;
    grid.innerHTML = '';
    photos.forEach(function(p, i) {
        var div = document.createElement('div');
        div.className = 'photo-item';
        div.innerHTML = '<img src="' + p.src + '"><input class="caption-input" placeholder="Keterangan..." value="' + (p.caption||'') + '" onchange="photos['+i+'].caption=this.value;saveDraft();"><button class="remove-btn" onclick="removePhoto('+i+')">✕</button>';
        grid.appendChild(div);
    });
}

function removePhoto(i) { photos.splice(i,1); renderPhotos(); saveDraft(); }

// ================================================================
// GET ALL DATA
// ================================================================
function getAllData() {
    var data = {};
    data.nomor_surat = document.getElementById('nomor_surat').value;

    var dasarInputs = document.querySelectorAll('.dasar_hukum_input');
    data.dasar_hukum = [];
    dasarInputs.forEach(function(el) {
        if (el.value.trim()) data.dasar_hukum.push(el.value.trim());
    });

    var namaInputs = document.querySelectorAll('.kepada_nama');
    var jabatanInputs = document.querySelectorAll('.kepada_jabatan');
    data.kepada = [];
    for (var i = 0; i < namaInputs.length; i++) {
        var nama = namaInputs[i].value.trim();
        var jabatan = jabatanInputs[i] ? jabatanInputs[i].value.trim() : '';
        if (nama || jabatan) {
            data.kepada.push({ nama: nama, jabatan: jabatan });
        }
    }

    var untukInputs = document.querySelectorAll('.untuk_input');
    data.untuk = [];
    untukInputs.forEach(function(el) {
        if (el.value.trim()) data.untuk.push(el.value.trim());
    });

    data.ttd_kota = document.getElementById('ttd_kota').value;
    data.ttd_tgl = document.getElementById('ttd_tgl').value;
    data.ttd_instansi = document.getElementById('ttd_instansi').value;
    data.ttd_jabatan = document.getElementById('ttd_jabatan').value;
    data.ttd_nama = document.getElementById('ttd_nama').value;

    data.lampiran_enabled = document.getElementById('lampiran_enabled').checked;
    data.lampiran_nomor_surat = document.getElementById('lampiran_nomor_surat').value;
    data.lampiran_tanggal = document.getElementById('lampiran_tanggal').value;
    var lampNama = document.querySelectorAll('.lampiran_nama');
    var lampJabatan = document.querySelectorAll('.lampiran_jabatan');
    var lampAlamat = document.querySelectorAll('.lampiran_alamat');
    data.lampiran_data = [];
    for (var k = 0; k < lampNama.length; k++) {
        var lnama = lampNama[k].value.trim();
        var ljabatan = lampJabatan[k] ? lampJabatan[k].value.trim() : '';
        var lalamat = lampAlamat[k] ? lampAlamat[k].value.trim() : '';
        if (lnama || ljabatan || lalamat) {
            data.lampiran_data.push({ nama: lnama, jabatan: ljabatan, alamat: lalamat });
        }
    }

    var hariInputs = document.querySelectorAll('.kehadiran_hari');
    var tglInputs = document.querySelectorAll('.kehadiran_tanggal');
    data.kehadiran = [];
    for (var j = 0; j < hariInputs.length; j++) {
        var hari = hariInputs[j].value.trim();
        var tgl = tglInputs[j] ? tglInputs[j].value : '';
        if (hari || tgl) {
            data.kehadiran.push({ hari: hari, tanggal: tgl });
        }
    }

    data.photos = photos;
    return data;
}

// ================================================================
// SAVE DRAFT
// ================================================================
function saveDraft() {
    var data = getAllData();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    showToast('💾 Draf disimpan', 'success');
    saveToServer('draft');
}

function saveToServer(status) {
    var data = getAllData();
    fetch('api/save_submission.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            form_key: 'form_st',
            data: data,
            status: status,
            submission_id: submissionId
        })
    })
    .then(function(res) { return res.json(); })
    .then(function(result) {
        if (result.success) {
            submissionId = result.submission_id;
            var draft = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
            draft.submission_id = result.submission_id;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(draft));
        }
    })
    .catch(function() {});
}

// ================================================================
// LOAD DRAFT
// ================================================================
function loadDraft() {
    try {
        var saved = localStorage.getItem(STORAGE_KEY);
        if (!saved) return;
        var data = JSON.parse(saved);

        document.getElementById('nomor_surat').value = data.nomor_surat || '';

        if (data.dasar_hukum && data.dasar_hukum.length > 0) {
            var dhContainer = document.getElementById('dasar_hukum_container');
            dhContainer.innerHTML = '';
            data.dasar_hukum.forEach(function(text, i) {
                var row = document.createElement('div');
                row.className = 'dynamic-row';
                row.innerHTML = `
                    <span class="row-number">${i+1}.</span>
                    <input type="text" class="dasar_hukum_input" value="${text.replace(/"/g, '&quot;')}" placeholder="Peraturan ...">
                    <button class="btn-remove" onclick="removeRow(this, 'dasar_hukum_container')" style="${i===0?'display:none;':''}">✕</button>
                `;
                dhContainer.appendChild(row);
            });
        }

        if (data.kepada && data.kepada.length > 0) {
            var kContainer = document.getElementById('kepada_container');
            kContainer.innerHTML = '';
            data.kepada.forEach(function(item, i) {
                var row = document.createElement('div');
                row.className = 'dynamic-row';
                row.style.flexWrap = 'wrap';
                row.innerHTML = `
                    <span class="row-number">${i+1}.</span>
                    <input type="text" class="kepada_nama" value="${item.nama.replace(/"/g, '&quot;')}" placeholder="Nama Pelaksana" style="flex:1;min-width:150px;">
                    <input type="text" class="kepada_jabatan" value="${item.jabatan.replace(/"/g, '&quot;')}" placeholder="Jabatan" style="flex:1;min-width:150px;">
                    <button class="btn-remove" onclick="removeRow(this, 'kepada_container')" style="${i===0?'display:none;':''}">✕</button>
                `;
                kContainer.appendChild(row);
            });
        }

        if (data.untuk && data.untuk.length > 0) {
            var uContainer = document.getElementById('untuk_container');
            uContainer.innerHTML = '';
            data.untuk.forEach(function(text, i) {
                var row = document.createElement('div');
                row.className = 'dynamic-row';
                row.innerHTML = `
                    <span class="row-number">${i+1}.</span>
                    <input type="text" class="untuk_input" value="${text.replace(/"/g, '&quot;')}" placeholder="Dinas dalam rangka ...">
                    <button class="btn-remove" onclick="removeRow(this, 'untuk_container')" style="${i===0?'display:none;':''}">✕</button>
                `;
                uContainer.appendChild(row);
            });
        }

        document.getElementById('ttd_kota').value = data.ttd_kota || '';
        document.getElementById('ttd_tgl').value = data.ttd_tgl || '';
        document.getElementById('ttd_instansi').value = data.ttd_instansi || document.getElementById('ttd_instansi').value;
        document.getElementById('ttd_jabatan').value = data.ttd_jabatan || '';
        document.getElementById('ttd_nama').value = data.ttd_nama || '';

        document.getElementById('lampiran_enabled').checked = !!data.lampiran_enabled;
        document.getElementById('lampiran_nomor_surat').value = data.lampiran_nomor_surat || '';
        document.getElementById('lampiran_tanggal').value = data.lampiran_tanggal || '';
        toggleLampiran();
        if (data.lampiran_data && data.lampiran_data.length > 0) {
            var lContainer = document.getElementById('lampiran_data_container');
            lContainer.innerHTML = '';
            data.lampiran_data.forEach(function(item, i) {
                var row = document.createElement('div');
                row.className = 'dynamic-row';
                row.style.flexWrap = 'wrap';
                row.innerHTML = `
                    <span class="row-number">${i+1}.</span>
                    <input type="text" class="lampiran_nama" value="${(item.nama||'').replace(/"/g, '&quot;')}" placeholder="Nama" style="flex:1;min-width:130px;">
                    <input type="text" class="lampiran_jabatan" value="${(item.jabatan||'').replace(/"/g, '&quot;')}" placeholder="Jabatan" style="flex:1;min-width:130px;">
                    <input type="text" class="lampiran_alamat" value="${(item.alamat||'').replace(/"/g, '&quot;')}" placeholder="Alamat" style="flex:1;min-width:150px;">
                    <button class="btn-remove" onclick="removeRow(this, 'lampiran_data_container')" style="${i===0?'display:none;':''}">✕</button>
                `;
                lContainer.appendChild(row);
            });
        }

        if (data.kehadiran && data.kehadiran.length > 0) {
            var khContainer = document.getElementById('kehadiran_container');
            khContainer.innerHTML = '';
            // header
            var header = document.createElement('div');
            header.className = 'dynamic-row';
            header.style.flexWrap = 'wrap';
            header.style.background = '#f8f9fc';
            header.style.padding = '6px';
            header.style.borderRadius = '4px';
            header.style.marginBottom = '4px';
            header.innerHTML = `
                <span style="font-weight:700;min-width:30px;">No</span>
                <span style="font-weight:700;flex:2;min-width:120px;">Pelaksana SPD</span>
                <span style="font-weight:700;flex:1;min-width:80px;">Hari</span>
                <span style="font-weight:700;flex:1;min-width:100px;">Tanggal</span>
            `;
            khContainer.appendChild(header);

            var kepadaNamaLoad = data.kepada || [];
            data.kehadiran.forEach(function(item, i) {
                var pelaksanaLabel = '...';
                if (kepadaNamaLoad.length > 0) {
                    var names = kepadaNamaLoad.map(function(k){ return k.nama + (k.jabatan ? ' (' + k.jabatan + ')' : ''); });
                    pelaksanaLabel = names.join(', ');
                }
                var row = document.createElement('div');
                row.className = 'dynamic-row';
                row.style.flexWrap = 'wrap';
                row.style.background = '#fafbfd';
                row.style.padding = '6px';
                row.style.borderRadius = '4px';
                row.style.marginBottom = '4px';
                row.innerHTML = `
                    <span style="font-weight:600;min-width:30px;">${i+1}.</span>
                    <span style="flex:2;min-width:120px;font-size:12px;color:#333;">${pelaksanaLabel}</span>
                    <input type="text" class="kehadiran_hari" value="${item.hari.replace(/"/g, '&quot;')}" placeholder="Hari" style="flex:1;min-width:80px;">
                    <input type="date" class="kehadiran_tanggal" value="${item.tanggal}" style="flex:1;min-width:100px;">
                    <button class="btn-remove" onclick="removeRow(this, 'kehadiran_container')">✕</button>
                `;
                khContainer.appendChild(row);
            });
        }

        if (data.photos) { photos = data.photos; renderPhotos(); }
        if (data.submission_id) submissionId = data.submission_id;
    } catch(e) {}
}

// ================================================================
// RESET
// ================================================================
function resetForm() {
    if (!confirm('Reset semua data?')) return;
    localStorage.removeItem(STORAGE_KEY);
    location.reload();
}

// ================================================================
// PREVIEW
// ================================================================
function previewAndDownload() {
    saveDraft();
    generatePreview();
    switchTab('preview');
    saveToServer('previewed');
}

function generatePreview() {
    var html = buildPDFHTML();
    document.getElementById('previewDoc').innerHTML = html;
}

// ================================================================
// BUILD PDF HTML - PREVIEW (2-3 Halaman) - dengan struktur tabel rapi seperti Doc 2
// ================================================================
function buildPDFHTML() {
    function v(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }
    function esc(s) { return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
    function fdate(s) { if(!s) return ''; var d=new Date(s); var M=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']; return d.getDate()+' '+M[d.getMonth()]+' '+d.getFullYear(); }

    var dasarHukum = [];
    document.querySelectorAll('.dasar_hukum_input').forEach(function(el) {
        if (el.value.trim()) dasarHukum.push(esc(el.value.trim()));
    });

    var kepada = [];
    var namaEls = document.querySelectorAll('.kepada_nama');
    var jabatanEls = document.querySelectorAll('.kepada_jabatan');
    for (var i = 0; i < namaEls.length; i++) {
        var nama = namaEls[i].value.trim();
        var jabatan = jabatanEls[i] ? jabatanEls[i].value.trim() : '';
        if (nama || jabatan) {
            kepada.push({ nama: esc(nama), jabatan: esc(jabatan) });
        }
    }

    var untuk = [];
    document.querySelectorAll('.untuk_input').forEach(function(el) {
        if (el.value.trim()) untuk.push(esc(el.value.trim()));
    });

    var lampiranEnabled = document.getElementById('lampiran_enabled').checked;
    var lampiranNomorSurat = esc(v('lampiran_nomor_surat'));
    var lampiranTanggal = fdate(v('lampiran_tanggal'));
    var lampiranData = [];
    var lampNamaEls = document.querySelectorAll('.lampiran_nama');
    var lampJabatanEls = document.querySelectorAll('.lampiran_jabatan');
    var lampAlamatEls = document.querySelectorAll('.lampiran_alamat');
    for (var m = 0; m < lampNamaEls.length; m++) {
        var lnama = lampNamaEls[m].value.trim();
        var ljabatan = lampJabatanEls[m] ? lampJabatanEls[m].value.trim() : '';
        var lalamat = lampAlamatEls[m] ? lampAlamatEls[m].value.trim() : '';
        if (lnama || ljabatan || lalamat) {
            lampiranData.push({ nama: esc(lnama), jabatan: esc(ljabatan), alamat: esc(lalamat) });
        }
    }

    var kehadiran = [];
    var hariEls = document.querySelectorAll('.kehadiran_hari');
    var tglEls = document.querySelectorAll('.kehadiran_tanggal');
    for (var j = 0; j < hariEls.length; j++) {
        var hari = hariEls[j].value.trim();
        var tgl = tglEls[j] ? tglEls[j].value : '';
        if (hari || tgl) {
            kehadiran.push({ hari: esc(hari), tanggal: tgl });
        }
    }

    var nomorSurat = esc(v('nomor_surat'));
    var ttdKota = esc(v('ttd_kota'));
    var ttdTgl = fdate(v('ttd_tgl'));
    var ttdInstansi = esc(v('ttd_instansi'));
    var ttdJabatan = esc(v('ttd_jabatan'));
    var ttdNama = esc(v('ttd_nama'));

    function buildKop() {
        var html = '<div class="kop">';
        if ('<?= $kop_logo ?>') html += '<img src="<?= $kop_logo ?>">';
        html += '<div class="instansi"><?= htmlspecialchars($kop_instansi) ?></div>';
        if ('<?= $kop_alamat ?>') html += '<div class="alamat">Sekretariat : <?= htmlspecialchars($kop_alamat) ?></div>';
        if ('<?= $kop_telp ?>') html += '<div class="alamat">Telp : <?= htmlspecialchars($kop_telp) ?></div>';
        if ('<?= $kop_email ?>') html += '<div class="alamat">Email : <?= htmlspecialchars($kop_email) ?></div>';
        if ('<?= $kop_website ?>') html += '<div class="alamat">Website : <?= htmlspecialchars($kop_website) ?></div>';
        html += '<hr style="border:2px solid #000;margin:4px 0;">';
        html += '<hr style="border:2px solid #000;margin:2px 0 8px 0;">';
        html += '</div>';
        return html;
    }

    var html = '';

    // HALAMAN 1
    html += '<div class="pdf-page">';
    html += buildKop();
    html += '<div class="pdf-title">SURAT TUGAS</div>';
    html += '<p style="text-align:center;margin-bottom:8px;">Nomor : ' + (nomorSurat || '-') + '</p>';

    if (dasarHukum.length > 0) {
        html += '<div class="pdf-section">Dasar :</div>';
        // Hanging indent: nomor di kolom kiri kecil, teks (termasuk baris lanjutan yang wrap)
        // otomatis sejajar dengan awal teks, bukan sejajar dengan nomor — karena ini 1 sel <td>.
        html += '<table style="width:100%;border-collapse:collapse;margin-bottom:8px;">';
        dasarHukum.forEach(function(item, idx) {
            html += '<tr>';
            html += '<td style="width:22px;vertical-align:top;padding:2px 0;white-space:nowrap;">' + (idx+1) + '.</td>';
            html += '<td style="text-align:justify;vertical-align:top;padding:2px 0;">' + item + '</td>';
            html += '</tr>';
        });
        html += '</table>';
    }

    html += '<div style="text-align:center;font-weight:700;font-size:11pt;margin:8px 0 4px;">MENUGASKAN :</div>';

    if (kepada.length > 0) {
        html += '<table style="width:100%;border-collapse:collapse;margin-bottom:6px;">';
        html += '<tr><td style="width:60px;vertical-align:top;padding:2px 0;">Kepada</td><td style="width:10px;vertical-align:top;">:</td><td style="vertical-align:top;">';
        kepada.forEach(function(item, idx) {
            html += '<table style="border-collapse:collapse;margin-bottom:4px;">';
            html += '<tr>';
            html += '<td style="width:18px;vertical-align:top;padding:0;">' + (idx+1) + '.</td>';
            html += '<td style="width:95px;vertical-align:top;padding:0;">Nama Lengkap</td>';
            html += '<td style="width:12px;vertical-align:top;padding:0;">:</td>';
            html += '<td style="vertical-align:top;padding:0;">' + (item.nama || '..................') + '</td>';
            html += '</tr>';
            html += '<tr>';
            html += '<td style="padding:0;"></td>';
            html += '<td style="width:95px;vertical-align:top;padding:0;">Jabatan</td>';
            html += '<td style="width:12px;vertical-align:top;padding:0;">:</td>';
            html += '<td style="vertical-align:top;padding:0;">' + (item.jabatan || '..................') + '</td>';
            html += '</tr>';
            html += '</table>';
        });
        html += '</td></tr></table>';
    }

    if (untuk.length > 0) {
        html += '<table style="width:100%;border-collapse:collapse;margin-bottom:6px;">';
        html += '<tr><td style="width:60px;vertical-align:top;padding:2px 0;">Untuk</td><td style="width:10px;vertical-align:top;">:</td><td style="vertical-align:top;">';
        untuk.forEach(function(item, idx) {
            html += '<div style="margin-bottom:4px;">' + (idx+1) + '. ' + item + '</div>';
        });
        html += '</td></tr></table>';
    }

    // Blok TTD - persis pola Doc 2: tanggal/kota di kanan atas blok,
    // lalu instansi (dari field Nama Instansi) + kabupaten + jabatan (bold, center dalam blok), lalu nama (bold, underline)
    html += '<table style="width:100%;border-collapse:collapse;margin-top:16px;"><tr><td style="width:55%;"></td><td style="width:45%;text-align:left;">';
    html += '<div>Dikeluarkan di : ' + (ttdKota || '-') + '</div>';
    html += '<div>Pada tanggal &nbsp;: ' + (ttdTgl || '-') + '</div>';
    html += '<div style="text-align:center;margin-top:6px;">';
    html += '<div style="font-weight:700;">' + (ttdInstansi || '<?= htmlspecialchars($kop_instansi) ?>') + '</div>';
    html += '<div style="font-weight:700;">' + '<?= htmlspecialchars($kop_kabupaten) ?>' + '</div>';
    html += '<div style="font-weight:700;">' + (ttdJabatan || 'KETUA') + ',</div>';
    html += '<div style="margin-top:32px;font-weight:700;text-decoration:underline;">' + (ttdNama || '-') + '</div>';
    html += '</div>';
    html += '</td></tr></table>';
    html += '</div>'; // end halaman 1

    // HALAMAN LAMPIRAN (OPSIONAL)
    if (lampiranEnabled) {
        html += '<div class="pdf-page">';
        html += buildKop();
        html += '<div style="text-align:right;margin-bottom:10px;">';
        html += '<div style="font-weight:700;">LAMPIRAN</div>';
        html += '<div>Nomor : ' + (lampiranNomorSurat || '-') + '</div>';
        html += '<div>Tanggal : ' + (lampiranTanggal || '-') + '</div>';
        html += '</div>';
        if (lampiranData.length > 0) {
            html += '<table class="pdf-tbl">';
            html += '<tr><th style="width:8%;">No</th><th style="width:30%;">Nama</th><th style="width:30%;">Jabatan</th><th style="width:32%;">Alamat</th></tr>';
            lampiranData.forEach(function(item, idx) {
                html += '<tr>';
                html += '<td style="text-align:center;">' + (idx+1) + '</td>';
                html += '<td>' + (item.nama || '-') + '</td>';
                html += '<td>' + (item.jabatan || '-') + '</td>';
                html += '<td>' + (item.alamat || '-') + '</td>';
                html += '</tr>';
            });
            html += '</table>';
        } else {
            html += '<p style="text-align:center;color:#999;padding:20px;">Belum ada data lampiran</p>';
        }
        html += '</div>'; // end halaman lampiran
    }

    // HALAMAN FORM 8 JAM KHUSUS LAMPIRAN (1 NAMA = 1 HALAMAN)
    if (lampiranEnabled && lampiranData.length > 0) {
        function buildKehadiranPersonPageHTML(personLabel) {
            var ph = '<div class="pdf-page">';
            ph += buildKop();
            ph += '<div style="text-align:center;font-weight:700;font-size:11pt;margin-bottom:8px;">';
            ph += 'Form Bukti Kehadiran Pelaksanaan Perjalanan Dinas Jabatan<br>';
            ph += 'Dalam Kota Sampai dengan 8 (Delapan) Jam';
            ph += '</div>';

            if (kehadiran.length > 0) {
                ph += '<table class="pdf-tbl">';
                ph += '<tr>';
                ph += '<th rowspan="2" style="width:6%;">No</th>';
                ph += '<th rowspan="2" style="width:28%;">Pelaksana SPD</th>';
                ph += '<th rowspan="2" style="width:14%;">Hari</th>';
                ph += '<th rowspan="2" style="width:14%;">Tanggal</th>';
                ph += '<th colspan="3" style="width:38%;">Pejabat/Petugas Yang Mengesahkan</th>';
                ph += '</tr>';
                ph += '<tr>';
                ph += '<th style="width:14%;">Nama</th>';
                ph += '<th style="width:12%;">Jabatan</th>';
                ph += '<th style="width:12%;">Tanda Tangan</th>';
                ph += '</tr>';
                ph += '<tr>';
                for (var c = 1; c <= 7; c++) { ph += '<th style="font-weight:400;">' + c + '</th>'; }
                ph += '</tr>';

                kehadiran.forEach(function(item, idx) {
                    var tglFormatted = item.tanggal ? fmtTanggalID(item.tanggal) : '-';
                    ph += '<tr>';
                    ph += '<td class="data-row" style="text-align:center;">' + (idx+1) + '</td>';
                    ph += '<td class="data-row">' + personLabel + '</td>';
                    ph += '<td class="data-row" style="text-align:center;">' + (item.hari || '-') + '</td>';
                    ph += '<td class="data-row" style="text-align:center;">' + tglFormatted + '</td>';
                    ph += '<td class="data-row">&nbsp;</td>';
                    ph += '<td class="data-row">&nbsp;</td>';
                    ph += '<td class="data-row">&nbsp;</td>';
                    ph += '</tr>';
                });
                for (var r = 0; r < 3; r++) {
                    ph += '<tr><td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td></tr>';
                }
                ph += '</table>';
            } else {
                ph += '<p style="text-align:center;color:#999;padding:20px;">Belum ada data kehadiran</p>';
            }
            ph += '</div>';
            return ph;
        }

        lampiranData.forEach(function(litem) {
            var personLabel = (litem.nama || '-') + (litem.jabatan ? '<br><span style="font-size:8pt;color:#555;">(' + litem.jabatan + ')</span>' : '');
            html += buildKehadiranPersonPageHTML(personLabel);
        });
    }

    // HALAMAN 2 (KEHADIRAN)
    html += '<div class="pdf-page">';
    html += buildKop();
    html += '<div style="text-align:center;font-weight:700;font-size:11pt;margin-bottom:8px;">';
    html += 'Form Bukti Kehadiran Pelaksanaan Perjalanan Dinas Jabatan<br>';
    html += 'Dalam Kota Sampai dengan 8 (Delapan) Jam';
    html += '</div>';

    if (kehadiran.length > 0) {
        var pelaksanaNames = [];
        kepada.forEach(function(item) {
            pelaksanaNames.push(item.nama + (item.jabatan ? '<br><span style="font-size:8pt;color:#555;">(' + item.jabatan + ')</span>' : ''));
        });

        html += '<table class="pdf-tbl">';
        // baris 1: header judul kolom (dengan rowspan utk No, Pelaksana, Hari, Tanggal; colspan utk Pengesahan)
        html += '<tr>';
        html += '<th rowspan="2" style="width:6%;">No</th>';
        html += '<th rowspan="2" style="width:28%;">Pelaksana SPD</th>';
        html += '<th rowspan="2" style="width:14%;">Hari</th>';
        html += '<th rowspan="2" style="width:14%;">Tanggal</th>';
        html += '<th colspan="3" style="width:38%;">Pejabat/Petugas Yang Mengesahkan</th>';
        html += '</tr>';
        // baris 2: sub-header
        html += '<tr>';
        html += '<th style="width:14%;">Nama</th>';
        html += '<th style="width:12%;">Jabatan</th>';
        html += '<th style="width:12%;">Tanda Tangan</th>';
        html += '</tr>';
        // baris 3: nomor kolom (1-7), seperti Doc 2
        html += '<tr>';
        for (var c = 1; c <= 7; c++) {
            html += '<th style="font-weight:400;">' + c + '</th>';
        }
        html += '</tr>';

        kehadiran.forEach(function(item, idx) {
            var pelaksanaText = pelaksanaNames[idx] || pelaksanaNames[0] || '-';
            var tglFormatted = item.tanggal ? fmtTanggalID(item.tanggal) : '-';
            html += '<tr>';
            html += '<td class="data-row" style="text-align:center;">' + (idx+1) + '</td>';
            html += '<td class="data-row">' + pelaksanaText + '</td>';
            html += '<td class="data-row" style="text-align:center;">' + (item.hari || '-') + '</td>';
            html += '<td class="data-row" style="text-align:center;">' + tglFormatted + '</td>';
            html += '<td class="data-row">&nbsp;</td>';
            html += '<td class="data-row">&nbsp;</td>';
            html += '<td class="data-row">&nbsp;</td>';
            html += '</tr>';
        });
        // baris kosong cadangan (mengikuti gaya Doc 2), tinggi sama dgn baris data supaya muat cap
        for (var r = 0; r < 3; r++) {
            html += '<tr>';
            html += '<td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td><td class="data-row">&nbsp;</td>';
            html += '</tr>';
        }
        html += '</table>';
    } else {
        html += '<p style="text-align:center;color:#999;padding:20px;">Belum ada data kehadiran</p>';
    }

    html += '</div>'; // end halaman 2

    // DOKUMENTASI
    if (photos.length > 0) {
        html += '<div class="pdf-page" style="text-align:center;">';
        html += buildKop();
        html += '<div class="pdf-foto-title">DOKUMENTASI KEGIATAN</div>';
        html += '<div class="pdf-foto-grid">';
        photos.forEach(function(p) {
            html += '<div class="pdf-foto-item"><img src="'+p.src+'"><p>'+esc(p.caption||'')+'</p></div>';
        });
        html += '</div>';
        html += '</div>';
    }

    return html;
}

// ================================================================
// DOWNLOAD PDF - JSPDF (struktur tabel diperbaiki: header 2 lapis + nomor kolom, tanggal DD/MM/YYYY)
// ================================================================
function downloadPDF() {
    saveToServer('downloaded');

    function v(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }
    function esc(s) { return s || ''; }
    function fdate(s) { if(!s) return ''; var d=new Date(s); var M=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']; return d.getDate()+' '+M[d.getMonth()]+' '+d.getFullYear(); }

    // Ambil data dinamis
    var dasarHukum = [];
    document.querySelectorAll('.dasar_hukum_input').forEach(function(el) {
        if (el.value.trim()) dasarHukum.push(esc(el.value.trim()));
    });

    var kepada = [];
    var namaEls = document.querySelectorAll('.kepada_nama');
    var jabatanEls = document.querySelectorAll('.kepada_jabatan');
    for (var i = 0; i < namaEls.length; i++) {
        var nama = namaEls[i].value.trim();
        var jabatan = jabatanEls[i] ? jabatanEls[i].value.trim() : '';
        if (nama || jabatan) {
            kepada.push({ nama: esc(nama), jabatan: esc(jabatan) });
        }
    }

    var untuk = [];
    document.querySelectorAll('.untuk_input').forEach(function(el) {
        if (el.value.trim()) untuk.push(esc(el.value.trim()));
    });

    var lampiranEnabled = document.getElementById('lampiran_enabled').checked;
    var lampiranNomorSurat = esc(v('lampiran_nomor_surat'));
    var lampiranTanggal = fdate(v('lampiran_tanggal'));
    var lampiranData = [];
    var lampNamaEls = document.querySelectorAll('.lampiran_nama');
    var lampJabatanEls = document.querySelectorAll('.lampiran_jabatan');
    var lampAlamatEls = document.querySelectorAll('.lampiran_alamat');
    for (var m = 0; m < lampNamaEls.length; m++) {
        var lnama = lampNamaEls[m].value.trim();
        var ljabatan = lampJabatanEls[m] ? lampJabatanEls[m].value.trim() : '';
        var lalamat = lampAlamatEls[m] ? lampAlamatEls[m].value.trim() : '';
        if (lnama || ljabatan || lalamat) {
            lampiranData.push({ nama: esc(lnama), jabatan: esc(ljabatan), alamat: esc(lalamat) });
        }
    }

    var kehadiran = [];
    var hariEls = document.querySelectorAll('.kehadiran_hari');
    var tglEls = document.querySelectorAll('.kehadiran_tanggal');
    for (var j = 0; j < hariEls.length; j++) {
        var hari = hariEls[j].value.trim();
        var tgl = tglEls[j] ? tglEls[j].value : '';
        if (hari || tgl) {
            kehadiran.push({ hari: hari, tanggal: tgl });
        }
    }

    var nomorSurat = esc(v('nomor_surat'));
    var ttdKota = esc(v('ttd_kota'));
    var ttdTgl = fdate(v('ttd_tgl'));
    var ttdInstansi = esc(v('ttd_instansi'));
    var ttdJabatan = esc(v('ttd_jabatan'));
    var ttdNama = esc(v('ttd_nama'));
    var foto_judul = esc(v('foto_judul'));

    var pdf = new jspdf.jsPDF('p', 'mm', [210, 330]);
    var pdfWidth = pdf.internal.pageSize.getWidth();
    var pdfHeight = pdf.internal.pageSize.getHeight();
    var margin = 15; // margin diperbesar supaya tabel tidak "bleber" ke tepi
    var contentWidth = pdfWidth - (margin * 2);
    var y = margin;

    // fungsi bantu untuk menggambar kop surat (dipakai ulang di setiap halaman)
    function drawKop() {
        var logoUrl = '<?= $kop_logo ?>';
        if (logoUrl) {
            try {
                pdf.addImage(logoUrl, 'JPEG', margin, y, 170, 25);
                y += 20;
            } catch(e) {
                console.log('Logo tidak bisa dimuat: ' + e.message);
                y += 5;
            }
        }
        pdf.setFontSize(12);
        pdf.setFont('times', 'bold');
        pdf.text('<?= htmlspecialchars($kop_instansi) ?>', pdfWidth/2, y + 4, { align: 'center' });
        y += 10;
        pdf.setFontSize(8);
        pdf.setFont('times', 'normal');
        var alamatKopLocal = '<?= htmlspecialchars($kop_alamat) ?>';
        if (alamatKopLocal) { pdf.text('Sekretariat : ' + alamatKopLocal, pdfWidth/2, y, { align: 'center' }); y += 4; }
        var telpKopLocal = '<?= htmlspecialchars($kop_telp) ?>';
        if (telpKopLocal) { pdf.text('Telp : ' + telpKopLocal, pdfWidth/2, y, { align: 'center' }); y += 4; }
        var emailKopLocal = '<?= htmlspecialchars($kop_email) ?>';
        if (emailKopLocal) { pdf.text('Email : ' + emailKopLocal, pdfWidth/2, y, { align: 'center' }); y += 4; }
        var webKopLocal = '<?= htmlspecialchars($kop_website) ?>';
        if (webKopLocal) { pdf.text('Website : ' + webKopLocal, pdfWidth/2, y, { align: 'center' }); y += 4; }
        y += 2;
        pdf.setLineWidth(1);
        pdf.line(margin, y, pdfWidth - margin, y);
        y += 1;
        pdf.setLineWidth(0.3);
        pdf.line(margin, y, pdfWidth - margin, y);
        y += 8;
    }

    drawKop();

    pdf.setFontSize(12);
    pdf.setFont('times', 'bold');
    pdf.text('SURAT TUGAS', pdfWidth/2, y, { align: 'center' });
    y += 6;

    pdf.setFontSize(9);
    pdf.setFont('times', 'normal');
    pdf.text('Nomor : ' + (nomorSurat || '-'), pdfWidth/2, y, { align: 'center' });
    y += 8;

    // Dasar - hanging indent: nomor di kiri, baris lanjutan sejajar dengan AWAL TEKS (bukan sejajar nomor)
    if (dasarHukum.length > 0) {
        pdf.setFont('times', 'bold');
        pdf.text('Dasar :', margin, y);
        y += 6;
        pdf.setFont('times', 'normal');
        dasarHukum.forEach(function(item, idx) {
            var numberLabel = (idx+1) + '. ';
            var numWidth = pdf.getTextWidth(numberLabel);
            var indentX = margin + 5;
            var textX = indentX + numWidth;
            var maxWidth = contentWidth - 10 - numWidth;
            var split = pdf.splitTextToSize(item, maxWidth);
            if (y + (split.length * 5) > pdfHeight - margin) { pdf.addPage(); y = margin; }
            pdf.text(numberLabel, indentX, y);
            pdf.text(split, textX, y);
            y += (split.length * 5) + 2;
        });
        y += 4;
    }

    // MENUGASKAN - center
    if (y + 20 > pdfHeight - margin) { pdf.addPage(); y = margin; }
    pdf.setFont('times', 'bold');
    pdf.text('MENUGASKAN :', pdfWidth / 2, y, { align: 'center' });
    y += 6;
    pdf.setFont('times', 'normal');

    // Kepada - nama & jabatan disejajarkan pakai kolom X tetap agar tanda titik dua rapi
    if (kepada.length > 0) {
        pdf.text('Kepada :', margin + 5, y);
        y += 5;
        var kepadaNoX = margin + 10;
        var kepadaLabelX = margin + 16;
        var kepadaColonX = margin + 48;
        var kepadaValueX = margin + 52;
        kepada.forEach(function(item, idx) {
            if (y + 10 > pdfHeight - margin) { pdf.addPage(); y = margin; }
            pdf.text((idx+1) + '.', kepadaNoX, y);
            pdf.text('Nama Lengkap', kepadaLabelX, y);
            pdf.text(':', kepadaColonX, y);
            pdf.text(item.nama || '..................', kepadaValueX, y);
            y += 5;
            pdf.text('Jabatan', kepadaLabelX, y);
            pdf.text(':', kepadaColonX, y);
            pdf.text(item.jabatan || '..................', kepadaValueX, y);
            y += 5;
        });
        y += 4;
    }

    // Untuk
    if (untuk.length > 0) {
        pdf.text('Untuk :', margin + 5, y);
        y += 5;
        untuk.forEach(function(item, idx) {
            var numberLabel = (idx+1) + '. ';
            var numWidth = pdf.getTextWidth(numberLabel);
            var indentX = margin + 10;
            var textX = indentX + numWidth;
            var split = pdf.splitTextToSize(item, contentWidth - 20 - numWidth);
            if (y + (split.length * 5) > pdfHeight - margin) { pdf.addPage(); y = margin; }
            pdf.text(numberLabel, indentX, y);
            pdf.text(split, textX, y);
            y += (split.length * 5) + 2;
        });
        y += 4;
    }

    // TTD - blok mengikuti pola Doc 2: tanggal/kota rata kiri dlm blok kanan,
    // lalu instansi (dari field Nama Instansi) + kabupaten + jabatan (bold, CENTER dalam blok), lalu nama (bold, underline, center)
    if (y + 45 > pdfHeight - margin) { pdf.addPage(); y = margin; }
    pdf.setFont('times', 'normal');
    pdf.setFontSize(9);
    var ttdBlockWidth = 75;
    var ttdBlockX = pdfWidth - margin - ttdBlockWidth;
    var ttdBlockCenter = ttdBlockX + (ttdBlockWidth / 2);
    pdf.text('Dikeluarkan di : ' + (ttdKota || '-'), ttdBlockX, y);
    y += 6;
    pdf.text('Pada tanggal   : ' + (ttdTgl || '-'), ttdBlockX, y);
    y += 8;
    pdf.setFont('times', 'bold');
    pdf.text(ttdInstansi || '<?= htmlspecialchars($kop_instansi) ?>', ttdBlockCenter, y, { align: 'center' });
    y += 5;
    pdf.text('<?= htmlspecialchars($kop_kabupaten) ?>', ttdBlockCenter, y, { align: 'center' });
    y += 5;
    pdf.text((ttdJabatan || 'KETUA') + ',', ttdBlockCenter, y, { align: 'center' });
    y += 22;
    pdf.text(ttdNama || '-', ttdBlockCenter, y, { align: 'center' });
    pdf.setFont('times', 'normal');

    // ===== HALAMAN LAMPIRAN (OPSIONAL) =====
    if (lampiranEnabled) {
        pdf.addPage();
        y = margin;
        drawKop();

        // rata kanan: LAMPIRAN / Nomor / Tanggal
        pdf.setFontSize(10);
        pdf.setFont('times', 'bold');
        pdf.text('LAMPIRAN', pdfWidth - margin, y, { align: 'right' });
        y += 6;
        pdf.setFont('times', 'normal');
        pdf.setFontSize(9);
        pdf.text('Nomor  : ' + (lampiranNomorSurat || '-'), pdfWidth - margin, y, { align: 'right' });
        y += 5;
        pdf.text('Tanggal : ' + (lampiranTanggal || '-'), pdfWidth - margin, y, { align: 'right' });
        y += 10;

        // tabel No / Nama / Jabatan / Alamat
        var lCol1 = contentWidth * 0.08;
        var lCol2 = contentWidth * 0.30;
        var lCol3 = contentWidth * 0.28;
        var lCol4 = contentWidth * 0.34;
        var lRowHeader = 8;
        var lStartX = margin;

        function drawLampiranHeader() {
            pdf.setFontSize(8);
            pdf.setFont('times', 'bold');
            var x = lStartX;
            pdf.rect(x, y, lCol1, lRowHeader);
            pdf.text('No', x + lCol1/2, y + lRowHeader/2 + 1.5, { align: 'center' });
            x += lCol1;
            pdf.rect(x, y, lCol2, lRowHeader);
            pdf.text('Nama', x + lCol2/2, y + lRowHeader/2 + 1.5, { align: 'center' });
            x += lCol2;
            pdf.rect(x, y, lCol3, lRowHeader);
            pdf.text('Jabatan', x + lCol3/2, y + lRowHeader/2 + 1.5, { align: 'center' });
            x += lCol3;
            pdf.rect(x, y, lCol4, lRowHeader);
            pdf.text('Alamat', x + lCol4/2, y + lRowHeader/2 + 1.5, { align: 'center' });
            y += lRowHeader;
            pdf.setFont('times', 'normal');
        }

        drawLampiranHeader();

        var lampCount = Math.max(lampiranData.length, 1);
        for (var li = 0; li < lampCount; li++) {
            var litem = lampiranData[li];
            var namaSplit = pdf.splitTextToSize(litem ? (litem.nama || '-') : '-', lCol2 - 4);
            var jabatanSplit = pdf.splitTextToSize(litem ? (litem.jabatan || '-') : '-', lCol3 - 4);
            var alamatSplit = pdf.splitTextToSize(litem ? (litem.alamat || '-') : '-', lCol4 - 4);
            var linesCount = Math.max(namaSplit.length, jabatanSplit.length, alamatSplit.length, 1);
            var lRowH = Math.max(8, linesCount * 4 + 2);

            if (y + lRowH > pdfHeight - margin) {
                pdf.addPage();
                y = margin;
                drawKop();
                drawLampiranHeader();
            }

            pdf.setFontSize(8);
            var x = lStartX;
            pdf.rect(x, y, lCol1, lRowH);
            pdf.text((li+1).toString(), x + lCol1/2, y + 5, { align: 'center' });
            x += lCol1;
            pdf.rect(x, y, lCol2, lRowH);
            pdf.text(namaSplit, x + 2, y + 5);
            x += lCol2;
            pdf.rect(x, y, lCol3, lRowH);
            pdf.text(jabatanSplit, x + 2, y + 5);
            x += lCol3;
            pdf.rect(x, y, lCol4, lRowH);
            pdf.text(alamatSplit, x + 2, y + 5);
            y += lRowH;
        }
    }

    // ===== HALAMAN FORM 8 JAM KHUSUS LAMPIRAN (1 NAMA = 1 HALAMAN) =====
    if (lampiranEnabled && lampiranData.length > 0) {
        (function drawKehadiranLampiranPages() {
            var pCol1 = contentWidth * 0.06;
            var pCol2 = contentWidth * 0.28;
            var pCol3 = contentWidth * 0.14;
            var pCol4 = contentWidth * 0.14;
            var pCol5 = contentWidth * 0.14;
            var pCol6 = contentWidth * 0.12;
            var pCol7 = contentWidth * 0.12;
            var pRowHeight = 8;
            var pRowHeightData = 26;

            function drawPersonHeader(startY) {
                pdf.setFontSize(7);
                pdf.setFont('times', 'bold');
                var x = margin;
                pdf.rect(x, startY, pCol1, pRowHeight * 2);
                pdf.text('No', x + pCol1/2, startY + pRowHeight, { align: 'center' });
                x += pCol1;
                pdf.rect(x, startY, pCol2, pRowHeight * 2);
                pdf.text('Pelaksana SPD', x + pCol2/2, startY + pRowHeight, { align: 'center' });
                x += pCol2;
                pdf.rect(x, startY, pCol3, pRowHeight * 2);
                pdf.text('Hari', x + pCol3/2, startY + pRowHeight, { align: 'center' });
                x += pCol3;
                pdf.rect(x, startY, pCol4, pRowHeight * 2);
                pdf.text('Tanggal', x + pCol4/2, startY + pRowHeight, { align: 'center' });
                x += pCol4;
                pdf.rect(x, startY, pCol5 + pCol6 + pCol7, pRowHeight);
                pdf.text('Pejabat/Petugas Yang Mengesahkan', x + (pCol5+pCol6+pCol7)/2, startY + pRowHeight/2 + 2, { align: 'center' });

                var y2 = startY + pRowHeight;
                pdf.rect(x, y2, pCol5, pRowHeight);
                pdf.text('Nama', x + pCol5/2, y2 + pRowHeight/2 + 2, { align: 'center' });
                x += pCol5;
                pdf.rect(x, y2, pCol6, pRowHeight);
                pdf.text('Jabatan', x + pCol6/2, y2 + pRowHeight/2 + 2, { align: 'center' });
                x += pCol6;
                pdf.rect(x, y2, pCol7, pRowHeight);
                pdf.text('Tanda Tangan', x + pCol7/2, y2 + pRowHeight/2 + 2, { align: 'center' });

                var newY = startY + (pRowHeight * 2);
                var widths = [pCol1, pCol2, pCol3, pCol4, pCol5, pCol6, pCol7];
                x = margin;
                pdf.setFont('times', 'normal');
                for (var c = 0; c < 7; c++) {
                    pdf.rect(x, newY, widths[c], pRowHeight * 0.7);
                    pdf.text((c+1).toString(), x + widths[c]/2, newY + (pRowHeight*0.7)/2 + 1.5, { align: 'center' });
                    x += widths[c];
                }
                return newY + (pRowHeight * 0.7);
            }

            lampiranData.forEach(function(litem) {
                pdf.addPage();
                y = margin;
                drawKop();

                pdf.setFontSize(10);
                pdf.setFont('times', 'bold');
                pdf.text('Form Bukti Kehadiran Pelaksanaan Perjalanan Dinas Jabatan', pdfWidth/2, y, { align: 'center' });
                y += 6;
                pdf.setFontSize(9);
                pdf.text('Dalam Kota Sampai dengan 8 (Delapan) Jam', pdfWidth/2, y, { align: 'center' });
                y += 8;

                y = drawPersonHeader(y);

                var personLabel = (litem.nama || '-') + (litem.jabatan ? ' (' + litem.jabatan + ')' : '');
                var personSplit = pdf.splitTextToSize(personLabel, pCol2 - 4);
                var dataRowCountP = Math.max(kehadiran.length, 1);

                pdf.setFont('times', 'normal');
                pdf.setFontSize(7);
                for (var pi = 0; pi < dataRowCountP; pi++) {
                    if (y > pdfHeight - margin - pRowHeightData) {
                        pdf.addPage();
                        y = margin;
                        drawKop();
                        y = drawPersonHeader(y);
                        pdf.setFontSize(7);
                        pdf.setFont('times', 'normal');
                    }
                    var kitem = kehadiran[pi];
                    var x = margin;
                    pdf.rect(x, y, pCol1, pRowHeightData);
                    pdf.text((pi+1).toString(), x + pCol1/2, y + 5, { align: 'center' });
                    x += pCol1;
                    pdf.rect(x, y, pCol2, pRowHeightData);
                    pdf.text(personSplit, x + 2, y + 5);
                    x += pCol2;
                    pdf.rect(x, y, pCol3, pRowHeightData);
                    pdf.text(kitem ? (kitem.hari || '-') : '', x + pCol3/2, y + 5, { align: 'center' });
                    x += pCol3;
                    pdf.rect(x, y, pCol4, pRowHeightData);
                    pdf.text(kitem ? fmtTanggalPDF(kitem.tanggal) : '', x + pCol4/2, y + 5, { align: 'center' });
                    x += pCol4;
                    pdf.rect(x, y, pCol5, pRowHeightData);
                    x += pCol5;
                    pdf.rect(x, y, pCol6, pRowHeightData);
                    x += pCol6;
                    pdf.rect(x, y, pCol7, pRowHeightData);
                    y += pRowHeightData;
                }
            });
        })();
    }

    // ===== HALAMAN 2 (KEHADIRAN) =====
    pdf.addPage();
    y = margin;

    // KOP HALAMAN 2
    drawKop();

    pdf.setFontSize(10);
    pdf.setFont('times', 'bold');
    pdf.text('Form Bukti Kehadiran Pelaksanaan Perjalanan Dinas Jabatan', pdfWidth/2, y, { align: 'center' });
    y += 6;
    pdf.setFontSize(9);
    pdf.text('Dalam Kota Sampai dengan 8 (Delapan) Jam', pdfWidth/2, y, { align: 'center' });
    y += 8;

    // Tabel: total lebar kolom PERSIS = contentWidth, supaya tidak "bleber" keluar margin
    var col1 = contentWidth * 0.06;   // No
    var col2 = contentWidth * 0.28;   // Pelaksana SPD
    var col3 = contentWidth * 0.14;   // Hari
    var col4 = contentWidth * 0.14;   // Tanggal
    var col5 = contentWidth * 0.14;   // Nama
    var col6 = contentWidth * 0.12;   // Jabatan
    var col7 = contentWidth * 0.12;   // Tanda Tangan
    var rowHeight = 8;       // tinggi baris header
    var rowHeightData = 26;  // tinggi baris DATA - diperbesar agar cukup ruang untuk cap/stempel
    var startX = margin;

    function drawHeader() {
        pdf.setFontSize(7);
        pdf.setFont('times', 'bold');
        var x = startX;
        var headerY = y;

        // baris 1: No / Pelaksana SPD / Hari / Tanggal (rowspan 2) + Pejabat/Petugas (colspan 3)
        pdf.rect(x, headerY, col1, rowHeight * 2);
        pdf.text('No', x + col1/2, headerY + rowHeight, { align: 'center' });
        x += col1;
        pdf.rect(x, headerY, col2, rowHeight * 2);
        pdf.text('Pelaksana SPD', x + col2/2, headerY + rowHeight, { align: 'center' });
        x += col2;
        pdf.rect(x, headerY, col3, rowHeight * 2);
        pdf.text('Hari', x + col3/2, headerY + rowHeight, { align: 'center' });
        x += col3;
        pdf.rect(x, headerY, col4, rowHeight * 2);
        pdf.text('Tanggal', x + col4/2, headerY + rowHeight, { align: 'center' });
        x += col4;
        pdf.rect(x, headerY, col5 + col6 + col7, rowHeight);
        pdf.text('Pejabat/Petugas Yang Mengesahkan', x + (col5+col6+col7)/2, headerY + rowHeight/2 + 2, { align: 'center' });

        // baris 2: Nama / Jabatan / Tanda Tangan
        var y2 = headerY + rowHeight;
        pdf.rect(x, y2, col5, rowHeight);
        pdf.text('Nama', x + col5/2, y2 + rowHeight/2 + 2, { align: 'center' });
        x += col5;
        pdf.rect(x, y2, col6, rowHeight);
        pdf.text('Jabatan', x + col6/2, y2 + rowHeight/2 + 2, { align: 'center' });
        x += col6;
        pdf.rect(x, y2, col7, rowHeight);
        pdf.text('Tanda Tangan', x + col7/2, y2 + rowHeight/2 + 2, { align: 'center' });

        y = headerY + (rowHeight * 2);

        // baris 3: nomor kolom (1-7)
        var widths = [col1, col2, col3, col4, col5, col6, col7];
        x = startX;
        pdf.setFont('times', 'normal');
        for (var c = 0; c < 7; c++) {
            pdf.rect(x, y, widths[c], rowHeight * 0.7);
            pdf.text((c+1).toString(), x + widths[c]/2, y + (rowHeight*0.7)/2 + 1.5, { align: 'center' });
            x += widths[c];
        }
        y += rowHeight * 0.7;
    }

    drawHeader();

    pdf.setFont('times', 'normal');
    pdf.setFontSize(7);
    var pelaksanaNames = [];
    kepada.forEach(function(item) {
        pelaksanaNames.push(item.nama + (item.jabatan ? ' (' + item.jabatan + ')' : ''));
    });

    function fmtTanggalPDF(isoStr) {
        if (!isoStr) return '-';
        var parts = isoStr.split('-');
        if (parts.length !== 3) return isoStr;
        return parts[2] + '/' + parts[1] + '/' + parts[0];
    }

    var dataRowCount = Math.max(kehadiran.length, 1);
    for (var idx = 0; idx < dataRowCount; idx++) {
        if (y > pdfHeight - margin - rowHeightData) {
            pdf.addPage();
            y = margin;
            drawHeader();
            pdf.setFontSize(7);
            pdf.setFont('times', 'normal');
        }
        var item = kehadiran[idx];
        var x = startX;
        var pelaksanaText = pelaksanaNames[idx] || pelaksanaNames[0] || '-';
        var widths = [col1, col2, col3, col4, col5, col6, col7];

        pdf.rect(x, y, col1, rowHeightData);
        pdf.text((idx+1).toString(), x + col1/2, y + 5, { align: 'center' });
        x += col1;
        pdf.rect(x, y, col2, rowHeightData);
        var pelaksanaSplit = pdf.splitTextToSize(pelaksanaText, col2 - 4);
        pdf.text(pelaksanaSplit, x + 2, y + 5);
        x += col2;
        pdf.rect(x, y, col3, rowHeightData);
        pdf.text(item ? (item.hari || '-') : '', x + col3/2, y + 5, { align: 'center' });
        x += col3;
        pdf.rect(x, y, col4, rowHeightData);
        pdf.text(item ? fmtTanggalPDF(item.tanggal) : '', x + col4/2, y + 5, { align: 'center' });
        x += col4;
        pdf.rect(x, y, col5, rowHeightData);
        x += col5;
        pdf.rect(x, y, col6, rowHeightData);
        x += col6;
        pdf.rect(x, y, col7, rowHeightData);
        y += rowHeightData;
    }

    // FOTO
    if (photos.length > 0) {
        pdf.addPage();
        y = margin + 15;
        pdf.setFont('times', 'bold');
        pdf.setFontSize(12);
        var judulFoto = foto_judul || 'DOKUMENTASI KEGIATAN';
        pdf.text(judulFoto, pdfWidth/2, y, { align: 'center' });
        y += 10;

        var imgWidth = 80;
        var imgHeight = 60;
        var cols = 2;
        var spacing = 10;
        var totalWidth = (cols * imgWidth) + ((cols - 1) * spacing);
        var startXFoto = (pdfWidth - totalWidth) / 2;

        photos.forEach(function(p, index) {
            var col = index % cols;
            var row = Math.floor(index / cols);
            var x = startXFoto + (col * (imgWidth + spacing));
            var yPos = y + (row * (imgHeight + spacing + 10));

            if (yPos + imgHeight > pdfHeight - margin) {
                pdf.addPage();
                y = margin + 15;
                yPos = y + (row * (imgHeight + spacing + 10));
            }

            try {
                pdf.addImage(p.src, 'JPEG', x, yPos, imgWidth, imgHeight);
                if (p.caption) {
                    pdf.setFont('times', 'italic');
                    pdf.setFontSize(7);
                    pdf.text(p.caption, x + imgWidth/2, yPos + imgHeight + 4, { align: 'center' });
                }
            } catch(e) {
                console.log('Gagal load foto: ' + e.message);
            }
        });
    }

    pdf.save('Surat_Tugas_' + new Date().toISOString().slice(0,10) + '.pdf');
    showToast('📄 PDF berhasil di-download!', 'success');
}

// ================================================================
// TAB
// ================================================================
function switchTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
    document.getElementById('tabForm').style.display = 'none';
    document.getElementById('tabPreview').style.display = 'none';
    document.getElementById('tabRiwayat').style.display = 'none';
    if (tab === 'form') {
        document.querySelector('.tab-btn:nth-child(1)').classList.add('active');
        document.getElementById('tabForm').style.display = 'block';
    } else if (tab === 'preview') {
        document.querySelector('.tab-btn:nth-child(2)').classList.add('active');
        document.getElementById('tabPreview').style.display = 'block';
        generatePreview();
    } else if (tab === 'riwayat') {
        document.querySelector('.tab-btn:nth-child(3)').classList.add('active');
        document.getElementById('tabRiwayat').style.display = 'block';
        loadRiwayat();
    }
}

// ================================================================
// LOAD RIWAYAT
// ================================================================
function loadRiwayat() {
    fetch('api/get_submissions.php?form_key=form_st')
        .then(function(res) { return res.json(); })
        .then(function(data) {
            var container = document.getElementById('riwayatContent');
            if (data && data.length > 0) {
                var html = '<table class="submission-table"><thead><tr><th>#</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead><tbody>';
                data.forEach(function(s, i) {
                    var label = { 'draft':'📝 Draf', 'previewed':'👁 Preview', 'downloaded':'⬇ Downloaded', 'submitted':'📤 Terkirim', 'approved':'✅ Diterima', 'rejected':'❌ Ditolak' }[s.status] || s.status;
                    html += '<tr><td>'+(i+1)+'</td><td>'+new Date(s.created_at).toLocaleString()+'</td><td><span class="status-badge '+s.status+'">'+label+'</span></td><td><button class="btn-edit" onclick="editSubmission('+s.id+')">✏️ Edit</button><button class="btn-preview" onclick="previewSubmission('+s.id+')">👁 Preview</button><button class="btn-delete" onclick="deleteSubmission('+s.id+')">🗑 Hapus</button></td></tr>';
                });
                html += '</tbody></table>';
                container.innerHTML = html;
            } else {
                container.innerHTML = '<p style="text-align:center;color:#6B7A99;padding:20px;">Belum ada submission</p>';
            }
        })
        .catch(function() {});
}

// ================================================================
// EDIT SUBMISSION
// ================================================================
function editSubmission(id) {
    fetch('api/get_submission.php?id='+id)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data && data.form_data) {
                var formData = data.form_data;
                localStorage.setItem(STORAGE_KEY, JSON.stringify(formData));
                location.reload();
            }
        })
        .catch(function() {});
}

function previewSubmission(id) {
    fetch('api/get_submission.php?id='+id)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data && data.form_data) {
                var formData = data.form_data;
                localStorage.setItem(STORAGE_KEY, JSON.stringify(formData));
                loadDraft();
                generatePreview();
                switchTab('preview');
            }
        })
        .catch(function() {});
}

// ================================================================
// DELETE SUBMISSION
// ================================================================
function deleteSubmission(id) {
    if (!confirm('Yakin ingin menghapus data ini?')) return;
    fetch('api/delete_submission.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
    })
    .then(function(res) { return res.json(); })
    .then(function(result) {
        if (result.success) {
            showToast('🗑 Data berhasil dihapus!', 'success');
            loadRiwayat();
        } else {
            showToast('❌ Gagal hapus data', 'error');
        }
    })
    .catch(function() {});
}

// ================================================================
// TOAST
// ================================================================
function showToast(msg, type) {
    var toast = document.createElement('div');
    toast.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%);padding:12px 24px;border-radius:10px;font-weight:600;z-index:9999;box-shadow:0 4px 20px rgba(0,0,0,0.2);max-width:90%;';
    var colors = { success: '#2E7D32', error: '#C62828', warning: '#F5A623', info: '#2D5BE3' };
    toast.style.background = colors[type] || '#1A1A2E';
    toast.style.color = '#fff';
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(function() { toast.style.opacity = '0'; setTimeout(function() { toast.remove(); }, 300); }, 3000);
}

function submitForm() {
    if (!submissionId) {
        showToast('⚠️ Simpan draft terlebih dahulu!', 'warning');
        return;
    }
    if (!confirm('Kirim form ini untuk verifikasi?')) return;
    
    fetch('api/submit_form.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ submission_id: submissionId })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast('✅ ' + data.message, 'success');
            location.reload();
        } else {
            showToast('❌ ' + data.message, 'error');
        }
    })
    .catch(() => showToast('❌ Gagal mengirim form', 'error'));
}

// ================================================================
// INIT
// ================================================================
document.addEventListener('DOMContentLoaded', function() {
    var today = new Date().toISOString().slice(0,10);
    var tglInput = document.getElementById('ttd_tgl');
    if (tglInput && !tglInput.value) tglInput.value = today;

    loadDraft();
    loadRiwayat();
});
</script>
</body>
</html>