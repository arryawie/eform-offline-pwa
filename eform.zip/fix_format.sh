#!/bin/bash

# Cari fungsi downloadPDF dan ubah ukuran jadi F4
sed -i '/function downloadPDF() {/,/^    }/c\
function downloadPDF() {\
    saveToServer("downloaded");\
    var element = document.getElementById("previewDoc");\
    html2canvas(element, { scale: 2, useCORS: true, logging: false, allowTaint: true }).then(function(canvas) {\
        var imgData = canvas.toDataURL("image/png");\
        // F4 = 210mm x 330mm\
        var pdf = new jspdf.jsPDF("p", "mm", [210, 330]);\
        var pdfWidth = pdf.internal.pageSize.getWidth();\
        var pdfHeight = pdf.internal.pageSize.getHeight();\
        var imgWidth = canvas.width;\
        var imgHeight = canvas.height;\
        var ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);\
        var imgX = (pdfWidth - imgWidth * ratio) / 2;\
        var imgY = 0;\
        var pageHeight = pdfHeight;\
        var heightLeft = imgHeight * ratio;\
        var position = 0;\
        var margin = 1; // 1cm margin\
        var contentWidth = pdfWidth - (margin * 2);\
        var contentHeight = pdfHeight - (margin * 2);\
        var ratioContent = Math.min(contentWidth / imgWidth, contentHeight / imgHeight);\
        var imgX2 = margin + (contentWidth - imgWidth * ratioContent) / 2;\
        var imgY2 = margin;\
        pdf.addImage(imgData, "PNG", imgX2, imgY2, imgWidth * ratioContent, imgHeight * ratioContent);\
        heightLeft -= pageHeight;\
        while (heightLeft > 0) {\
            position = heightLeft - imgHeight * ratioContent;\
            pdf.addPage();\
            pdf.addImage(imgData, "PNG", imgX2, position, imgWidth * ratioContent, imgHeight * ratioContent);\
            heightLeft -= pageHeight;\
        }\
        pdf.save("Laporan_Hasil_Pengawasan_"+new Date().toISOString().slice(0,10)+".pdf");\
        showToast("📄 PDF F4 berhasil di-download!", "success");\
    }).catch(function(err) {\
        console.error(err);\
        showToast("❌ Gagal generate PDF", "error");\
    });\
}' form_a.php

echo "✅ Format F4 + margin 1cm sudah di-set!"

# ============================================================
# 2. PEMENGALAN HALAMAN TIDAK MEMOTONG ISI
# ============================================================
sed -i '/function downloadPDF() {/,/^    }/c\
function downloadPDF() {\
    saveToServer("downloaded");\
    var element = document.getElementById("previewDoc");\
    html2canvas(element, { scale: 2, useCORS: true, logging: false, allowTaint: true }).then(function(canvas) {\
        var imgData = canvas.toDataURL("image/png");\
        var pdf = new jspdf.jsPDF("p", "mm", [210, 330]);\
        var pdfWidth = pdf.internal.pageSize.getWidth();\
        var pdfHeight = pdf.internal.pageSize.getHeight();\
        var imgWidth = canvas.width;\
        var imgHeight = canvas.height;\
        var margin = 1;\
        var contentWidth = pdfWidth - (margin * 2);\
        var contentHeight = pdfHeight - (margin * 2);\
        var ratio = Math.min(contentWidth / imgWidth, contentHeight / imgHeight);\
        var imgX = margin + (contentWidth - imgWidth * ratio) / 2;\
        var imgY = margin;\
        var pageHeight = pdfHeight;\
        var imgHeightPage = imgHeight * ratio;\
        var totalPages = Math.ceil(imgHeightPage / contentHeight);\
        var heightLeft = imgHeightPage;\
        var position = 0;\
        var yOffset = 0;\
        var maxY = imgHeight * ratio;\
        var pageContentHeight = contentHeight;\
        for (var page = 0; page < totalPages; page++) {\
            if (page > 0) pdf.addPage();\
            var cropY = position;\
            var cropHeight = Math.min(pageContentHeight / ratio, imgHeight - position / ratio);\
            var canvasCrop = document.createElement("canvas");\
            canvasCrop.width = imgWidth;\
            canvasCrop.height = cropHeight * ratio;\
            var ctx = canvasCrop.getContext("2d");\
            ctx.drawImage(canvas, 0, cropY / ratio, imgWidth, cropHeight, 0, 0, imgWidth, cropHeight * ratio);\
            var imgDataCrop = canvasCrop.toDataURL("image/png");\
            pdf.addImage(imgDataCrop, "PNG", imgX, margin, imgWidth * ratio, cropHeight * ratio);\
            position += pageContentHeight;\
            heightLeft -= pageContentHeight;\
        }\
        pdf.save("Laporan_Hasil_Pengawasan_"+new Date().toISOString().slice(0,10)+".pdf");\
        showToast("📄 PDF F4 berhasil di-download!", "success");\
    }).catch(function(err) {\
        console.error(err);\
        showToast("❌ Gagal generate PDF", "error");\
    });\
}' form_a.php

echo "✅ Pemenggalan halaman tidak memotong isi!"
