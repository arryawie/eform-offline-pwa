<?php
// ============================================================
// GOOGLE DRIVE SYNC - SUPER ADMIN
// ============================================================
require_once 'config/database.php';
require_once 'config/auth.php';
requireAdmin();

if ($_SESSION['role'] !== 'super_admin') {
    die('<h1>⛔ Akses Ditolak</h1><p>Hanya Super Admin</p>');
}

// Statistik
$stats = [
    'total_files' => 0,
    'synced_files' => 0,
    'pending_files' => 0,
    'total_size' => 0
];

try {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN gdrive_file_id IS NOT NULL THEN 1 ELSE 0 END) as synced,
            SUM(CASE WHEN gdrive_file_id IS NULL AND pdf_path IS NOT NULL THEN 1 ELSE 0 END) as pending
        FROM form_submissions 
        WHERE pdf_path IS NOT NULL
    ");
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Kolom gdrive_file_id belum ada
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sinkron Google Drive</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .container { max-width: 900px; margin: 0 auto; padding: 20px; }
        .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin: 20px 0; }
        .stat-card { background: #fff; border-radius: 12px; padding: 20px; text-align: center; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .stat-card .num { font-size: 32px; font-weight: 800; }
        .stat-card .label { font-size: 12px; color: #6B7A99; text-transform: uppercase; margin-top: 4px; }
        .stat-card.blue .num { color: #2D5BE3; }
        .stat-card.green .num { color: #1A7A45; }
        .stat-card.orange .num { color: #F5A623; }
        .stat-card.red .num { color: #C62828; }
        
        .card { background: #fff; border-radius: 12px; padding: 24px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .card h2 { margin-top: 0; }
        
        .btn-sync { 
            background: linear-gradient(135deg, #4285F4, #34A853); 
            color: #fff; 
            padding: 16px 40px; 
            border: none; 
            border-radius: 12px; 
            font-size: 18px; 
            font-weight: 700; 
            cursor: pointer; 
            display: inline-flex; 
            align-items: center; 
            gap: 10px; 
            transition: all 0.3s;
        }
        .btn-sync:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(66,133,244,0.3); }
        .btn-sync:disabled { opacity: 0.6; cursor: not-allowed; }
        
        .progress-box { display: none; margin-top: 20px; padding: 20px; background: #F8F9FC; border-radius: 12px; }
        .progress-bar { background: #E0E0E0; border-radius: 6px; height: 12px; overflow: hidden; margin: 12px 0; }
        .progress-fill { background: linear-gradient(90deg, #4285F4, #34A853); height: 100%; width: 0%; transition: width 0.3s; }
        .progress-text { font-size: 13px; color: #6B7A99; margin-top: 4px; }
        
        .log-box { background: #1A1A2E; color: #00FF00; padding: 16px; border-radius: 8px; font-family: monospace; font-size: 12px; max-height: 300px; overflow-y: auto; margin-top: 16px; }
        .log-box .error { color: #FF6B6B; }
        .log-box .success { color: #4CAF50; }
        .log-box .info { color: #64B5F6; }
        
        .info-box { background: #EEF4FF; border-left: 4px solid #2D5BE3; padding: 16px; border-radius: 8px; margin-bottom: 20px; }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="app">
    <main class="main">
        <div class="container">
            <h1>☁️ Sinkron Google Drive</h1>
            <p style="color: #6B7A99;">Upload semua file PDF dari server VPS ke Google Drive</p>
            
            <!-- INFO -->
            <div class="info-box">
                <strong>ℹ️ Cara Kerja:</strong><br>
                Sinkronisasi akan mengupload semua file PDF dari folder <code>uploads/pdfs/</code> 
                ke Google Drive dengan struktur folder yang sama. File yang sudah terupload 
                tidak akan diupload ulang.
            </div>
            
            <!-- STATISTIK -->
            <div class="stats">
                <div class="stat-card blue">
                    <div class="num"><?= $stats['total'] ?? 0 ?></div>
                    <div class="label">📁 Total File</div>
                </div>
                <div class="stat-card green">
                    <div class="num"><?= $stats['synced'] ?? 0 ?></div>
                    <div class="label">✅ Sudah Sync</div>
                </div>
                <div class="stat-card orange">
                    <div class="num"><?= $stats['pending'] ?? 0 ?></div>
                    <div class="label">⏳ Belum Sync</div>
                </div>
                <div class="stat-card red">
                    <div class="num" id="sessionCount">0</div>
                    <div class="label">📊 Sesi Ini</div>
                </div>
            </div>
            
            <!-- TOMBOL SINKRON -->
            <div class="card" style="text-align: center;">
                <h2>🚀 Mulai Sinkronisasi</h2>
                <p style="color: #6B7A99;">Klik tombol di bawah untuk memulai sinkronisasi</p>
                <button class="btn-sync" id="btnSync" onclick="startSync()">
                    🔄 Sinkron Sekarang
                </button>
                
                <!-- PROGRESS -->
                <div class="progress-box" id="progressBox">
                    <div style="font-weight: 700; font-size: 14px;" id="progressTitle">Memproses...</div>
                    <div class="progress-bar">
                        <div class="progress-fill" id="progressFill"></div>
                    </div>
                    <div class="progress-text" id="progressText">0 / 0 file</div>
                </div>
                
                <!-- LOG -->
                <div class="log-box" id="logBox" style="display: none;"></div>
            </div>
            
            <!-- HASIL -->
            <div class="card" id="resultCard" style="display: none;">
                <h2>📊 Hasil Sinkronisasi</h2>
                <div id="resultContent"></div>
            </div>
        </div>
    </main>
</div>

<script>
// ============================================================
// START SYNC
// ============================================================
function startSync() {
    if (!confirm('Mulai sinkronisasi ke Google Drive?')) return;
    
    var btn = document.getElementById('btnSync');
    btn.disabled = true;
    btn.innerHTML = '⏳ Sedang Sinkron...';
    
    document.getElementById('progressBox').style.display = 'block';
    document.getElementById('logBox').style.display = 'block';
    document.getElementById('logBox').innerHTML = '';
    document.getElementById('resultCard').style.display = 'none';
    
    log('🚀 Memulai sinkronisasi...', 'info');
    
    // 1. Ambil daftar file yang belum di-sync
    fetch('api/gdrive_list_pending.php')
        .then(res => res.json())
        .then(data => {
            if (!data.success) {
                log('❌ ' + data.message, 'error');
                return;
            }
            
            var files = data.files || [];
            var total = files.length;
            
            if (total === 0) {
                log('✅ Semua file sudah tersinkron!', 'success');
                btn.disabled = false;
                btn.innerHTML = '🔄 Sinkron Sekarang';
                return;
            }
            
            log('📁 Ditemukan ' + total + ' file yang perlu di-sync', 'info');
            
            // 2. Proses upload satu-satu
            uploadNext(files, 0, total);
        })
        .catch(err => {
            log('❌ Error: ' + err.message, 'error');
            btn.disabled = false;
            btn.innerHTML = '🔄 Sinkron Sekarang';
        });
}

// ============================================================
// UPLOAD SATU-SATU
// ============================================================
function uploadNext(files, index, total) {
    if (index >= total) {
        finishSync(total);
        return;
    }
    
    var file = files[index];
    updateProgress(index + 1, total, file.filename);
    log('📤 Uploading [' + (index + 1) + '/' + total + ']: ' + file.filename, 'info');
    
    fetch('../api/gdrive_upload.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            submission_id: file.submission_id,
            pdf_path: file.pdf_path
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            log('✅ Berhasil: ' + file.filename + ' → ' + (data.gdrive_url || ''), 'success');
            document.getElementById('sessionCount').textContent = index + 1;
        } else {
            log('❌ Gagal: ' + file.filename + ' - ' + data.message, 'error');
        }
        
        // Lanjut ke file berikutnya
        uploadNext(files, index + 1, total);
    })
    .catch(err => {
        log('❌ Error: ' + file.filename + ' - ' + err.message, 'error');
        uploadNext(files, index + 1, total);
    });
}

// ============================================================
// UPDATE PROGRESS
// ============================================================
function updateProgress(current, total, filename) {
    var percent = (current / total) * 100;
    document.getElementById('progressFill').style.width = percent + '%';
    document.getElementById('progressText').textContent = current + ' / ' + total + ' file';
    document.getElementById('progressTitle').textContent = 'Uploading: ' + filename;
}

// ============================================================
// FINISH
// ============================================================
function finishSync(total) {
    log('🎉 Sinkronisasi selesai!', 'success');
    
    var btn = document.getElementById('btnSync');
    btn.disabled = false;
    btn.innerHTML = '🔄 Sinkron Sekarang';
    
    document.getElementById('resultCard').style.display = 'block';
    document.getElementById('resultContent').innerHTML = 
        '<p style="font-size: 16px;">' +
        '✅ <strong>' + total + ' file</strong> telah diproses.<br>' +
        '📁 Cek Google Drive Anda untuk melihat hasilnya.' +
        '</p>';
}

// ============================================================
// LOG
// ============================================================
function log(msg, type) {
    var box = document.getElementById('logBox');
    var time = new Date().toLocaleTimeString();
    var className = type || 'info';
    box.innerHTML += '<div class="' + className + '">[' + time + '] ' + msg + '</div>';
    box.scrollTop = box.scrollHeight;
}
</script>
</body>
</html>