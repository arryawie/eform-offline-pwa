<?php
// ============================================================
// GOOGLE DRIVE CONNECT - SUPER ADMIN
// ============================================================
require_once 'config/database.php';
require_once 'config/auth.php';
requireAdmin();

if ($_SESSION['role'] !== 'super_admin') {
    die('<h1>⛔ Akses Ditolak</h1><p>Hanya Super Admin</p>');
}

$user_id = $_SESSION['user_id'];

// ============================================================
// CEK STATUS KONEKSI
// ============================================================
$stmt = $pdo->prepare("
    SELECT gdrive_refresh_token, gdrive_folder_id, gdrive_enabled, 
           gdrive_connected_at, gdrive_email, gdrive_folder_link, gdrive_folder_name
    FROM users WHERE id = ?
");
$stmt->execute([$user_id]);
$gdrive = $stmt->fetch(PDO::FETCH_ASSOC);

$isConnected = !empty($gdrive['gdrive_refresh_token']) && $gdrive['gdrive_enabled'] == 1;

// ============================================================
// HANDLE: DISCONNECT
// ============================================================
if (isset($_GET['disconnect'])) {
    $stmt = $pdo->prepare("
        UPDATE users 
        SET gdrive_refresh_token = NULL, 
            gdrive_folder_id = NULL, 
            gdrive_enabled = 0,
            gdrive_connected_at = NULL,
            gdrive_email = NULL
        WHERE id = ?
    ");
    $stmt->execute([$user_id]);
    header('Location: gdrive_connect.php?disconnected=1');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Connect Google Drive</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        .card { background: #fff; border-radius: 12px; padding: 30px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .card h2 { margin-top: 0; }
        
        .status-box { 
            display: flex; 
            align-items: center; 
            gap: 16px; 
            padding: 20px; 
            border-radius: 12px; 
            margin-bottom: 20px;
        }
        .status-box.connected { background: #EEFAF4; border: 2px solid #34A853; }
        .status-box.disconnected { background: #FFFBEE; border: 2px solid #F5A623; }
        
        .status-icon { font-size: 48px; }
        .status-text h3 { margin: 0 0 4px; font-size: 18px; }
        .status-text p { margin: 0; color: #6B7A99; font-size: 13px; }
        
        .btn-google {
            background: #4285F4;
            color: #fff;
            padding: 14px 32px;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            transition: 0.3s;
        }
        .btn-google:hover { background: #3367D6; transform: translateY(-2px); }
        
        .btn-disconnect {
            background: #C62828;
            color: #fff;
            padding: 10px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            font-size: 13px;
        }
        .btn-disconnect:hover { background: #8E0000; }
        
        .info-table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        .info-table td { padding: 10px 12px; border-bottom: 1px solid #EEF0F6; font-size: 13px; }
        .info-table td:first-child { font-weight: 600; color: #6B7A99; width: 180px; }
        
        .step-list { padding-left: 20px; }
        .step-list li { margin-bottom: 12px; font-size: 14px; line-height: 1.6; }
        
        .alert { padding: 12px 20px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
        .alert-success { background: #EEFAF4; color: #1A7A45; border: 1px solid #A8E6CF; }
        .alert-warning { background: #FFFBEE; color: #B07A00; border: 1px solid #FFE082; }
        .alert-info { background: #EEF4FF; color: #2D5BE3; border: 1px solid #C3D4F9; }
        .alert-error { background: #FFE5E5; color: #C62828; border: 1px solid #FFCDD2; }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="app">
    <main class="main">
        <div class="container">
            <h1>☁️ Connect Google Drive</h1>
            <p style="color: #6B7A99;">Hubungkan akun Google Drive Anda untuk backup otomatis file PDF</p>
            
            <!-- NOTIFIKASI -->
            <?php if (isset($_GET['connected'])): ?>
            <div class="alert alert-success">✅ Google Drive berhasil terhubung!</div>
            <?php endif; ?>
            
            <?php if (isset($_GET['disconnected'])): ?>
            <div class="alert alert-warning">⚠️ Google Drive telah diputuskan</div>
            <?php endif; ?>
            
            <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">❌ <?= htmlspecialchars($_GET['error']) ?></div>
            <?php endif; ?>
            
            <!-- STATUS KONEKSI -->
            <div class="status-box <?= $isConnected ? 'connected' : 'disconnected' ?>">
                <div class="status-icon">
                    <?= $isConnected ? '✅' : '⚠️' ?>
                </div>
                <div class="status-text">
                    <h3><?= $isConnected ? 'Google Drive Terhubung' : 'Google Drive Belum Terhubung' ?></h3>
                    <p><?= $isConnected 
                        ? 'File PDF akan otomatis di-backup ke Google Drive'
                        : 'Hubungkan Google Drive untuk mengaktifkan fitur backup' ?>
                    </p>
                </div>
            </div>
            
            <!-- INFO KONEKSI -->
            <?php if ($isConnected): ?>
            <div class="card">
                <h2>📊 Informasi Koneksi</h2>
                <table class="info-table">
                    <tr>
                        <td>📧 Email Google</td>
                        <td><?= htmlspecialchars($gdrive['gdrive_email'] ?? '-') ?></td>
                    </tr>
                    <tr>
                        <td>📁 Folder Backup</td>
                        <td>
                            <?php if ($gdrive['gdrive_folder_link']): ?>
                            <a href="<?= htmlspecialchars($gdrive['gdrive_folder_link']) ?>" target="_blank">
                                <?= htmlspecialchars($gdrive['gdrive_folder_name'] ?? 'E-Form Backup') ?> 🔗
                            </a>
                            <?php else: ?>
                            <?= htmlspecialchars($gdrive['gdrive_folder_name'] ?? '-') ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>📅 Terhubung Sejak</td>
                        <td><?= $gdrive['gdrive_connected_at'] ? date('d/m/Y H:i', strtotime($gdrive['gdrive_connected_at'])) : '-' ?></td>
                    </tr>
                    <tr>
                        <td>🔑 Status</td>
                        <td><span style="color:#1A7A45;font-weight:600;">✅ Aktif</span></td>
                    </tr>
                </table>
                
                <div style="margin-top: 20px; display: flex; gap: 10px;">
                    <a href="gdrive_sync.php" class="btn-google" style="background:#34A853;">
                        🔄 Buka Menu Sinkron
                    </a>
                    <a href="?disconnect=1" class="btn-disconnect" 
                       onclick="return confirm('Yakin ingin memutuskan Google Drive?')">
                        🔌 Putuskan Koneksi
                    </a>
                </div>
            </div>
            
            <?php else: ?>
            
            <!-- PANDUAN CONNECT -->
            <div class="card">
                <h2>🚀 Cara Menghubungkan Google Drive</h2>
                <ol class="step-list">
                    <li><strong>Klik tombol "Connect Google Drive"</strong> di bawah</li>
                    <li>Login dengan akun Google yang ingin digunakan</li>
                    <li><strong>Izinkan akses</strong> ke Google Drive</li>
                    <li>Sistem akan otomatis membuat folder <code>E-Form Backup</code></li>
                    <li>Selesai! Anda bisa mulai sinkronisasi</li>
                </ol>
                
                <div class="alert alert-info" style="margin-top: 20px;">
                    <strong>ℹ️ Catatan:</strong> File PDF akan diupload dengan struktur folder 
                    <code>{instansi}/{form_key}/filename.pdf</code> — sama seperti di server VPS.
                </div>
                
                <div style="text-align: center; margin-top: 24px;">
                    <a href="gdrive_oauth.php" class="btn-google">
                        <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" 
                             style="width: 20px; height: 20px; background: #fff; padding: 2px; border-radius: 50%;">
                        Connect Google Drive
                    </a>
                </div>
            </div>
            
            <!-- SYARAT -->
            <div class="card">
                <h2>⚠️ Persyaratan</h2>
                <ul class="step-list">
                    <li>Akun Google aktif dengan ruang penyimpanan cukup</li>
                    <li>Google Drive API sudah di-enable di Google Cloud Console</li>
                    <li>File <code>config/gdrive_credentials.json</code> sudah ada</li>
                </ul>
            </div>
            
            <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>