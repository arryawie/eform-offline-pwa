<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? 'user';

// ============================================================
// SUPER ADMIN → tampilkan dashboard super
// ============================================================
if ($role === 'super_admin') {
    include 'dashboard_super.php';
    exit;
}

// ============================================================
// ADMIN BIASA → tampilkan dashboard admin
// ============================================================
if ($role === 'admin') {
    include 'dashboard_admin_content.php';
    exit;
}

// ============================================================
// USER → lanjut dashboard biasa
// ============================================================
$user = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$user->execute([$_SESSION['user_id']]);
$userData = $user->fetch(PDO::FETCH_ASSOC);

$totalForms = $pdo->query("SELECT COUNT(*) FROM forms")->fetchColumn();
$activeForms = $pdo->query("SELECT COUNT(*) FROM forms WHERE is_active = 1")->fetchColumn();
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

// ============================================================
// AMBIL SUBMISSION SESUAI ROLE
// ============================================================
if (hasRole('super_admin')) {
    // Super admin: lihat semua submission
    $submissions = $pdo->prepare("
        SELECT s.*, f.form_name, f.icon, f.form_key,
               u.fullname AS user_fullname, u.username AS user_username
        FROM form_submissions s 
        JOIN forms f ON s.form_id = f.id 
        JOIN users u ON s.user_id = u.id
        WHERE u.role = 'user'
        ORDER BY s.created_at DESC 
        LIMIT 20
    ");
    $submissions->execute();
} elseif (hasRole('admin')) {
    // Admin biasa: lihat submission dari user yang DIBUATNYA
    $submissions = $pdo->prepare("
        SELECT s.*, f.form_name, f.icon, f.form_key,
               u.fullname AS user_fullname, u.username AS user_username
        FROM form_submissions s 
        JOIN forms f ON s.form_id = f.id 
        JOIN users u ON s.user_id = u.id
        WHERE u.created_by = ?
        ORDER BY s.created_at DESC 
        LIMIT 20
    ");
    $submissions->execute([$_SESSION['user_id']]);
} else {
    // User biasa: lihat submission sendiri
    $submissions = $pdo->prepare("
        SELECT s.*, f.form_name, f.icon, f.form_key,
               u.fullname AS user_fullname, u.username AS user_username
        FROM form_submissions s 
        JOIN forms f ON s.form_id = f.id 
        JOIN users u ON s.user_id = u.id
        WHERE s.user_id = ?
        ORDER BY s.created_at DESC 
        LIMIT 20
    ");
    $submissions->execute([$_SESSION['user_id']]);
}
$submissionList = $submissions->fetchAll(PDO::FETCH_ASSOC);

function userCanAccess($form_key) {
    global $pdo;
    if (!isset($_SESSION['user_id'])) return false;
    if (hasRole('super_admin') || hasRole('admin')) return true;
    
    $stmt = $pdo->prepare("SELECT 1 FROM user_form_access ufa JOIN forms f ON f.id = ufa.form_id WHERE ufa.user_id = ? AND f.form_key = ?");
    $stmt->execute([$_SESSION['user_id'], $form_key]);
    return $stmt->fetch() !== false;
}

// Tampilkan form aktif sesuai role login, 1 per form_key
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? 'user';

if (in_array($role, ['super_admin', 'admin'])) {
    // Admin/Super Admin lihat form milik sendiri
    $stmt = $pdo->prepare("SELECT * FROM forms WHERE is_active = 1 AND (user_id = ?) GROUP BY form_key ORDER BY form_name");
    $stmt->execute([$user_id]);
} else {
    // User lihat form dari admin pembuatnya
    $stmt = $pdo->prepare("SELECT created_by FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    $adminId = $userData['created_by'] ?? 0;
    $stmt = $pdo->prepare("SELECT * FROM forms WHERE is_active = 1 AND user_id = ? GROUP BY form_key ORDER BY form_name");
    $stmt->execute([$adminId]);
}
$activeForms = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Hitung notifikasi belum dibaca
$unreadCount = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
$unreadCount->execute([$_SESSION['user_id']]);
$unreadTotal = $unreadCount->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .quick-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 14px; }
        .quick-card { background: #fff; border: 1px solid #DDE3F0; border-radius: 10px; padding: 16px; text-align: center; transition: 0.2s; }
        .quick-card:hover { border-color: #C0C8E0; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .quick-card .icon { font-size: 32px; }
        .quick-card .name { font-weight: 700; font-size: 13px; margin: 4px 0; }
        .quick-card .btn { margin-top: 8px; display: inline-block; padding: 6px 16px; border-radius: 6px; text-decoration: none; font-size: 12px; font-weight: 600; }
        .quick-card .btn-primary { background: #E53935; color: #fff; }
        .quick-card .btn-primary:hover { background: #c62828; }
        .quick-card .btn-disabled { background: #E0E0E0; color: #999; cursor: not-allowed; }
        .quick-card.disabled { opacity: 0.5; }
        .status-badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
        .status-badge.draft { background: #EEF0F6; color: #6B7A99; }
        .status-badge.previewed { background: #EEF4FF; color: #2D5BE3; }
        .status-badge.downloaded { background: #EEFAF4; color: #1A7A45; }
        .status-badge.submitted { background: #FFFBEE; color: #B07A00; }
        .status-badge.approved { background: #EEFAF4; color: #1A7A45; }
        .status-badge.rejected { background: #FFE5E5; color: #C62828; }
        .submission-table { width: 100%; border-collapse: collapse; font-size: 12px; }
        .submission-table th { text-align: left; padding: 6px 8px; background: #F8F9FC; color: #6B7A99; font-weight: 700; font-size: 11px; text-transform: uppercase; border-bottom: 2px solid #DDE3F0; }
        .submission-table td { padding: 6px 8px; border-bottom: 1px solid #EEF0F6; vertical-align: middle; }
        .submission-table tr:hover { background: #FAFBFD; }
        .btn-sm { padding: 4px 10px; font-size: 11px; border-radius: 4px; border: none; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-outline { background: transparent; color: #E53935; border: 1.5px solid #E53935; }
        .btn-outline:hover { background: #FFF5F5; }
        .stats-mini { display: flex; gap: 20px; flex-wrap: wrap; background: #fff; padding: 14px 18px; border-radius: 10px; border: 1px solid #DDE3F0; margin-bottom: 16px; }
        .stats-mini .item { display: flex; align-items: center; gap: 6px; font-size: 13px; }
        .stats-mini .item .num { font-weight: 700; font-size: 18px; color: #1A1A2E; }
        .stats-mini .item .label { color: #6B7A99; }
        .badge-count { background: #E53935; color: #fff; padding: 2px 8px; border-radius: 50%; font-size: 10px; font-weight: 700; }
    </style>
</head>
<body>
<?php include "sidebar.php"; ?>
    <div class="app">

        <main class="main">
            <header class="topbar">
                <div class="topbar-left">
                    <button type="button" class="hamburger" onclick="toggleSidebar()" aria-label="Buka menu">☰</button>
                    <h2>Dashboard</h2>
                </div>
                <div class="topbar-right">
                    <span class="user-badge">👤 <?= htmlspecialchars($_SESSION['fullname']) ?> <span class="role-badge"><?= $_SESSION['role'] ?></span></span>
                </div>
            </header>

            <div class="stats-mini">
                <div class="item"><span class="num"><?= count($submissionList) ?></span><span class="label">Total Submission</span></div>
                <?php foreach (['draft'=>'📝 Draf', 'previewed'=>'👁 Preview', 'downloaded'=>'⬇ Downloaded'] as $key => $label): 
                    $count = array_reduce($submissionList, function($carry, $item) use ($key) {
                        return $carry + ($item['status'] === $key ? 1 : 0);
                    }, 0);
                    if ($count > 0): ?>
                <div class="item"><span class="num"><?= $count ?></span><span class="label"><?= $label ?></span></div>
                <?php endif; endforeach; ?>
            </div>

            <?php if (hasRole('user')): ?>
            <div class="card">
                <div class="card-header"><h3>🚀 Quick Access</h3></div>
                <div class="card-body">
                    <div class="quick-grid">
                        <?php foreach ($activeForms as $form):
                            $file = $form['form_key'] . '.php';
                            $exists = file_exists($file);
                            $canAccess = userCanAccess($form['form_key']);
                            
                            // ✅ SKIP kalau tidak ada akses
                            if (!$exists || !$canAccess) continue;
                        ?>
                        <div class="quick-card <?= ($exists && $canAccess) ? '' : 'disabled' ?>">
                            <div class="icon"><?= $form['icon'] ?></div>
                            <div class="name"><?= htmlspecialchars($form['form_name']) ?></div>
                            <a href="<?= $file ?>" class="btn btn-primary">Buka Form</a>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header"><h3>📋 Riwayat Submission</h3></div>
                <div class="card-body">
                    <?php if (empty($submissionList)): ?>
                        <p style="text-align:center;color:#6B7A99;padding:20px;">Belum ada submission. Mulai buat form!</p>
                    <?php else: ?>
                    <table class="submission-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>User</th>
                            <th>Form</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <?php if (hasRole('user')): ?>
                            <th>Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $no = 1; foreach ($submissionList as $s): 
                        $statusClass = $s['status'] ?? 'draft';
                        $statusLabel = ['draft'=>'📝 Draf','previewed'=>'👁 Preview','downloaded'=>'⬇ Downloaded','submitted'=>'📤 Terkirim','approved'=>'✅ Diterima','rejected'=>'❌ Ditolak'][$statusClass] ?? $statusClass;
                        $formFile = $s['form_key'] . '.php';
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><strong><?= htmlspecialchars($s['user_fullname'] ?? $s['user_username'] ?? '-') ?></strong></td>
                        <td><?= $s['icon'] ?> <?= htmlspecialchars($s['form_name']) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($s['created_at'])) ?></td>
                        <td><span class="status-badge <?= $statusClass ?>"><?= $statusLabel ?></span></td>
                        <?php if (hasRole('user')): ?>
                        <td><a href="<?= $formFile ?>?edit=<?= $s['id'] ?>" class="btn-sm btn-outline">📝 Buka</a></td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    <script src="assets/js/main.js"></script>
    <?php include 'bottom_nav.php'; ?>
    <!-- FOOTER -->
    <footer style="text-align:center;padding:16px 0 8px;border-top:1px solid #DDE3F0;margin-top:20px;font-size:11px;color:#6B7A99;">
        E-Form System v1.8 &copy; 2026 PT. Nura Kreasi Digital
    </footer>
</body>
</html>
