#!/bin/bash

# Cari dan ganti fungsi downloadPDF
sed -i '/function downloadPDF() {/,/^    }/c\
function downloadPDF() {\
    saveToServer("downloaded");\
    \
    var pdf = new jspdf.jsPDF("p", "mm", [210, 330]);\
    var pdfWidth = pdf.internal.pageSize.getWidth();\
    var pdfHeight = pdf.internal.pageSize.getHeight();\
    var margin = 10;\
    var contentWidth = pdfWidth - (margin * 2);\
    var y = margin;\
    \
    // ===== AMBIL DATA DARI FORM =====\
    function v(id) { var el = document.getElementById(id); return el ? el.value.trim() : ""; }\
    function esc(s) { return s || ""; }\
    function fdate(s) { if(!s) return ""; var d=new Date(s); var M=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"]; return d.getDate()+" "+M[d.getMonth()]+" "+d.getFullYear(); }\
    \
    var nomor = esc(v("nomor"));\
    var tahapan = esc(v("tahapan"));\
    var nama_pengawas = esc(v("nama_pengawas"));\
    var jabatan = esc(v("jabatan"));\
    var no_st = esc(v("no_st"));\
    var alamat = esc(v("alamat"));\
    var bentuk = esc(v("bentuk"));\
    var tujuan = esc(v("tujuan"));\
    var sasaran = esc(v("sasaran"));\
    var tgl_kegiatan = fdate(v("tgl_kegiatan"));\
    var tempat_kegiatan = esc(v("tempat_kegiatan"));\
    var uraian = quill ? quill.root.innerText || quill.root.textContent : esc(v("uraian"));\
    var ttd_kota = esc(v("ttd_kota"));\
    var ttd_tgl = fdate(v("ttd_tgl"));\
    var ttd_jabatan = esc(v("ttd_jabatan"));\
    var ttd_nama = esc(v("ttd_nama"));\
    \
    // ===== KOP =====\
    pdf.setFontSize(12);\
    pdf.setFont("times", "bold");\
    var kopText = "'"<?= htmlspecialchars($kop_instansi) ?>"'";\
    pdf.text(kopText, pdfWidth/2, y, { align: "center" });\
    y += 8;\
    \
    pdf.setFontSize(8);\
    pdf.setFont("times", "normal");\
    var alamatKop = "'"<?= htmlspecialchars($kop_alamat) ?>"'";\
    if (alamatKop) { pdf.text(alamatKop, pdfWidth/2, y, { align: "center" }); y += 5; }\
    var telpKop = "'"<?= htmlspecialchars($kop_telp) ?>"'";\
    var emailKop = "'"<?= htmlspecialchars($kop_email) ?>"'";\
    if (telpKop || emailKop) {\
        var infoKop = "";\
        if (telpKop) infoKop += "Telp: " + telpKop;\
        if (telpKop && emailKop) infoKop += " | ";\
        if (emailKop) infoKop += "Email: " + emailKop;\
        pdf.text(infoKop, pdfWidth/2, y, { align: "center" });\
        y += 5;\
    }\
    y += 3;\
    pdf.line(margin, y, pdfWidth - margin, y);\
    y += 6;\
    \
    // ===== JUDUL =====\
    pdf.setFontSize(12);\
    pdf.setFont("times", "bold");\
    pdf.text("FORM A", pdfWidth/2, y, { align: "center" });\
    y += 7;\
    pdf.setFontSize(11);\
    pdf.text("LAPORAN HASIL PENGAWASAN PEMILIHAN", pdfWidth/2, y, { align: "center" });\
    y += 8;\
    pdf.setFontSize(10);\
    pdf.text("Nomor: " + (nomor || "-"), pdfWidth/2, y, { align: "center" });\
    y += 10;\
    \
    // ===== I. DATA PENGAWASAN =====\
    pdf.setFontSize(10);\
    pdf.setFont("times", "bold");\
    pdf.text("I. Data Pengawasan", margin, y);\
    y += 6;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    var dataRows = [\
        ["1. Tahapan yang diawasi", tahapan || "-"],\
        ["2. Nama Pelaksana", nama_pengawas || "-"],\
        ["3. Jabatan", jabatan || "-"],\
        ["4. Nomor Surat Tugas", no_st || "-"],\
        ["5. Alamat", alamat || "-"]\
    ];\
    dataRows.forEach(function(row) {\
        if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
        pdf.text(row[0], margin, y);\
        var splitText = pdf.splitTextToSize(row[1], 120);\
        pdf.text(splitText, margin + 60, y);\
        y += (splitText.length * 5) + 2;\
    });\
    y += 4;\
    \
    // ===== II. KEGIATAN =====\
    if (y > pdfHeight - margin - 20) { pdf.addPage(); y = margin; }\
    pdf.setFont("times", "bold");\
    pdf.setFontSize(10);\
    pdf.text("II. Kegiatan Pengawasan", margin, y);\
    y += 6;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    var kegiatanRows = [\
        ["1. Bentuk", bentuk || "-"],\
        ["2. Tujuan", tujuan || "-"],\
        ["3. Sasaran", sasaran || "-"],\
        ["4. Waktu dan Tempat", (tgl_kegiatan || "-") + ", " + (tempat_kegiatan || "-")]\
    ];\
    kegiatanRows.forEach(function(row) {\
        if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
        pdf.text(row[0], margin, y);\
        var splitText = pdf.splitTextToSize(row[1], 120);\
        pdf.text(splitText, margin + 60, y);\
        y += (splitText.length * 5) + 2;\
    });\
    y += 4;\
    \
    // ===== III. URAIAN =====\
    if (y > pdfHeight - margin - 20) { pdf.addPage(); y = margin; }\
    pdf.setFont("times", "bold");\
    pdf.setFontSize(10);\
    pdf.text("III. Uraian Singkat Hasil Pengawasan", margin, y);\
    y += 6;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    var uraianText = uraian || "-";\
    var uraianSplit = pdf.splitTextToSize(uraianText, contentWidth);\
    uraianSplit.forEach(function(line) {\
        if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
        pdf.text(line, margin, y);\
        y += 5;\
    });\
    y += 4;\
    \
    // ===== IV. PELANGGARAN =====\
    var adaP = document.getElementById("ada_pelanggaran").checked;\
    if (y > pdfHeight - margin - 20) { pdf.addPage(); y = margin; }\
    pdf.setFont("times", "bold");\
    pdf.setFontSize(10);\
    pdf.text("IV. Informasi Dugaan Pelanggaran", margin, y);\
    y += 6;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    if (adaP) {\
        var pelanggaranData = [\
            ["1. Peristiwa", v("p_peristiwa") || "-"],\
            ["   b. Tempat", v("p_tempat") || "-"],\
            ["   c. Waktu", v("p_waktu") || "-"],\
            ["   d. Pelaku", v("p_pelaku") || "-"],\
            ["   e. Alamat", v("p_alamat_pelaku") || "-"],\
            ["2. Saksi-saksi", (v("saksi1_nama") || "-") + " (" + (v("saksi1_alamat") || "-") + "), " + (v("saksi2_nama") || "-") + " (" + (v("saksi2_alamat") || "-") + ")"],\
            ["3. Alat Bukti", (v("bukti_a") || "-") + ", " + (v("bukti_b") || "-") + ", " + (v("bukti_c") || "-")],\
            ["4. Barang Bukti", (v("barang_a") || "-") + ", " + (v("barang_b") || "-") + ", " + (v("barang_c") || "-")],\
            ["5. Uraian", v("uraian_pelanggaran") || "-"],\
            ["6. Fakta", v("fakta") || "-"],\
            ["7. Analisa", v("analisa") || "-"]\
        ];\
        pelanggaranData.forEach(function(row) {\
            if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
            pdf.text(row[0], margin, y);\
            var splitText = pdf.splitTextToSize(row[1], 120);\
            pdf.text(splitText, margin + 60, y);\
            y += (splitText.length * 5) + 2;\
        });\
    } else {\
        pdf.text("Nihil", margin, y);\
        y += 6;\
    }\
    y += 4;\
    \
    // ===== V. SENGKETA =====\
    var adaS = document.getElementById("ada_sengketa").checked;\
    if (y > pdfHeight - margin - 20) { pdf.addPage(); y = margin; }\
    pdf.setFont("times", "bold");\
    pdf.setFontSize(10);\
    pdf.text("V. Informasi Potensi Sengketa", margin, y);\
    y += 6;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    if (adaS) {\
        var sengketaData = [\
            ["1. Peristiwa", v("s_peserta") || "-"],\
            ["   b. Tempat", v("s_tempat") || "-"],\
            ["   c. Waktu", v("s_waktu") || "-"],\
            ["2. Obyek Sengketa", v("s_bentuk") || "-"],\
            ["   b. Identitas", v("s_identitas") || "-"],\
            ["   c. Tanggal", v("s_tgl_keluar") || "-"],\
            ["   d. Kerugian", v("s_kerugian") || "-"],\
            ["3. Uraian", v("s_uraian") || "-"]\
        ];\
        sengketaData.forEach(function(row) {\
            if (y > pdfHeight - margin) { pdf.addPage(); y = margin; }\
            pdf.text(row[0], margin, y);\
            var splitText = pdf.splitTextToSize(row[1], 120);\
            pdf.text(splitText, margin + 60, y);\
            y += (splitText.length * 5) + 2;\
        });\
    } else {\
        pdf.text("Nihil", margin, y);\
        y += 6;\
    }\
    y += 4;\
    \
    // ===== VI. TTD =====\
    if (y > pdfHeight - margin - 40) { pdf.addPage(); y = margin; }\
    pdf.setFont("times", "bold");\
    pdf.setFontSize(10);\
    pdf.text("VI. Penandatangan", margin, y);\
    y += 8;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(9);\
    var ttdText = (ttd_kota || "-") + ", " + (ttd_tgl || "-");\
    pdf.text(ttdText, margin + 80, y);\
    y += 8;\
    pdf.text(ttd_jabatan || "-", margin + 80, y);\
    y += 8;\
    pdf.text("_________________________", margin + 75, y);\
    y += 6;\
    pdf.setFont("times", "bold");\
    pdf.text(ttd_nama || "-", margin + 80, y);\
    y += 6;\
    pdf.setFont("times", "normal");\
    pdf.setFontSize(8);\
    pdf.text("Nama Lengkap", margin + 75, y);\
    y += 10;\
    \
    // ===== DOKUMENTASI =====\
    if (photos.length > 0) {\
        pdf.addPage();\
        y = margin + 20;\
        pdf.setFont("times", "bold");\
        pdf.setFontSize(12);\
        pdf.text("DOKUMENTASI KEGIATAN", pdfWidth/2, y, { align: "center" });\
        y += 10;\
        \
        var fotoJudul = esc(v("foto_judul"));\
        if (fotoJudul) {\
            pdf.setFont("times", "italic");\
            pdf.setFontSize(9);\
            pdf.text(fotoJudul, pdfWidth/2, y, { align: "center" });\
            y += 10;\
        }\
        \
        var imgWidth = 80;\
        var imgHeight = 60;\
        var cols = 2;\
        var spacing = 10;\
        var totalWidth = (cols * imgWidth) + ((cols - 1) * spacing);\
        var startX = (pdfWidth - totalWidth) / 2;\
        \
        photos.forEach(function(p, index) {\
            var col = index % cols;\
            var row = Math.floor(index / cols);\
            var x = startX + (col * (imgWidth + spacing));\
            var yPos = y + (row * (imgHeight + spacing + 10));\
            \
            if (yPos + imgHeight > pdfHeight - margin) {\
                pdf.addPage();\
                y = margin + 20;\
                yPos = y + (row * (imgHeight + spacing + 10));\
            }\
            \
            try {\
                pdf.addImage(p.src, "JPEG", x, yPos, imgWidth, imgHeight);\
                if (p.caption) {\
                    pdf.setFont("times", "italic");\
                    pdf.setFontSize(7);\
                    pdf.text(p.caption, x + imgWidth/2, yPos + imgHeight + 4, { align: "center" });\
                }\
            } catch(e) {\
                console.log("Gagal load foto: " + e.message);\
            }\
        });\
    }\
    \
    pdf.save("Laporan_Hasil_Pengawasan_" + new Date().toISOString().slice(0,10) + ".pdf");\
    showToast("📄 PDF F4 berhasil di-download!", "success");\
}' form_a.php

echo "✅ PDF generator sudah diperbaiki!"
echo "   - Sekarang data diambil dari input form"
echo "   - Uraian dari Quill Editor"
echo "   - Foto dari upload user"
