#!/bin/bash

# Tambahkan CDN Quill Editor di head
sed -i '/<head>/a\
    <!-- Quill Editor CDN -->\
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">\
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>' form_a.php

# Ganti textarea uraian dengan div untuk Quill
sed -i '/<textarea id="uraian" rows="8" placeholder=""><\/textarea>/c\
                            <div id="editor_uraian" style="height: 300px; border: 1px solid #DDE3F0; border-radius: 8px;"></div>\
                            <input type="hidden" id="uraian" name="uraian">' form_a.php

# Tambahkan script inisialisasi Quill di bagian akhir script
sed -i '/\/\/ INIT/a\
    // ================================================================\
    // INIT QUILL EDITOR\
    // ================================================================\
    var quill = new Quill("#editor_uraian", {\
        theme: "snow",\
        modules: {\
            toolbar: [\
                [{ "header": [1, 2, 3, 4, 5, 6, false] }],\
                [{ "font": [] }],\
                ["bold", "italic", "underline", "strike"],\
                [{ "color": [] }, { "background": [] }],\
                [{ "list": "ordered" }, { "list": "bullet" }],\
                [{ "indent": "-1" }, { "indent": "+1" }],\
                [{ "align": [] }],\
                ["blockquote", "code-block"],\
                ["link", "image", "video"],\
                ["clean"]\
            ]\
        },\
        placeholder: "Tulis uraian hasil pengawasan di sini..."\
    });\
    \
    // Sync quill content ke hidden input sebelum save\
    quill.on("text-change", function() {\
        document.getElementById("uraian").value = quill.root.innerHTML;\
    });\
    \
    // Load existing data ke quill\
    function loadQuillContent(content) {\
        if (content) {\
            quill.root.innerHTML = content;\
        }\
    }' form_a.php

# Update loadDraft untuk load konten ke quill
sed -i '/if (data.uraian) { document.getElementById("uraian").value = data.uraian; }/c\
                if (data.uraian) { \
                    document.getElementById("uraian").value = data.uraian; \
                    if (typeof quill !== "undefined") { quill.root.innerHTML = data.uraian; } \
                }' form_a.php

echo "✅ Toolbar bullet, numbering, insert, edit, adjust tabel sudah ditambahkan!"
